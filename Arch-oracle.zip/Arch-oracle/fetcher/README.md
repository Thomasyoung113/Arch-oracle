# Ordinals Oracle — Fetcher Bot

Off-chain price aggregator for the Arch Network Ordinals Oracle.
Fetches floor prices from 4 marketplaces, computes a weighted median, signs the result, and submits it to your deployed Arch oracle program.

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Generate your oracle node keypair (do this once)
node src/keygen.js

# 3. Copy .env.example and fill in your values
cp .env.example .env
# → paste your ORACLE_PRIVATE_KEY from step 2
# → set ARCH_PROGRAM_ID once you deploy the Rust program

# 4. Run tests (no network needed)
npm test

# 5. Run one fetch round
npm run fetch-once

# 6. Start the continuous loop (fetches every 10 minutes)
npm start
```

## File Structure

```
src/
  index.js        ← Main loop (entry point)
  fetchers.js     ← One fetcher per marketplace (Magic Eden, OKX, Unisat, Gamma)
  aggregator.js   ← Median, outlier removal, confidence scoring
  signer.js       ← Ed25519 signing of price reports
  submitter.js    ← Submits signed reports to Arch Network via RPC
  collections.js  ← List of tracked Ordinals collections + their slugs
  logger.js       ← Structured colour logger
  keygen.js       ← One-time keypair generator
  test.js         ← Unit tests for pure functions
```

## How It Works

```
Every 10 minutes:
  For each collection (NodeMonkes, Bitcoin Puppets, etc.):
    1. Fetch floor price from Magic Eden  ──┐
    2. Fetch floor price from OKX         ──┤→ 4 parallel requests
    3. Fetch floor price from Unisat      ──┤
    4. Fetch floor price from Gamma       ──┘
    5. Remove outliers (>2 std dev)
    6. Compute weighted median
    7. Score confidence (0-100)
    8. Sign report with oracle keypair (Ed25519)
    9. Submit signed report to Arch via RPC
```

## Environment Variables

| Variable | Description | Default |
|---|---|---|
| `ORACLE_PRIVATE_KEY` | Base58 Ed25519 private key | required |
| `ARCH_RPC_URL` | Arch Network RPC endpoint | testnet URL |
| `ARCH_PROGRAM_ID` | Deployed oracle program ID | required for submission |
| `FETCH_INTERVAL_MS` | How often to fetch (ms) | 600000 (10 min) |
| `MIN_SOURCES` | Min valid sources to submit | 2 |
| `MAX_DEVIATION_PCT` | Max price change % before skipping | 20 |
| `UNISAT_API_KEY` | Unisat API key (get at unisat.io) | optional |
| `LOG_LEVEL` | debug / info / warn / error | info |

## Next Step

Once this bot is running and submitting prices, deploy the **Rust oracle program** to Arch testnet — it will verify your signatures and publish the aggregated price on-chain for other protocols to read.
