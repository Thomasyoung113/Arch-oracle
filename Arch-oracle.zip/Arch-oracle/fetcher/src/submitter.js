// ─────────────────────────────────────────────────────────────
// submitter.js — Submits signed price reports to Arch Network
//
// Calls the Arch RPC to invoke the oracle program's
// submit_price instruction with the signed price report.
// ─────────────────────────────────────────────────────────────

import axios from "axios";
import { logger } from "./logger.js";

const ARCH_RPC_URL = process.env.ARCH_RPC_URL ?? "https://rpc.testnet.arch.network";
const PROGRAM_ID   = process.env.ARCH_PROGRAM_ID ?? "";

const rpc = axios.create({
  baseURL: ARCH_RPC_URL,
  timeout: 15000,
  headers: { "Content-Type": "application/json" },
});

/**
 * Submit a signed price report to the Arch oracle program.
 *
 * Arch uses a JSON-RPC interface similar to Solana.
 * The instruction data is serialized as a base64 payload.
 *
 * @param {Object} signedReport - { report, signature, publicKey }
 * @returns {string} Transaction ID on success
 */
export async function submitToArch(signedReport) {
  if (!PROGRAM_ID) {
    logger.warn("ARCH_PROGRAM_ID not set — skipping on-chain submission (dry run)");
    return "dry-run-no-program-id";
  }

  const { report, signature, publicKey } = signedReport;

  // Serialize the instruction payload for Arch's ArchVM
  // This matches the instruction layout expected by the Rust program
  const instructionData = {
    instruction: "submit_price",
    args: {
      collection_id: report.collectionId,
      price_sats:    report.priceSats,
      confidence:    report.confidence,
      sources:       report.sources,
      timestamp:     report.timestamp,
    },
  };

  // Base64-encode the instruction payload (Arch expects this format)
  const encodedData = Buffer.from(JSON.stringify(instructionData)).toString("base64");

  // Build the Arch RPC transaction
  const tx = {
    version:  1,
    signers:  [publicKey],
    message: {
      signers:      [publicKey],
      instructions: [
        {
          program_id: PROGRAM_ID,
          accounts:   [
            // Oracle state account for this collection (must exist on-chain)
            {
              pubkey:      deriveCollectionAccount(report.collectionId, publicKey),
              is_signer:   false,
              is_writable: true,
            },
            // Reporter account (the oracle node's account)
            {
              pubkey:      publicKey,
              is_signer:   true,
              is_writable: false,
            },
          ],
          data: encodedData,
        },
      ],
    },
    signatures: [signature],
  };

  try {
    logger.info(`Submitting price to Arch: ${report.collectionId} @ ${report.priceSats} sats`);

    const response = await rpc.post("/", {
      jsonrpc: "2.0",
      id:      1,
      method:  "send_transaction",
      params:  [tx],
    });

    if (response.data.error) {
      throw new Error(`RPC error: ${JSON.stringify(response.data.error)}`);
    }

    const txId = response.data.result;
    logger.info(`✅ Submitted! TxID: ${txId}`);
    return txId;
  } catch (err) {
    logger.error(`Failed to submit to Arch: ${err.message}`);
    throw err;
  }
}

/**
 * Derive the on-chain state account address for a collection.
 * This mirrors the PDA (program derived address) logic in the Rust program.
 *
 * In production, compute this from program_id + collection_id seed.
 * For now, returns a deterministic placeholder for testing.
 */
function deriveCollectionAccount(collectionId, reporterPubkey) {
  // TODO: Replace with actual PDA derivation once program is deployed
  // This should match: find_program_address([b"oracle", collection_id.as_bytes()], program_id)
  return `oracle_state_${collectionId}_placeholder`;
}

/**
 * Check if the Arch RPC is reachable and responding.
 */
export async function healthCheck() {
  try {
    const response = await rpc.post("/", {
      jsonrpc: "2.0",
      id:      1,
      method:  "get_block_count",
      params:  [],
    });
    const blockHeight = response.data.result;
    logger.info(`Arch RPC healthy. Block height: ${blockHeight}`);
    return true;
  } catch (err) {
    logger.error(`Arch RPC health check failed: ${err.message}`);
    return false;
  }
}
