// ─────────────────────────────────────────────────────────────
// collections.js — Master list of tracked Ordinals collections
// Each collection has its slug per marketplace (they differ!)
// ─────────────────────────────────────────────────────────────

export const COLLECTIONS = [
  {
    id: "node-monkes",
    name: "NodeMonkes",
    magicEdenSlug: "node-monkes",
    okxSlug: "node-monkes",
    unisatSlug: "NodeMonkes",
    gammaSlug: "node-monkes",
    minLiquidityBTC: 1, // skip if floor too low (likely dead collection)
  },
  {
    id: "bitcoin-puppets",
    name: "Bitcoin Puppets",
    magicEdenSlug: "bitcoin-puppets",
    okxSlug: "bitcoin-puppets",
    unisatSlug: "Bitcoin Puppets",
    gammaSlug: "bitcoin-puppets",
    minLiquidityBTC: 0.5,
  },
  {
    id: "ordinal-maxi-biz",
    name: "Ordinal Maxi Biz (OMB)",
    magicEdenSlug: "ordinal-maxi-biz",
    okxSlug: "ordinal-maxi-biz",
    unisatSlug: "Ordinal Maxi Biz",
    gammaSlug: "ordinal-maxi-biz",
    minLiquidityBTC: 0.5,
  },
  {
    id: "runestones",
    name: "Runestones",
    magicEdenSlug: "runestones",
    okxSlug: "runestones",
    unisatSlug: "Runestones",
    gammaSlug: "runestones",
    minLiquidityBTC: 0.1,
  },
  {
    id: "bitcoin-frogs",
    name: "Bitcoin Frogs",
    magicEdenSlug: "bitcoin-frogs",
    okxSlug: "bitcoin-frogs",
    unisatSlug: "Bitcoin Frogs",
    gammaSlug: "bitcoin-frogs",
    minLiquidityBTC: 0.3,
  },
];

// Return a collection config by its id
export function getCollection(id) {
  return COLLECTIONS.find((c) => c.id === id) ?? null;
}
