// ─────────────────────────────────────────────────────────────
// index.js — Ordinals Oracle Fetcher Bot
//
// Main loop:
//   For each tracked collection:
//     1. Fetch floor prices from all 4 marketplaces in parallel
//     2. Aggregate using weighted median + outlier removal
//     3. Sign the report with the oracle node keypair
//     4. Submit the signed report to the Arch oracle program
//   Sleep for FETCH_INTERVAL_MS, then repeat
// ─────────────────────────────────────────────────────────────

import "dotenv/config";
import { COLLECTIONS } from "./collections.js";
import { fetchAllSources } from "./fetchers.js";
import { aggregate, isDeviationAcceptable } from "./aggregator.js";
import { loadKeypair, buildReport, signReport } from "./signer.js";
import { submitToArch, healthCheck } from "./submitter.js";
import { logger } from "./logger.js";

// In-memory store of last submitted price per collection (for deviation check)
const lastPrices = {};

// ─── Single fetch + submit round ─────────────────────────────
async function runRound(keyPair) {
  logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  logger.info(`Starting fetch round — ${new Date().toISOString()}`);
  logger.info("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");

  const results = [];

  for (const collection of COLLECTIONS) {
    try {
      // 1. Fetch from all sources
      const rawResults = await fetchAllSources(collection);

      // 2. Aggregate
      const aggregated = aggregate(rawResults, collection.id);
      if (!aggregated) {
        logger.warn(`[${collection.id}] Skipping — aggregation failed`);
        continue;
      }

      const { priceSats, confidence, sources } = aggregated;

      // 3. Deviation check — don't submit wildly different prices
      const lastPrice = lastPrices[collection.id];
      if (!isDeviationAcceptable(priceSats, lastPrice)) {
        logger.warn(`[${collection.id}] Deviation too high vs last price ${lastPrice}. Skipping.`);
        continue;
      }

      // 4. Build + sign report
      const report = buildReport(collection.id, priceSats, confidence, sources);
      const signedReport = signReport(report, keyPair);

      // 5. Submit to Arch
      const txId = await submitToArch(signedReport);

      // 6. Update local state
      lastPrices[collection.id] = priceSats;

      results.push({
        collection: collection.name,
        priceSats,
        priceBTC: (priceSats / 1e8).toFixed(6),
        confidence,
        sources,
        txId,
      });
    } catch (err) {
      logger.error(`[${collection.id}] Unhandled error in round`, { error: err.message });
    }
  }

  // Print round summary
  logger.info("\n📊 Round Summary:");
  for (const r of results) {
    logger.info(
      `  ${r.collection.padEnd(25)} ${r.priceBTC} BTC  (confidence: ${r.confidence}%  sources: ${r.sources.length})`
    );
  }

  return results;
}

// ─── Main ─────────────────────────────────────────────────────
async function main() {
  logger.info("🔮 Ordinals Price Oracle — Fetcher Bot starting...");

  // Load keypair first — fail fast if not configured
  let keyPair;
  try {
    keyPair = loadKeypair();
  } catch (err) {
    logger.error(`Keypair error: ${err.message}`);
    logger.info("Run `node src/keygen.js` to generate a keypair, then add it to .env");
    process.exit(1);
  }

  // Check Arch RPC health
  const healthy = await healthCheck();
  if (!healthy) {
    logger.warn("Arch RPC unreachable — will retry on each round, continuing anyway");
  }

  const INTERVAL_MS = parseInt(process.env.FETCH_INTERVAL_MS ?? "600000");
  const runOnce = process.argv.includes("--once");

  // Run immediately
  await runRound(keyPair);

  if (runOnce) {
    logger.info("--once flag set. Exiting after first round.");
    process.exit(0);
  }

  // Then loop on interval
  logger.info(`\n⏱  Next round in ${INTERVAL_MS / 1000}s. (CTRL+C to stop)\n`);
  setInterval(async () => {
    await runRound(keyPair);
    logger.info(`\n⏱  Next round in ${INTERVAL_MS / 1000}s.\n`);
  }, INTERVAL_MS);
}

main().catch((err) => {
  logger.error("Fatal error", { error: err.message, stack: err.stack });
  process.exit(1);
});
