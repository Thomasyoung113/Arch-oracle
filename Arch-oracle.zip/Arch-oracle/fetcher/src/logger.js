// ─────────────────────────────────────────────
// logger.js — Structured logger
// ─────────────────────────────────────────────

const LEVELS = { debug: 0, info: 1, warn: 2, error: 3 };
const COLORS = {
  debug: "\x1b[36m", // cyan
  info:  "\x1b[32m", // green
  warn:  "\x1b[33m", // yellow
  error: "\x1b[31m", // red
  reset: "\x1b[0m",
  dim:   "\x1b[2m",
};

const currentLevel = LEVELS[process.env.LOG_LEVEL ?? "info"] ?? 1;

function log(level, message, data = null) {
  if (LEVELS[level] < currentLevel) return;

  const ts = new Date().toISOString();
  const color = COLORS[level];
  const prefix = `${COLORS.dim}${ts}${COLORS.reset} ${color}[${level.toUpperCase().padEnd(5)}]${COLORS.reset}`;

  if (data) {
    console.log(`${prefix} ${message}`, JSON.stringify(data, null, 2));
  } else {
    console.log(`${prefix} ${message}`);
  }
}

export const logger = {
  debug: (msg, data) => log("debug", msg, data),
  info:  (msg, data) => log("info",  msg, data),
  warn:  (msg, data) => log("warn",  msg, data),
  error: (msg, data) => log("error", msg, data),
};
