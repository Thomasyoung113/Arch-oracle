// ─────────────────────────────────────────────────────────────
// keygen.js — Generate a fresh oracle node keypair
//
// Run once: node src/keygen.js
// Copy the ORACLE_PRIVATE_KEY value into your .env file
// ─────────────────────────────────────────────────────────────

import nacl from "tweetnacl";
import bs58 from "bs58";

const keyPair = nacl.sign.keyPair();

const privateKeyB58 = bs58.encode(keyPair.secretKey); // 64 bytes
const publicKeyB58  = bs58.encode(keyPair.publicKey);  // 32 bytes

console.log("\n╔══════════════════════════════════════════════════════╗");
console.log("║         Ordinals Oracle — Node Keypair               ║");
console.log("╚══════════════════════════════════════════════════════╝\n");
console.log("Public Key (share this — register on-chain):");
console.log(`  ${publicKeyB58}\n`);
console.log("Private Key (keep secret — paste into .env):");
console.log(`  ORACLE_PRIVATE_KEY=${privateKeyB58}\n`);
console.log("⚠️  Store the private key securely. Do NOT commit it to git.\n");
