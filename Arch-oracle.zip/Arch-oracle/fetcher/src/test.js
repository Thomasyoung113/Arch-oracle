// ─────────────────────────────────────────────────────────────
// test.js — Unit tests for aggregation logic
// Run with: node src/test.js
// No network or .env needed — tests pure math functions
// ─────────────────────────────────────────────────────────────

import { median, removeOutliers, aggregate } from "./aggregator.js";
import { buildReport, signReport, verifyReport } from "./signer.js";
import nacl from "tweetnacl";
import bs58 from "bs58";

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`  ✅ ${name}`);
    passed++;
  } catch (err) {
    console.log(`  ❌ ${name}: ${err.message}`);
    failed++;
  }
}

function assert(condition, message) {
  if (!condition) throw new Error(message ?? "Assertion failed");
}

function assertEqual(a, b, message) {
  if (a !== b) throw new Error(message ?? `Expected ${a} === ${b}`);
}

// ─── Median Tests ─────────────────────────────────────────────
console.log("\n📐 Median Tests:");

test("median of odd-length array", () => {
  assertEqual(median([1, 3, 5]), 3);
});

test("median of even-length array", () => {
  assertEqual(median([1, 3, 5, 7]), 4);
});

test("median of single element", () => {
  assertEqual(median([42]), 42);
});

test("median of identical values", () => {
  assertEqual(median([5, 5, 5, 5]), 5);
});

// ─── Outlier Removal Tests ─────────────────────────────────────
console.log("\n🔍 Outlier Removal Tests:");

test("removes extreme high outlier", () => {
  // 5_000_000 sats is a massive outlier vs ~4_000_000
  const prices = [3_900_000, 4_000_000, 4_100_000, 5_000_000];
  const clean = removeOutliers(prices);
  assert(!clean.includes(5_000_000), "Extreme outlier should be removed");
});

test("keeps close prices intact", () => {
  const prices = [3_950_000, 4_000_000, 4_050_000, 4_020_000];
  const clean = removeOutliers(prices);
  assertEqual(clean.length, 4, "No outliers in close prices");
});

test("does not filter with only 2 sources", () => {
  // With 2 prices we can't statistically determine outliers
  const prices = [1_000_000, 5_000_000];
  const clean = removeOutliers(prices);
  assertEqual(clean.length, 2, "Should not filter 2-element array");
});

// ─── Aggregation Tests ────────────────────────────────────────
console.log("\n🧮 Aggregation Tests:");

// Set env var for test
process.env.MIN_SOURCES = "2";

test("aggregates 4 valid sources correctly", () => {
  const results = [
    { source: "magic-eden", priceSats: 4_000_000 },
    { source: "okx",        priceSats: 4_100_000 },
    { source: "unisat",     priceSats: 3_950_000 },
    { source: "gamma",      priceSats: 4_050_000 },
  ];
  const agg = aggregate(results, "test-collection");
  assert(agg !== null, "Should return aggregated result");
  assert(agg.priceSats >= 3_950_000 && agg.priceSats <= 4_100_000, "Price should be in range");
  assertEqual(agg.sources.length, 4, "Should include all 4 sources");
});

test("handles 1 failed source gracefully", () => {
  const results = [
    { source: "magic-eden", priceSats: 4_000_000 },
    { source: "okx",        priceSats: null },       // failed
    { source: "unisat",     priceSats: 4_050_000 },
    { source: "gamma",      priceSats: 3_980_000 },
  ];
  const agg = aggregate(results, "test-collection");
  assert(agg !== null, "Should still aggregate with 3 valid sources");
  assertEqual(agg.sources.length, 3);
});

test("returns null when fewer than MIN_SOURCES respond", () => {
  const results = [
    { source: "magic-eden", priceSats: null },
    { source: "okx",        priceSats: null },
    { source: "unisat",     priceSats: 4_000_000 }, // only 1 valid
    { source: "gamma",      priceSats: null },
  ];
  const agg = aggregate(results, "test-collection");
  assertEqual(agg, null, "Should return null with only 1 source");
});

test("confidence is lower with high price spread", () => {
  const tight = [
    { source: "magic-eden", priceSats: 4_000_000 },
    { source: "okx",        priceSats: 4_010_000 },
    { source: "unisat",     priceSats: 3_990_000 },
  ];
  const spread = [
    { source: "magic-eden", priceSats: 3_000_000 },
    { source: "okx",        priceSats: 5_000_000 },
    { source: "unisat",     priceSats: 4_000_000 },
  ];
  const tightAgg  = aggregate(tight,  "test");
  const spreadAgg = aggregate(spread, "test");
  assert(tightAgg.confidence > spreadAgg.confidence, "Tight prices should have higher confidence");
});

// ─── Signing Tests ────────────────────────────────────────────
console.log("\n🔏 Signing Tests:");

test("sign + verify round trip", () => {
  const keyPair = nacl.sign.keyPair();
  const patchedKeyPair = {
    secretKey: keyPair.secretKey,
    publicKey: keyPair.publicKey,
  };

  const report = buildReport("node-monkes", 4_000_000, 90, ["magic-eden", "okx"]);
  const signedReport = signReport(report, {
    secretKey: keyPair.secretKey,
    publicKey: keyPair.publicKey,
  });

  const valid = verifyReport(signedReport);
  assert(valid, "Signature should verify correctly");
});

test("tampered report fails verification", () => {
  const keyPair = nacl.sign.keyPair();
  const report = buildReport("node-monkes", 4_000_000, 90, ["magic-eden"]);
  const signedReport = signReport(report, keyPair);

  // Tamper with the price after signing
  signedReport.report.priceSats = 1_000_000;

  const valid = verifyReport(signedReport);
  assert(!valid, "Tampered report should fail verification");
});

// ─── Summary ──────────────────────────────────────────────────
console.log(`\n${"─".repeat(50)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed === 0) {
  console.log("✅ All tests passed!\n");
} else {
  console.log("❌ Some tests failed.\n");
  process.exit(1);
}
