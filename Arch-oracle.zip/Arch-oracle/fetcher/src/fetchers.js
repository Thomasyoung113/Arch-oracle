// ─────────────────────────────────────────────────────────────
// fetchers.js — One fetcher per marketplace
//
// Each fetcher:
//   - Accepts a collection config object
//   - Returns { source, priceSats } or { source, priceSats: null } on failure
//   - Never throws — failures are caught and returned as null prices
//
// Price unit: satoshis (1 BTC = 100,000,000 sats)
// ─────────────────────────────────────────────────────────────

import axios from "axios";
import { logger } from "./logger.js";

// Shared axios config — 8 second timeout, standard headers
const http = axios.create({
  timeout: 8000,
  headers: {
    "User-Agent": "OrdinalsPriceOracle/1.0",
    Accept: "application/json",
  },
});

// Convert BTC string/float to satoshis (integer)
function btcToSats(btc) {
  return Math.round(parseFloat(btc) * 1e8);
}

// ─── Magic Eden ───────────────────────────────────────────────
export async function fetchMagicEden(collection) {
  const source = "magic-eden";
  try {
    // Magic Eden public API - no auth required for floor price
    const url = `https://api-mainnet.magiceden.dev/v2/ord/btc/stat?collectionSymbol=${collection.magicEdenSlug}`;
    const { data } = await http.get(url);

    // Response shape: { floorPrice: number (in sats), ... }
    const priceSats = data?.floorPrice ?? null;

    if (!priceSats || priceSats <= 0) throw new Error("Invalid floor price in response");

    logger.debug(`[${source}] ${collection.id}: ${priceSats} sats`);
    return { source, priceSats };
  } catch (err) {
    logger.warn(`[${source}] Failed to fetch ${collection.id}: ${err.message}`);
    return { source, priceSats: null };
  }
}

// ─── OKX NFT ─────────────────────────────────────────────────
export async function fetchOKX(collection) {
  const source = "okx";
  try {
    // OKX NFT Marketplace API
    const url = `https://www.okx.com/priapi/v1/nft/collection/detail?slug=${collection.okxSlug}&chain=bitcoin`;
    const { data } = await http.get(url);

    // Response shape: { data: { floorPrice: "0.05", ... } }
    const rawPrice = data?.data?.floorPrice ?? null;
    if (!rawPrice) throw new Error("No floorPrice in OKX response");

    // OKX returns price in BTC as a string
    const priceSats = btcToSats(rawPrice);
    if (priceSats <= 0) throw new Error("Invalid price");

    logger.debug(`[${source}] ${collection.id}: ${priceSats} sats`);
    return { source, priceSats };
  } catch (err) {
    logger.warn(`[${source}] Failed to fetch ${collection.id}: ${err.message}`);
    return { source, priceSats: null };
  }
}

// ─── Unisat ───────────────────────────────────────────────────
export async function fetchUnisat(collection) {
  const source = "unisat";
  try {
    // Unisat open API
    const url = `https://open-api.unisat.io/v3/market/collection/auction/summary?collectionId=${collection.unisatSlug}`;
    const { data } = await http.get(url, {
      headers: {
        // Unisat requires an API key in prod — get one at unisat.io/developer
        Authorization: `Bearer ${process.env.UNISAT_API_KEY ?? ""}`,
      },
    });

    // Response shape: { data: { floorPrice: number (sats) } }
    const priceSats = data?.data?.floorPrice ?? null;
    if (!priceSats || priceSats <= 0) throw new Error("Invalid price");

    logger.debug(`[${source}] ${collection.id}: ${priceSats} sats`);
    return { source, priceSats };
  } catch (err) {
    logger.warn(`[${source}] Failed to fetch ${collection.id}: ${err.message}`);
    return { source, priceSats: null };
  }
}

// ─── Gamma.io ─────────────────────────────────────────────────
export async function fetchGamma(collection) {
  const source = "gamma";
  try {
    const url = `https://gamma.io/api/v1/collections/${collection.gammaSlug}`;
    const { data } = await http.get(url);

    // Response shape: { floor_price: "0.045" } (BTC)
    const rawPrice = data?.floor_price ?? null;
    if (!rawPrice) throw new Error("No floor_price in Gamma response");

    const priceSats = btcToSats(rawPrice);
    if (priceSats <= 0) throw new Error("Invalid price");

    logger.debug(`[${source}] ${collection.id}: ${priceSats} sats`);
    return { source, priceSats };
  } catch (err) {
    logger.warn(`[${source}] Failed to fetch ${collection.id}: ${err.message}`);
    return { source, priceSats: null };
  }
}

// ─── Fetch All Sources ────────────────────────────────────────
/**
 * Fetch from all 4 sources in parallel for a single collection.
 * Returns array of { source, priceSats } — null prices for failed sources.
 */
export async function fetchAllSources(collection) {
  logger.info(`Fetching prices for: ${collection.name}`);

  const results = await Promise.allSettled([
    fetchMagicEden(collection),
    fetchOKX(collection),
    fetchUnisat(collection),
    fetchGamma(collection),
  ]);

  // allSettled never rejects — extract values (fetchers also never throw)
  return results.map((r) =>
    r.status === "fulfilled" ? r.value : { source: "unknown", priceSats: null }
  );
}
