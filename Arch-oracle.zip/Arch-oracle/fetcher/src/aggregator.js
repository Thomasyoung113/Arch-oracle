// ─────────────────────────────────────────────────────────────
// aggregator.js — Price aggregation logic
//
// Steps:
//   1. Remove nulls (failed fetches)
//   2. Sort prices
//   3. Remove outliers beyond 2 standard deviations from median
//   4. Return weighted median of clean prices
// ─────────────────────────────────────────────────────────────

import { logger } from "./logger.js";

/**
 * Compute the simple median of a sorted numeric array.
 */
export function median(sorted) {
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 !== 0
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2;
}

/**
 * Compute mean of an array.
 */
function mean(arr) {
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}

/**
 * Compute standard deviation of an array.
 */
function stdDev(arr) {
  const m = mean(arr);
  const variance = arr.reduce((sum, v) => sum + Math.pow(v - m, 2), 0) / arr.length;
  return Math.sqrt(variance);
}

/**
 * Remove outliers more than `threshold` standard deviations from the median.
 * Default threshold: 2.0
 */
export function removeOutliers(prices, threshold = 2.0) {
  if (prices.length <= 2) return prices; // not enough data to filter

  const sorted = [...prices].sort((a, b) => a - b);
  const med = median(sorted);
  const std = stdDev(sorted);

  const filtered = sorted.filter((p) => Math.abs(p - med) <= threshold * std);

  const removed = sorted.length - filtered.length;
  if (removed > 0) {
    logger.warn(`Outlier removal: dropped ${removed} price(s)`, {
      original: sorted,
      filtered,
      median: med,
      stdDev: std.toFixed(0),
    });
  }

  return filtered;
}

/**
 * Main aggregation function.
 * Takes raw price results from all sources, cleans them, returns final price.
 *
 * @param {Array<{source: string, priceSats: number|null}>} results
 * @param {string} collectionId - for logging only
 * @returns {{ priceSats: number, confidence: number, sources: string[] } | null}
 */
export function aggregate(results, collectionId) {
  // Step 1: Filter out failed fetches
  const valid = results.filter((r) => r.priceSats !== null && r.priceSats > 0);

  logger.debug(`[${collectionId}] Raw results`, results);

  if (valid.length < parseInt(process.env.MIN_SOURCES ?? "2")) {
    logger.warn(`[${collectionId}] Not enough valid sources (${valid.length}). Skipping.`);
    return null;
  }

  const prices = valid.map((r) => r.priceSats);
  const sources = valid.map((r) => r.source);

  // Step 2: Remove outliers
  const clean = removeOutliers(prices);

  if (clean.length === 0) {
    logger.error(`[${collectionId}] All prices were outliers. Skipping.`);
    return null;
  }

  // Step 3: Compute final median
  const sorted = [...clean].sort((a, b) => a - b);
  const finalPrice = Math.round(median(sorted));

  // Step 4: Confidence score (0-100) based on source agreement
  //   - All sources agree within 5% → 100
  //   - Large spread → lower confidence
  const spread = sorted[sorted.length - 1] - sorted[0];
  const spreadPct = (spread / finalPrice) * 100;
  const confidence = Math.max(0, Math.round(100 - spreadPct * 2));

  logger.info(`[${collectionId}] Aggregated price`, {
    priceSats: finalPrice,
    priceBTC: (finalPrice / 1e8).toFixed(6),
    sources,
    confidence,
    spreadPct: spreadPct.toFixed(1) + "%",
  });

  return { priceSats: finalPrice, confidence, sources };
}

/**
 * Check if a new price deviates too much from the last submitted price.
 * Returns true if the deviation is acceptable.
 */
export function isDeviationAcceptable(newPrice, lastPrice) {
  if (!lastPrice) return true; // no previous price, always acceptable

  const maxPct = parseFloat(process.env.MAX_DEVIATION_PCT ?? "20");
  const deviationPct = Math.abs((newPrice - lastPrice) / lastPrice) * 100;

  if (deviationPct > maxPct) {
    logger.warn(`Price deviation too high: ${deviationPct.toFixed(1)}% (max ${maxPct}%)`, {
      newPrice,
      lastPrice,
    });
    return false;
  }

  return true;
}
