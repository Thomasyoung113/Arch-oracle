// ─────────────────────────────────────────────────────────────
// signer.js — Signs price reports with oracle node keypair
//
// Uses Ed25519 (tweetnacl) — same curve Arch uses for signatures.
// The on-chain program verifies these signatures to authenticate
// that reports come from registered oracle nodes.
// ─────────────────────────────────────────────────────────────

import nacl from "tweetnacl";
import bs58 from "bs58";
import { logger } from "./logger.js";

/**
 * Load the oracle node keypair from the ORACLE_PRIVATE_KEY env var.
 * The private key is stored as base58-encoded 64 bytes (seed + pubkey).
 */
export function loadKeypair() {
  const raw = process.env.ORACLE_PRIVATE_KEY;
  if (!raw || raw === "your_base58_private_key_here") {
    throw new Error(
      "ORACLE_PRIVATE_KEY not set. Run `node src/keygen.js` to generate one."
    );
  }

  const bytes = bs58.decode(raw);
  if (bytes.length !== 64) {
    throw new Error(`Invalid key length: expected 64 bytes, got ${bytes.length}`);
  }

  const keyPair = nacl.sign.keyPair.fromSecretKey(bytes);
  const publicKey = bs58.encode(keyPair.publicKey);

  logger.info(`Oracle node loaded. Public key: ${publicKey}`);
  return keyPair;
}

/**
 * Build a canonical price report object.
 * This is exactly what gets signed and submitted on-chain.
 */
export function buildReport(collectionId, priceSats, confidence, sources) {
  return {
    collectionId,
    priceSats,
    confidence,
    sources,
    timestamp: Math.floor(Date.now() / 1000), // unix seconds
    version: 1,
  };
}

/**
 * Sign a report with the oracle node keypair.
 * Returns the report + base58-encoded signature.
 *
 * The on-chain program verifies:
 *   Ed25519.verify(signature, serialize(report), reporterPublicKey)
 */
export function signReport(report, keyPair) {
  // Canonical serialization — must match on-chain deserialization order
  const message = serializeReport(report);
  const messageBytes = new TextEncoder().encode(message);
  const signatureBytes = nacl.sign.detached(messageBytes, keyPair.secretKey);
  const signature = bs58.encode(signatureBytes);

  logger.debug("Report signed", { message, signature: signature.slice(0, 16) + "..." });

  return {
    report,
    signature,
    publicKey: bs58.encode(keyPair.publicKey),
  };
}

/**
 * Deterministic serialization of a report for signing.
 * Fields are sorted alphabetically to prevent ordering attacks.
 * Must exactly match the Rust deserialization on-chain.
 */
function serializeReport(report) {
  return JSON.stringify({
    collectionId: report.collectionId,
    confidence: report.confidence,
    priceSats: report.priceSats,
    sources: [...report.sources].sort(),
    timestamp: report.timestamp,
    version: report.version,
  });
}

/**
 * Verify a signed report locally (for testing).
 */
export function verifyReport(signedReport) {
  const { report, signature, publicKey } = signedReport;
  const message = serializeReport(report);
  const messageBytes = new TextEncoder().encode(message);
  const sigBytes = bs58.decode(signature);
  const pubKeyBytes = bs58.decode(publicKey);
  return nacl.sign.detached.verify(messageBytes, sigBytes, pubKeyBytes);
}
