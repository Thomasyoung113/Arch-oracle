# Arch Oracle 🔮

> The first decentralized floor price oracle for Ordinals on Arch Network.

Bitcoin-native. Trustless. Multi-source. Built for DeFi.

---

## What Is This?

Arch Oracle provides on-chain floor price feeds for Ordinals collections — enabling lending protocols, DEXes, and liquidation bots to safely use Ordinals as collateral on Arch Network.

**The problem it solves:** Arch Network's own docs confirm no decentralized oracle exists yet. Without one, billions in Ordinals value can't participate in Bitcoin DeFi.

---

## Repo Structure

```
/fetcher          Off-chain price aggregator (Node.js/TypeScript)
/oracle-program   On-chain Arch oracle program (Rust)
/sdk              TypeScript SDK for consumer protocols
/website          Marketing site + live feed (Next.js → Vercel)
```

---

## Quick Start

### 1. Fetcher Bot (off-chain)

```bash
cd fetcher
npm install
cp .env.example .env     # fill in your keys
node src/keygen.js       # generate oracle node keypair
npm test                 # run unit tests
npm run fetch-once       # single fetch round
npm start                # continuous loop (every 10 min)
```

### 2. Oracle Program (on-chain Rust)

```bash
cd oracle-program
cargo test               # run tests
cargo build --release    # build for deploy

# Deploy to Arch testnet
arch-cli program deploy \
  --program-keypair oracle-keypair.json \
  --program-path target/release/ordinals_oracle.so \
  --network testnet
```

### 3. SDK (for consuming protocols)

```bash
cd sdk
npm install
node src/test.js         # unit tests
```

```typescript
import { OracleClient } from "@ordinals-oracle/sdk";

const oracle = new OracleClient({
  network:   "testnet",
  programId: "YOUR_PROGRAM_ID",
});

const price = await oracle.getPrice("node-monkes");
console.log(price.priceBTC);   // "0.045000"
console.log(price.isFresh);    // true
```

### 4. Website

```bash
cd website
npm install
npm run dev              # localhost:3000
npm run build            # static export for Vercel
```

---

## Architecture

```
Every 10 minutes:
  Off-chain bots fetch from 4 marketplaces
        │
        ▼  (signed Ed25519 reports)
  Arch oracle program
    • Verifies signatures
    • Removes outliers (>2 std dev)
    • Computes weighted median
    • Requires 3+ reporter quorum
    • Writes price to on-chain UTXO state
        │
        ▼
  Downstream protocols read via SDK
    • Lending protocols → LTV calculation
    • DEXes → price validation
    • Liquidation bots → health factor monitoring
```

## Data Sources

| Source | Type | Notes |
|---|---|---|
| Magic Eden | REST API | Largest BTC NFT volume |
| OKX NFT | REST API | Institutional liquidity |
| Unisat | REST API | Community data |
| Gamma.io | REST API | Decentralized marketplace |

---

## Collections Supported

- NodeMonkes (`node-monkes`)
- Bitcoin Puppets (`bitcoin-puppets`)
- Ordinal Maxi Biz (`ordinal-maxi-biz`)
- Runestones (`runestones`)
- Bitcoin Frogs (`bitcoin-frogs`)

---

## Roadmap

- [x] Fetcher bot (multi-source aggregation)
- [x] Rust oracle program (on-chain Arch)
- [x] TypeScript SDK
- [x] Website (Next.js)
- [ ] Arch testnet deploy
- [ ] Integrate with Autara / Ordeez lending protocols
- [ ] Token-based oracle node rewards
- [ ] TWAP (time-weighted average price)
- [ ] Mainnet launch
- [ ] Apply to Arch Keystone Accelerator ($250k grant)

---

## License

MIT
