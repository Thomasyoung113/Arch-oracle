// ─────────────────────────────────────────────────────────────
// lib.rs — Ordinals Price Oracle Program
//
// Arch Network on-chain program.
// Aggregates floor price reports from registered oracle nodes
// and exposes a verified, on-chain price feed for Ordinals.
//
// Deploy: arch-cli program deploy --program-keypair oracle-keypair.json
// ─────────────────────────────────────────────────────────────

use arch_program::{
    account::AccountInfo,
    clock::Clock,
    entrypoint,
    msg,
    program_error::ProgramError,
    pubkey::Pubkey,
    sysvar::Sysvar,
};
use borsh::{BorshDeserialize, BorshSerialize};
use ed25519_dalek::{Signature, VerifyingKey};

mod error;
mod instructions;
mod math;
mod state;

use error::OracleError;
use instructions::OracleInstruction;
use math::aggregate_reports;
use state::{OracleState, PendingPool, PriceReport, ReporterRegistry};

// ─── Program Entrypoint ───────────────────────────────────────
entrypoint!(process_instruction);

pub fn process_instruction(
    program_id: &Pubkey,
    accounts: &[AccountInfo],
    instruction_data: &[u8],
) -> Result<(), ProgramError> {
    let instruction = OracleInstruction::try_from_slice(instruction_data)
        .map_err(|_| ProgramError::InvalidInstructionData)?;

    match instruction {
        OracleInstruction::InitializeRegistry => {
            msg!("Oracle: InitializeRegistry");
            process_initialize_registry(program_id, accounts)
        }
        OracleInstruction::AddReporter { reporter_pubkey } => {
            msg!("Oracle: AddReporter");
            process_add_reporter(program_id, accounts, reporter_pubkey)
        }
        OracleInstruction::RemoveReporter { reporter_pubkey } => {
            msg!("Oracle: RemoveReporter");
            process_remove_reporter(program_id, accounts, reporter_pubkey)
        }
        OracleInstruction::InitializeCollection { collection_id } => {
            msg!("Oracle: InitializeCollection {}", collection_id);
            process_initialize_collection(program_id, accounts, collection_id)
        }
        OracleInstruction::SubmitPrice {
            collection_id,
            price_sats,
            confidence,
            source_count,
            timestamp,
            signature,
        } => {
            msg!("Oracle: SubmitPrice {} @ {} sats", collection_id, price_sats);
            process_submit_price(
                program_id,
                accounts,
                collection_id,
                price_sats,
                confidence,
                source_count,
                timestamp,
                signature,
            )
        }
        OracleInstruction::GetFloorPrice { collection_id } => {
            msg!("Oracle: GetFloorPrice {}", collection_id);
            process_get_floor_price(program_id, accounts, collection_id)
        }
    }
}

// ─── InitializeRegistry ───────────────────────────────────────
fn process_initialize_registry(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
) -> Result<(), ProgramError> {
    let admin    = &accounts[0];
    let registry = &accounts[1];

    require!(admin.is_signer, OracleError::UnauthorizedAdmin);
    require!(!registry.data_is_empty(), OracleError::AccountTooSmall);

    let existing = ReporterRegistry::try_from_slice(&registry.data.borrow());
    if let Ok(r) = existing {
        if r.is_initialized {
            return Err(OracleError::AlreadyInitialized.into());
        }
    }

    let reg = ReporterRegistry::new(admin.key.to_bytes(), 0);
    reg.serialize(&mut *registry.data.borrow_mut())
        .map_err(|_| ProgramError::AccountDataTooSmall)?;

    msg!("Registry initialized. Admin: {:?}", admin.key);
    Ok(())
}

// ─── AddReporter ─────────────────────────────────────────────
fn process_add_reporter(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    reporter_pubkey: [u8; 32],
) -> Result<(), ProgramError> {
    let admin        = &accounts[0];
    let registry_acc = &accounts[1];

    require!(admin.is_signer, OracleError::UnauthorizedAdmin);

    let mut registry = ReporterRegistry::try_from_slice(&registry_acc.data.borrow())
        .map_err(|_| ProgramError::InvalidAccountData)?;

    require!(registry.is_initialized, OracleError::NotInitialized);
    require!(registry.admin == admin.key.to_bytes(), OracleError::UnauthorizedAdmin);

    registry.add_reporter(reporter_pubkey);
    registry
        .serialize(&mut *registry_acc.data.borrow_mut())
        .map_err(|_| ProgramError::AccountDataTooSmall)?;

    msg!("Reporter registered: {:?}", reporter_pubkey);
    Ok(())
}

// ─── RemoveReporter ───────────────────────────────────────────
fn process_remove_reporter(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    reporter_pubkey: [u8; 32],
) -> Result<(), ProgramError> {
    let admin        = &accounts[0];
    let registry_acc = &accounts[1];

    require!(admin.is_signer, OracleError::UnauthorizedAdmin);

    let mut registry = ReporterRegistry::try_from_slice(&registry_acc.data.borrow())
        .map_err(|_| ProgramError::InvalidAccountData)?;

    require!(registry.admin == admin.key.to_bytes(), OracleError::UnauthorizedAdmin);
    registry.remove_reporter(&reporter_pubkey);

    registry
        .serialize(&mut *registry_acc.data.borrow_mut())
        .map_err(|_| ProgramError::AccountDataTooSmall)?;

    msg!("Reporter removed");
    Ok(())
}

// ─── InitializeCollection ─────────────────────────────────────
fn process_initialize_collection(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    collection_id: String,
) -> Result<(), ProgramError> {
    let admin        = &accounts[0];
    let oracle_acc   = &accounts[1];
    let pool_acc     = &accounts[2];

    require!(admin.is_signer, OracleError::UnauthorizedAdmin);

    // Initialize OracleState
    let existing = OracleState::try_from_slice(&oracle_acc.data.borrow());
    if let Ok(s) = existing {
        require!(!s.is_initialized, OracleError::AlreadyInitialized);
    }
    let oracle_state = OracleState::new(collection_id.clone(), 0);
    oracle_state
        .serialize(&mut *oracle_acc.data.borrow_mut())
        .map_err(|_| ProgramError::AccountDataTooSmall)?;

    // Initialize PendingPool
    let pool = PendingPool::new(collection_id.clone(), 0);
    pool.serialize(&mut *pool_acc.data.borrow_mut())
        .map_err(|_| ProgramError::AccountDataTooSmall)?;

    msg!("Collection initialized: {}", collection_id);
    Ok(())
}

// ─── SubmitPrice ──────────────────────────────────────────────
fn process_submit_price(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    collection_id: String,
    price_sats: u64,
    confidence: u8,
    source_count: u8,
    timestamp: u64,
    signature: [u8; 64],
) -> Result<(), ProgramError> {
    let reporter     = &accounts[0];
    let registry_acc = &accounts[1];
    let pool_acc     = &accounts[2];
    let oracle_acc   = &accounts[3];

    // 1. Check reporter is a signer
    require!(reporter.is_signer, OracleError::UnauthorizedReporter);

    // 2. Check reporter is registered
    let registry = ReporterRegistry::try_from_slice(&registry_acc.data.borrow())
        .map_err(|_| ProgramError::InvalidAccountData)?;
    let reporter_bytes = reporter.key.to_bytes();
    require!(
        registry.is_registered(&reporter_bytes),
        OracleError::UnauthorizedReporter
    );

    // 3. Validate price
    require!(price_sats > 0, OracleError::InvalidPrice);

    // 4. Validate timestamp (must be within 5 minutes of current time)
    let clock = Clock::get().map_err(|_| ProgramError::InvalidArgument)?;
    let now = clock.unix_timestamp as u64;
    require!(timestamp <= now + 60, OracleError::FutureTimestamp);     // max 1 min future
    require!(now.saturating_sub(timestamp) <= 300, OracleError::StaleReport); // max 5 min old

    // 5. Verify Ed25519 signature over canonical report bytes
    verify_report_signature(
        &reporter_bytes,
        &collection_id,
        price_sats,
        confidence,
        timestamp,
        &signature,
    )?;

    // 6. Add to pending pool
    let mut pool = PendingPool::try_from_slice(&pool_acc.data.borrow())
        .map_err(|_| ProgramError::InvalidAccountData)?;

    require!(pool.collection_id == collection_id, OracleError::CollectionMismatch);

    let report = PriceReport {
        reporter_pubkey: reporter_bytes,
        price_sats,
        confidence,
        source_count,
        timestamp,
    };
    pool.add_report(report);

    // 7. If quorum reached → aggregate and publish
    if pool.has_quorum() {
        msg!("Quorum reached ({} reports) — aggregating...", pool.reports.len());

        let (final_price, final_confidence) = aggregate_reports(&pool.reports)
            .map_err(ProgramError::from)?;

        let mut oracle_state = OracleState::try_from_slice(&oracle_acc.data.borrow())
            .map_err(|_| ProgramError::InvalidAccountData)?;

        oracle_state.prev_price_sats  = oracle_state.floor_price_sats;
        oracle_state.floor_price_sats = final_price;
        oracle_state.last_updated     = now;
        oracle_state.reporter_count   = pool.reports.len() as u8;
        oracle_state.confidence       = final_confidence;

        oracle_state
            .serialize(&mut *oracle_acc.data.borrow_mut())
            .map_err(|_| ProgramError::AccountDataTooSmall)?;

        // Clear the pool for next round
        pool.clear();
        pool.round_started = 0;

        msg!(
            "Price published: {} sats (confidence: {}%)",
            final_price,
            final_confidence
        );
    } else {
        msg!(
            "Report accepted ({}/{}). Waiting for more reporters.",
            pool.reports.len(),
            PendingPool::MIN_QUORUM
        );
    }

    // Save pool state
    pool.serialize(&mut *pool_acc.data.borrow_mut())
        .map_err(|_| ProgramError::AccountDataTooSmall)?;

    Ok(())
}

// ─── GetFloorPrice ────────────────────────────────────────────
fn process_get_floor_price(
    _program_id: &Pubkey,
    accounts: &[AccountInfo],
    collection_id: String,
) -> Result<(), ProgramError> {
    let oracle_acc = &accounts[0];

    let state = OracleState::try_from_slice(&oracle_acc.data.borrow())
        .map_err(|_| ProgramError::InvalidAccountData)?;

    require!(state.is_initialized, OracleError::NotInitialized);
    require!(state.collection_id == collection_id, OracleError::CollectionMismatch);

    if state.last_updated == 0 {
        return Err(OracleError::PriceFeedEmpty.into());
    }

    let clock = Clock::get().map_err(|_| ProgramError::InvalidArgument)?;
    let now = clock.unix_timestamp as u64;

    require!(state.is_fresh(now), OracleError::PriceFeedStale);

    // Log the price so callers can read it from transaction logs
    msg!(
        "ORACLE_PRICE collection={} price_sats={} confidence={} last_updated={} reporter_count={}",
        state.collection_id,
        state.floor_price_sats,
        state.confidence,
        state.last_updated,
        state.reporter_count,
    );

    Ok(())
}

// ─── Signature Verification ───────────────────────────────────
/// Verify that the price report was signed by the reporting oracle node.
/// The message format must exactly match the JS signer (signer.js).
fn verify_report_signature(
    reporter_pubkey: &[u8; 32],
    collection_id: &str,
    price_sats: u64,
    confidence: u8,
    timestamp: u64,
    signature_bytes: &[u8; 64],
) -> Result<(), ProgramError> {
    // Reconstruct the canonical message (must match signer.js serializeReport)
    // Format: JSON with fields sorted alphabetically
    let message = format!(
        r#"{{"collectionId":"{collection_id}","confidence":{confidence},"priceSats":{price_sats},"timestamp":{timestamp},"version":1}}"#
    );

    let verifying_key = VerifyingKey::from_bytes(reporter_pubkey)
        .map_err(|_| ProgramError::from(OracleError::InvalidSignature))?;

    let signature = Signature::from_bytes(signature_bytes);

    use ed25519_dalek::Verifier;
    verifying_key
        .verify(message.as_bytes(), &signature)
        .map_err(|_| ProgramError::from(OracleError::InvalidSignature))?;

    Ok(())
}

// ─── Helper macro ─────────────────────────────────────────────
/// require!(condition, error) — Returns error if condition is false.
macro_rules! require {
    ($condition:expr, $error:expr) => {
        if !($condition) {
            return Err(ProgramError::from($error));
        }
    };
}
use require;
