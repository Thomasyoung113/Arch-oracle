// ─────────────────────────────────────────────────────────────
// state.rs — On-chain account structures
//
// These structs are stored in Arch UTXO accounts as Borsh-encoded bytes.
// Every field must be serializable — no heap-allocated types except String/Vec.
// ─────────────────────────────────────────────────────────────

use borsh::{BorshDeserialize, BorshSerialize};

// ─── Oracle State ─────────────────────────────────────────────
/// The main state account for a single collection's price feed.
/// One OracleState account exists per tracked collection (e.g. "node-monkes").
/// Stored at a PDA derived from: ["oracle", collection_id]
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct OracleState {
    /// The collection identifier (e.g. "node-monkes")
    pub collection_id: String,

    /// Current aggregated floor price in satoshis
    pub floor_price_sats: u64,

    /// Unix timestamp (seconds) when the price was last updated
    pub last_updated: u64,

    /// Number of oracle nodes that contributed to the current price
    pub reporter_count: u8,

    /// Confidence score 0–100 (higher = tighter agreement between sources)
    pub confidence: u8,

    /// Previous price (for deviation tracking by consumers)
    pub prev_price_sats: u64,

    /// Whether this oracle account has been initialized
    pub is_initialized: bool,

    /// Bump seed for the PDA (stored to avoid recomputation)
    pub bump: u8,

    /// Version for future upgrades
    pub version: u8,
}

impl OracleState {
    pub const VERSION: u8 = 1;

    /// Max age of a price in seconds before it's considered stale (30 minutes)
    pub const MAX_AGE_SECS: u64 = 1800;

    pub fn new(collection_id: String, bump: u8) -> Self {
        Self {
            collection_id,
            floor_price_sats: 0,
            last_updated: 0,
            reporter_count: 0,
            confidence: 0,
            prev_price_sats: 0,
            is_initialized: true,
            bump,
            version: Self::VERSION,
        }
    }

    /// Returns true if the stored price is fresh enough to use
    pub fn is_fresh(&self, current_time: u64) -> bool {
        if self.last_updated == 0 {
            return false; // never updated
        }
        current_time.saturating_sub(self.last_updated) <= Self::MAX_AGE_SECS
    }
}

// ─── Pending Submission Pool ──────────────────────────────────
/// A single price report submitted by one oracle node.
/// Multiple reporters submit to a shared pending pool account.
/// When quorum is reached, the program aggregates and publishes.
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct PriceReport {
    /// The oracle node's public key (32 bytes)
    pub reporter_pubkey: [u8; 32],

    /// Floor price in satoshis as reported by this node
    pub price_sats: u64,

    /// Confidence score from the off-chain aggregator (0–100)
    pub confidence: u8,

    /// Number of off-chain sources used
    pub source_count: u8,

    /// Submission timestamp (unix seconds)
    pub timestamp: u64,
}

/// Pool of pending price reports waiting for quorum.
/// One PendingPool account exists per collection, cleared after aggregation.
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct PendingPool {
    pub collection_id: String,
    pub reports: Vec<PriceReport>,
    pub round_started: u64,
    pub is_initialized: bool,
    pub bump: u8,
}

impl PendingPool {
    /// Minimum number of oracle nodes needed before aggregation fires
    pub const MIN_QUORUM: usize = 3;

    pub fn new(collection_id: String, bump: u8) -> Self {
        Self {
            collection_id,
            reports: Vec::new(),
            round_started: 0,
            is_initialized: true,
            bump,
        }
    }

    pub fn add_report(&mut self, report: PriceReport) {
        // Prevent duplicate submissions from same reporter in same round
        self.reports.retain(|r| r.reporter_pubkey != report.reporter_pubkey);
        self.reports.push(report);
    }

    pub fn has_quorum(&self) -> bool {
        self.reports.len() >= Self::MIN_QUORUM
    }

    pub fn clear(&mut self) {
        self.reports.clear();
    }
}

// ─── Reporter Registry ────────────────────────────────────────
/// Registry of authorised oracle node public keys.
/// Only registered reporters can submit price reports.
/// Controlled by the oracle admin (you, initially).
#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub struct ReporterRegistry {
    /// Admin pubkey — can add/remove reporters
    pub admin: [u8; 32],

    /// List of authorized oracle node public keys
    pub reporters: Vec<[u8; 32]>,

    pub is_initialized: bool,
    pub bump: u8,
}

impl ReporterRegistry {
    pub fn new(admin: [u8; 32], bump: u8) -> Self {
        Self {
            admin,
            reporters: Vec::new(),
            is_initialized: true,
            bump,
        }
    }

    pub fn is_registered(&self, pubkey: &[u8; 32]) -> bool {
        self.reporters.iter().any(|r| r == pubkey)
    }

    pub fn add_reporter(&mut self, pubkey: [u8; 32]) -> bool {
        if self.is_registered(&pubkey) {
            return false; // already registered
        }
        self.reporters.push(pubkey);
        true
    }

    pub fn remove_reporter(&mut self, pubkey: &[u8; 32]) -> bool {
        let before = self.reporters.len();
        self.reporters.retain(|r| r != pubkey);
        self.reporters.len() < before
    }
}
