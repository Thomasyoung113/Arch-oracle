// ─────────────────────────────────────────────────────────────
// math.rs — On-chain aggregation math (no_std safe)
//
// All arithmetic uses integer math — no floats on-chain.
// Standard deviations are approximated with integer square roots.
// ─────────────────────────────────────────────────────────────

use crate::error::OracleError;
use crate::state::PriceReport;

/// Compute the integer square root (floor) using Newton's method.
/// Used in std_dev calculation without floating point.
fn isqrt(n: u64) -> u64 {
    if n == 0 {
        return 0;
    }
    let mut x = n;
    let mut y = (x + 1) / 2;
    while y < x {
        x = y;
        y = (x + n / x) / 2;
    }
    x
}

/// Compute the median of a sorted slice of u64 prices.
/// Assumes the input is already sorted ascending.
pub fn median_sorted(sorted: &[u64]) -> u64 {
    let len = sorted.len();
    if len == 0 {
        return 0;
    }
    if len % 2 == 1 {
        sorted[len / 2]
    } else {
        // Average of two middle values (integer, no rounding error)
        (sorted[len / 2 - 1] + sorted[len / 2]) / 2
    }
}

/// Compute mean of a slice (integer division, truncates).
pub fn mean(prices: &[u64]) -> u64 {
    if prices.is_empty() {
        return 0;
    }
    prices.iter().sum::<u64>() / prices.len() as u64
}

/// Compute approximate standard deviation using integer arithmetic.
/// Returns variance * 1000 to preserve precision without floats.
pub fn std_dev_approx(prices: &[u64], m: u64) -> u64 {
    if prices.len() < 2 {
        return 0;
    }
    let variance_sum: u64 = prices
        .iter()
        .map(|&p| {
            let diff = if p > m { p - m } else { m - p };
            diff.saturating_mul(diff)
        })
        .sum();
    let variance = variance_sum / prices.len() as u64;
    isqrt(variance)
}

/// Remove statistical outliers from a sorted price slice.
///
/// Definition of outlier: |price - median| > threshold * std_dev
/// We use threshold = 2 (2 standard deviations).
///
/// Returns the filtered prices (still sorted).
pub fn remove_outliers(sorted: &[u64]) -> Vec<u64> {
    if sorted.len() <= 2 {
        // Not enough data to detect outliers — return as-is
        return sorted.to_vec();
    }

    let med = median_sorted(sorted);
    let std = std_dev_approx(sorted, med);

    // Threshold: 2 standard deviations
    // If std_dev is very small (tight cluster), allow at least 0.5% deviation
    let threshold = std.max(med / 200);

    sorted
        .iter()
        .copied()
        .filter(|&p| {
            let diff = if p > med { p - med } else { med - p };
            diff <= 2 * threshold
        })
        .collect()
}

/// Main aggregation: take reports, clean them, return final price.
///
/// Steps:
///   1. Sort prices from all reporters
///   2. Remove statistical outliers
///   3. Compute weighted median (weight by confidence score)
///   4. Return aggregated result
pub fn aggregate_reports(reports: &[PriceReport]) -> Result<(u64, u8), OracleError> {
    if reports.is_empty() {
        return Err(OracleError::InsufficientQuorum);
    }

    // Step 1: Extract and sort prices
    let mut prices: Vec<u64> = reports.iter().map(|r| r.price_sats).collect();
    prices.sort_unstable();

    // Step 2: Remove outliers
    let clean = remove_outliers(&prices);

    if clean.is_empty() {
        return Err(OracleError::AllOutliers);
    }

    // Step 3: Compute weighted median
    // Weight each price by the reporter's confidence score
    // Simple approach: find the price closest to the confidence-weighted mean
    let conf_weighted_sum: u64 = reports
        .iter()
        .filter(|r| clean.contains(&r.price_sats))
        .map(|r| r.price_sats.saturating_mul(r.confidence as u64))
        .sum();

    let total_confidence: u64 = reports
        .iter()
        .filter(|r| clean.contains(&r.price_sats))
        .map(|r| r.confidence as u64)
        .sum();

    let weighted_mean = if total_confidence > 0 {
        conf_weighted_sum / total_confidence
    } else {
        median_sorted(&clean) // fallback to simple median
    };

    // Final price: the clean price closest to the weighted mean
    let final_price = clean
        .iter()
        .min_by_key(|&&p| {
            let diff = if p > weighted_mean { p - weighted_mean } else { weighted_mean - p };
            diff
        })
        .copied()
        .unwrap_or(median_sorted(&clean));

    // Step 4: Compute confidence score
    // Based on spread of clean prices relative to final price
    let spread = clean.last().unwrap_or(&0).saturating_sub(*clean.first().unwrap_or(&0));
    let spread_pct = if final_price > 0 {
        (spread * 100) / final_price
    } else {
        100
    };
    // Confidence: 100 - (spread_pct * 2), clamped to 0-100
    let confidence = (100u64.saturating_sub(spread_pct * 2)).min(100) as u8;

    Ok((final_price, confidence))
}

// ─── Tests ────────────────────────────────────────────────────
#[cfg(test)]
mod tests {
    use super::*;

    fn make_report(price: u64, confidence: u8) -> PriceReport {
        PriceReport {
            reporter_pubkey: [0u8; 32],
            price_sats: price,
            confidence,
            source_count: 3,
            timestamp: 0,
        }
    }

    #[test]
    fn test_median_odd() {
        assert_eq!(median_sorted(&[1, 3, 5]), 3);
    }

    #[test]
    fn test_median_even() {
        assert_eq!(median_sorted(&[1, 3, 5, 7]), 4);
    }

    #[test]
    fn test_isqrt() {
        assert_eq!(isqrt(0), 0);
        assert_eq!(isqrt(1), 1);
        assert_eq!(isqrt(9), 3);
        assert_eq!(isqrt(16), 4);
        assert_eq!(isqrt(100), 10);
    }

    #[test]
    fn test_outlier_removal_catches_extreme() {
        // 50_000_000 is a massive outlier vs 4_000_000 cluster
        let prices = vec![3_900_000, 4_000_000, 4_100_000, 50_000_000];
        let clean = remove_outliers(&prices);
        assert!(!clean.contains(&50_000_000), "Extreme outlier should be removed");
    }

    #[test]
    fn test_outlier_removal_keeps_tight_cluster() {
        let prices = vec![3_950_000, 4_000_000, 4_020_000, 4_050_000];
        let clean = remove_outliers(&prices);
        assert_eq!(clean.len(), 4, "No outliers in tight cluster");
    }

    #[test]
    fn test_aggregate_happy_path() {
        let reports = vec![
            make_report(4_000_000, 90),
            make_report(4_100_000, 85),
            make_report(3_950_000, 88),
            make_report(4_020_000, 92),
        ];
        let (price, confidence) = aggregate_reports(&reports).unwrap();
        assert!(price >= 3_950_000 && price <= 4_100_000);
        assert!(confidence > 50, "Confidence should be decent with tight prices");
    }

    #[test]
    fn test_aggregate_empty_returns_error() {
        let result = aggregate_reports(&[]);
        assert_eq!(result, Err(OracleError::InsufficientQuorum));
    }
}
