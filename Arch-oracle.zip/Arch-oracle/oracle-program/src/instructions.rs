// ─────────────────────────────────────────────────────────────
// instructions.rs — Program instruction definitions
//
// Each variant maps to one callable action on the oracle program.
// Callers serialize these with Borsh and pass as instruction data.
// ─────────────────────────────────────────────────────────────

use borsh::{BorshDeserialize, BorshSerialize};

#[derive(BorshSerialize, BorshDeserialize, Debug, Clone)]
pub enum OracleInstruction {
    /// [Admin only] Initialize the reporter registry.
    /// Call once after deploying the program.
    ///
    /// Accounts:
    ///   0. [signer, writable] Admin account
    ///   1. [writable]         Registry account (PDA: ["registry"])
    ///   2. []                 System program
    InitializeRegistry,

    /// [Admin only] Register a new oracle node as an authorized reporter.
    ///
    /// Accounts:
    ///   0. [signer] Admin account
    ///   1. [writable] Registry account (PDA: ["registry"])
    AddReporter {
        /// Public key of the oracle node to register (32 bytes)
        reporter_pubkey: [u8; 32],
    },

    /// [Admin only] Remove an oracle node from the authorized list.
    ///
    /// Accounts:
    ///   0. [signer] Admin account
    ///   1. [writable] Registry account (PDA: ["registry"])
    RemoveReporter {
        reporter_pubkey: [u8; 32],
    },

    /// [Admin only] Initialize a price feed for a new collection.
    /// Creates the OracleState and PendingPool accounts.
    ///
    /// Accounts:
    ///   0. [signer, writable] Admin account
    ///   1. [writable]         OracleState account (PDA: ["oracle", collection_id])
    ///   2. [writable]         PendingPool account (PDA: ["pool", collection_id])
    ///   3. []                 System program
    InitializeCollection {
        collection_id: String,
    },

    /// [Registered reporter] Submit a price report for a collection.
    /// When quorum is reached, automatically triggers aggregation.
    ///
    /// Accounts:
    ///   0. [signer]   Reporter account
    ///   1. []         Registry account (PDA: ["registry"]) — for auth check
    ///   2. [writable] PendingPool account (PDA: ["pool", collection_id])
    ///   3. [writable] OracleState account (PDA: ["oracle", collection_id])
    SubmitPrice {
        collection_id: String,
        price_sats:    u64,
        confidence:    u8,
        source_count:  u8,
        timestamp:     u64,
        /// Ed25519 signature over the canonical report bytes
        /// Verified on-chain against the reporter's registered pubkey
        signature:     [u8; 64],
    },

    /// [Any caller] Read the current floor price for a collection.
    /// Returns OracleState data. Reverts if price is stale (>30 min).
    ///
    /// Accounts:
    ///   0. [] OracleState account (PDA: ["oracle", collection_id])
    GetFloorPrice {
        collection_id: String,
    },
}
