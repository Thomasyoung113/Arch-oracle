// ─────────────────────────────────────────────────────────────
// error.rs — Custom error types for the oracle program
// ─────────────────────────────────────────────────────────────

use arch_program::program_error::ProgramError;
use thiserror::Error;

#[derive(Error, Debug, Clone, PartialEq)]
pub enum OracleError {
    // ─── Initialization ───────────────────────────────────────
    #[error("Account is already initialized")]
    AlreadyInitialized,

    #[error("Account has not been initialized")]
    NotInitialized,

    // ─── Authorization ────────────────────────────────────────
    #[error("Reporter is not registered")]
    UnauthorizedReporter,

    #[error("Signer is not the admin")]
    UnauthorizedAdmin,

    #[error("Invalid signature on price report")]
    InvalidSignature,

    // ─── Price Submission ─────────────────────────────────────
    #[error("Price report timestamp is too old (>5 minutes)")]
    StaleReport,

    #[error("Price report timestamp is in the future")]
    FutureTimestamp,

    #[error("Reporter already submitted in this round")]
    DuplicateSubmission,

    #[error("Price value is zero or negative")]
    InvalidPrice,

    // ─── Aggregation ──────────────────────────────────────────
    #[error("Not enough reporters for quorum")]
    InsufficientQuorum,

    #[error("All submissions were outliers — cannot aggregate")]
    AllOutliers,

    // ─── Reading ──────────────────────────────────────────────
    #[error("Price feed is stale — no update in 30 minutes")]
    PriceFeedStale,

    #[error("Price feed has never been updated")]
    PriceFeedEmpty,

    // ─── Account ──────────────────────────────────────────────
    #[error("Wrong collection ID for this account")]
    CollectionMismatch,

    #[error("Account data is too small to hold state")]
    AccountTooSmall,
}

// Allow OracleError to be returned as ProgramError
impl From<OracleError> for ProgramError {
    fn from(e: OracleError) -> Self {
        // Encode our custom errors as ProgramError::Custom with a unique code
        let code = match e {
            OracleError::AlreadyInitialized       => 1000,
            OracleError::NotInitialized           => 1001,
            OracleError::UnauthorizedReporter     => 1002,
            OracleError::UnauthorizedAdmin        => 1003,
            OracleError::InvalidSignature         => 1004,
            OracleError::StaleReport              => 1005,
            OracleError::FutureTimestamp          => 1006,
            OracleError::DuplicateSubmission      => 1007,
            OracleError::InvalidPrice             => 1008,
            OracleError::InsufficientQuorum       => 1009,
            OracleError::AllOutliers              => 1010,
            OracleError::PriceFeedStale           => 1011,
            OracleError::PriceFeedEmpty           => 1012,
            OracleError::CollectionMismatch       => 1013,
            OracleError::AccountTooSmall          => 1014,
        };
        ProgramError::Custom(code)
    }
}
