# Ordinals Oracle — Arch Network Program (Rust)

On-chain oracle program deployed to Arch Network testnet.
Verifies price reports from oracle nodes, aggregates them, and exposes a trustless floor price feed for Ordinals collections.

## Prerequisites

```bash
# Install Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Install Arch CLI
cargo install arch-cli

# Add WebAssembly target (Arch compiles to WASM under the hood)
rustup target add wasm32-unknown-unknown
```

## Build

```bash
# Debug build (faster, for testing)
cargo build

# Release build (optimised, for deployment)
cargo build --release

# Run unit tests (no network needed)
cargo test
```

## Deploy to Arch Testnet

```bash
# 1. Generate a program keypair (do once)
arch-cli keygen --output oracle-keypair.json

# 2. Fund the deployer account with testnet BTC
#    Get testnet BTC from: https://faucet.arch.network

# 3. Deploy the compiled program
arch-cli program deploy \
  --program-keypair oracle-keypair.json \
  --program-path target/release/ordinals_oracle.so \
  --network testnet

# The CLI will print your PROGRAM_ID — copy it to the fetcher bot's .env

# 4. Initialize the registry (run once after deploy)
arch-cli program call \
  --program-id <PROGRAM_ID> \
  --instruction InitializeRegistry \
  --network testnet

# 5. Register your oracle node's public key
arch-cli program call \
  --program-id <PROGRAM_ID> \
  --instruction AddReporter \
  --args '{"reporter_pubkey": "<YOUR_ORACLE_NODE_PUBKEY>"}' \
  --network testnet

# 6. Initialize each collection you want to track
arch-cli program call \
  --program-id <PROGRAM_ID> \
  --instruction InitializeCollection \
  --args '{"collection_id": "node-monkes"}' \
  --network testnet
```

## Program Architecture

```
src/
  lib.rs            ← Entrypoint + instruction dispatcher
  state.rs          ← OracleState, PendingPool, ReporterRegistry structs
  instructions.rs   ← Instruction enum (all callable actions)
  math.rs           ← Median, outlier removal, weighted aggregation
  error.rs          ← Custom error codes
```

## Instructions

| Instruction | Who Can Call | What It Does |
|---|---|---|
| `InitializeRegistry` | Admin (once) | Creates the reporter whitelist |
| `AddReporter` | Admin | Registers an oracle node's pubkey |
| `RemoveReporter` | Admin | Removes a bad/inactive oracle node |
| `InitializeCollection` | Admin | Creates price feed for a collection |
| `SubmitPrice` | Registered reporters | Submits a signed price report |
| `GetFloorPrice` | Anyone | Reads current price (reverts if stale) |

## How SubmitPrice Works

```
Reporter calls SubmitPrice(collection_id, price_sats, signature)
  │
  ├─ Verify reporter is registered (registry check)
  ├─ Verify timestamp is fresh (<5 min old)
  ├─ Verify Ed25519 signature (proves reporter signed the data)
  ├─ Add to pending pool
  │
  └─ If pool has ≥3 reports → AGGREGATE
       ├─ Sort all reported prices
       ├─ Remove outliers (>2 std dev from median)
       ├─ Compute weighted median (weight by confidence)
       ├─ Write final price to OracleState account
       └─ Clear pending pool for next round
```

## Reading the Oracle (from another Arch program)

```rust
// In your lending/DEX program — import and call GetFloorPrice
use arch_program::{account::AccountInfo, pubkey::Pubkey};

pub fn get_ordinals_floor_price(
    oracle_program_id: &Pubkey,
    oracle_state_account: &AccountInfo,
    collection_id: &str,
) -> Result<u64, ProgramError> {
    // CPI (Cross-Program Invocation) to the oracle program
    let instruction = OracleInstruction::GetFloorPrice {
        collection_id: collection_id.to_string(),
    };
    // ... invoke and parse the returned price from logs
    // See Arch docs on CPI for full implementation
}
```

## SDK Integration (for off-chain consumers)

```typescript
// Read oracle price from your TypeScript app
import { ArchRPC } from "@arch-network/sdk";

const rpc = new ArchRPC("https://rpc.testnet.arch.network");

const price = await rpc.callProgram({
  programId: ORACLE_PROGRAM_ID,
  instruction: "GetFloorPrice",
  args: { collection_id: "node-monkes" },
  accounts: [{ pubkey: ORACLE_STATE_ACCOUNT, isSigner: false, isWritable: false }],
});

console.log(`NodeMonkes floor: ${price} sats`);
```

## Security Notes

- **Signature verification**: Every price report is signed by the reporter's Ed25519 key and verified on-chain. Unsigned reports are rejected.
- **Reporter whitelist**: Only registered oracle nodes can submit. You control who gets added.
- **Quorum requirement**: Minimum 3 reporters must agree before any price is published.
- **Outlier removal**: Statistical filtering prevents a single compromised node from moving the price.
- **Staleness protection**: `GetFloorPrice` reverts if the price is >30 minutes old — downstream protocols can never silently use stale data.

## Next Steps

1. Add more oracle node operators (more decentralization)
2. Add token-based rewards for honest reporters
3. Add TWAP (time-weighted average price) for smoother liquidation prices
4. Apply to [Arch Keystone Accelerator](https://arch.network/keystone) — up to $250k grant
