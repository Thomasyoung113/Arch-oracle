'use client'

import { useState, useEffect, useRef } from 'react'

// ── Data ──────────────────────────────────────────────────────
const PRICES = [
  { id: 'node-monkes',      name: 'NodeMonkes',       ticker: 'MONK',  btc: 0.04521, change: +4.72,  conf: 92, rep: 4 },
  { id: 'bitcoin-puppets',  name: 'Bitcoin Puppets',  ticker: 'PUPP',  btc: 0.01875, change: -1.24,  conf: 88, rep: 4 },
  { id: 'ordinal-maxi-biz', name: 'Ordinal Maxi Biz', ticker: 'OMB',   btc: 0.00932, change: +0.83,  conf: 85, rep: 3 },
  { id: 'runestones',       name: 'Runestones',       ticker: 'RUNE',  btc: 0.00314, change: +11.31, conf: 79, rep: 3 },
  { id: 'bitcoin-frogs',    name: 'Bitcoin Frogs',    ticker: 'FROG',  btc: 0.00678, change: -3.09,  conf: 90, rep: 4 },
]
const BTC_USD = 65000

// ── Helpers ───────────────────────────────────────────────────
const toSats = (btc: number) => Math.round(btc * 1e8)
const toUSD  = (btc: number) => (btc * BTC_USD).toLocaleString('en-US', { maximumFractionDigits: 0 })
const confColor = (c: number) => c >= 80 ? '#00ff88' : c >= 60 ? '#f59e0b' : '#ef4444'
const confLabel = (c: number) => c >= 80 ? 'HIGH' : c >= 60 ? 'MED' : 'LOW'

// ── Custom Cursor ─────────────────────────────────────────────
function Cursor() {
  const dot  = useRef<HTMLDivElement>(null)
  const ring = useRef<HTMLDivElement>(null)

  useEffect(() => {
    let mx = 0, my = 0, rx = 0, ry = 0
    const move = (e: MouseEvent) => { mx = e.clientX; my = e.clientY }
    window.addEventListener('mousemove', move)
    let raf: number
    const loop = () => {
      rx += (mx - rx) * 0.15; ry += (my - ry) * 0.15
      if (dot.current)  { dot.current.style.left  = mx + 'px'; dot.current.style.top  = my + 'px' }
      if (ring.current) { ring.current.style.left = rx + 'px'; ring.current.style.top = ry + 'px' }
      raf = requestAnimationFrame(loop)
    }
    loop()
    return () => { window.removeEventListener('mousemove', move); cancelAnimationFrame(raf) }
  }, [])

  return (
    <>
      <div ref={dot}  className="cursor-dot" />
      <div ref={ring} className="cursor-ring" />
    </>
  )
}

// ── Navbar ────────────────────────────────────────────────────
function Nav() {
  const [scrolled, setScrolled] = useState(false)
  const [time, setTime]         = useState('')

  useEffect(() => {
    window.addEventListener('scroll', () => setScrolled(window.scrollY > 50))
    const t = setInterval(() => setTime(new Date().toUTCString().slice(17, 25) + ' UTC'), 1000)
    return () => clearInterval(t)
  }, [])

  return (
    <nav className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${scrolled ? 'bg-[#030305]/90 backdrop-blur-md border-b border-[#1a1a2e]' : ''}`}>
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-3">
          <div className="relative w-8 h-8">
            <div className="absolute inset-0 border border-[#ff6b1a] rotate-45 animate-spin-slow opacity-40" />
            <div className="absolute inset-1 border border-[#ff6b1a] rotate-12 animate-spin-rev opacity-60" />
            <div className="absolute inset-2.5 bg-[#ff6b1a] rounded-sm" />
          </div>
          <span className="text-sm font-bold tracking-[0.2em] uppercase" style={{fontFamily:'Orbitron,sans-serif', color:'#ff6b1a'}}>
            ARCH ORACLE
          </span>
        </div>

        {/* Center links */}
        <div className="hidden md:flex items-center gap-8">
          {['feed','architecture','sdk','docs'].map(s => (
            <a key={s} href={`#${s}`}
              className="text-xs tracking-[0.15em] uppercase text-[#4a4a6a] hover:text-[#ff6b1a] transition-colors duration-200"
              style={{fontFamily:'Share Tech Mono,monospace'}}>
              {s}
            </a>
          ))}
        </div>

        {/* Right — clock + GitHub */}
        <div className="flex items-center gap-4">
          <span className="hidden md:block text-xs text-[#4a4a6a]" style={{fontFamily:'Share Tech Mono,monospace'}}>{time}</span>
          <a href="https://github.com/Thomasyoung113/Arch-oracle" target="_blank" rel="noopener noreferrer"
            className="text-xs border border-[#1a1a2e] hover:border-[#ff6b1a] hover:text-[#ff6b1a] text-[#4a4a6a] px-4 py-2 tracking-widest uppercase transition-all duration-200"
            style={{fontFamily:'Share Tech Mono,monospace'}}>
            [GITHUB]
          </a>
        </div>
      </div>
    </nav>
  )
}

// ── Price Ticker ──────────────────────────────────────────────
function Ticker() {
  const items = [...PRICES, ...PRICES, ...PRICES]
  return (
    <div className="relative overflow-hidden border-y border-[#1a1a2e] bg-[#08080e] py-2.5">
      {/* Fade edges */}
      <div className="absolute left-0 top-0 bottom-0 w-16 bg-gradient-to-r from-[#08080e] to-transparent z-10 pointer-events-none" />
      <div className="absolute right-0 top-0 bottom-0 w-16 bg-gradient-to-l from-[#08080e] to-transparent z-10 pointer-events-none" />
      <div className="flex animate-ticker whitespace-nowrap">
        {items.map((p, i) => (
          <span key={i} className="inline-flex items-center gap-2.5 mr-10 text-xs" style={{fontFamily:'Share Tech Mono,monospace'}}>
            <span className="text-[#ff6b1a]">{p.ticker}</span>
            <span className="text-[#ddddf0]">{p.btc.toFixed(6)}</span>
            <span className="text-[#4a4a6a]">BTC</span>
            <span className={p.change >= 0 ? 'text-[#00ff88]' : 'text-[#ef4444]'}>
              {p.change >= 0 ? '+' : ''}{p.change.toFixed(2)}%
            </span>
            <span className="text-[#1a1a2e] mx-2">//</span>
          </span>
        ))}
      </div>
    </div>
  )
}

// ── Hero ──────────────────────────────────────────────────────
function Hero() {
  const [glitch, setGlitch]   = useState(false)
  const [typed,  setTyped]    = useState('')
  const full = 'ORDINALS PRICE ORACLE'

  // Typewriter
  useEffect(() => {
    let i = 0
    const t = setInterval(() => {
      setTyped(full.slice(0, i + 1))
      i++
      if (i >= full.length) clearInterval(t)
    }, 70)
    return () => clearInterval(t)
  }, [])

  // Glitch trigger
  useEffect(() => {
    const t = setInterval(() => {
      setGlitch(true)
      setTimeout(() => setGlitch(false), 400)
    }, 6000)
    return () => clearInterval(t)
  }, [])

  return (
    <section className="relative min-h-screen flex flex-col justify-center px-6 pt-16 overflow-hidden">

      {/* Background hex grid decoration */}
      <div className="absolute top-1/4 right-0 w-[500px] h-[500px] opacity-5 pointer-events-none">
        <svg viewBox="0 0 200 200" fill="none" xmlns="http://www.w3.org/2000/svg">
          {Array.from({length:7}).map((_,r)=>Array.from({length:7}).map((_,c)=>{
            const x = c*28 + (r%2)*14; const y = r*24
            return <polygon key={`${r}-${c}`} points={`${x+14},${y} ${x+28},${y+8} ${x+28},${y+22} ${x+14},${y+30} ${x},${y+22} ${x},${y+8}`} stroke="#ff6b1a" strokeWidth="0.5"/>
          }))}
        </svg>
      </div>

      {/* Vertical line decorations */}
      <div className="absolute left-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[#ff6b1a] to-transparent opacity-20" />
      <div className="absolute right-0 top-0 bottom-0 w-px bg-gradient-to-b from-transparent via-[#00d4ff] to-transparent opacity-10" />

      <div className="relative max-w-7xl mx-auto w-full">
        <div className="max-w-5xl">

          {/* System tag */}
          <div className="flex items-center gap-3 mb-8">
            <div className="w-1.5 h-1.5 bg-[#00ff88] rounded-full animate-pulse" />
            <span className="text-xs text-[#00ff88] tracking-[0.25em] uppercase" style={{fontFamily:'Share Tech Mono,monospace'}}>
              SYS::ARCH_TESTNET // NODE_STATUS: ACTIVE
            </span>
          </div>

          {/* Main heading */}
          <div className="relative mb-6">
            <h1
              className="text-6xl md:text-8xl lg:text-9xl font-black leading-none tracking-tighter"
              style={{ fontFamily: 'Orbitron, sans-serif', color: '#ff6b1a' }}
            >
              {/* Glitch layers */}
              {glitch && (
                <>
                  <span className="absolute inset-0 text-[#00d4ff] opacity-70"
                    style={{animation:'glitch 0.3s steps(1) forwards', clipPath:'inset(20% 0 60% 0)', transform:'translate(3px,0)', fontFamily:'Orbitron,sans-serif'}}>
                    ARCH
                  </span>
                  <span className="absolute inset-0 text-[#ff6b1a] opacity-50"
                    style={{animation:'glitch 0.3s steps(1) 0.1s forwards', clipPath:'inset(60% 0 20% 0)', transform:'translate(-2px,0)', fontFamily:'Orbitron,sans-serif'}}>
                    ARCH
                  </span>
                </>
              )}
              ARCH
            </h1>
            <h1 className="text-6xl md:text-8xl lg:text-9xl font-black leading-none tracking-tighter text-[#ddddf0]" style={{fontFamily:'Orbitron,sans-serif'}}>
              ORACLE
            </h1>
          </div>

          {/* Typewriter subtitle */}
          <div className="flex items-center gap-3 mb-6">
            <div className="h-px flex-1 max-w-16 bg-[#ff6b1a]" />
            <span className="text-sm md:text-base text-[#ff6b1a] tracking-[0.3em] terminal-cursor" style={{fontFamily:'Share Tech Mono,monospace'}}>
              {typed}
            </span>
          </div>

          <p className="text-lg md:text-xl text-[#8888aa] max-w-2xl leading-relaxed mb-12 font-medium" style={{fontFamily:'Rajdhani,sans-serif'}}>
            The first decentralized floor price feed for Ordinals on Arch Network.
            Multi-source. Trustless. Bitcoin-native. No bridges. No wrapping.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-wrap gap-4 mb-16">
            <a href="#sdk"
              className="group relative overflow-hidden bg-[#ff6b1a] text-black font-bold text-xs px-8 py-4 tracking-[0.2em] uppercase transition-all duration-200 hover:shadow-[0_0_30px_rgba(255,107,26,0.5)]"
              style={{fontFamily:'Orbitron,sans-serif'}}>
              <span className="relative z-10">INTEGRATE SDK</span>
              <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity" />
            </a>
            <a href="#feed"
              className="group border border-[#ff6b1a] text-[#ff6b1a] font-bold text-xs px-8 py-4 tracking-[0.2em] uppercase hover:bg-[#ff6b1a] hover:text-black transition-all duration-200"
              style={{fontFamily:'Orbitron,sans-serif'}}>
              VIEW LIVE FEED
            </a>
            <a href="https://github.com/Thomasyoung113/Arch-oracle" target="_blank" rel="noopener noreferrer"
              className="border border-[#1a1a2e] text-[#4a4a6a] font-bold text-xs px-8 py-4 tracking-[0.2em] uppercase hover:border-[#4a4a6a] hover:text-[#ddddf0] transition-all duration-200"
              style={{fontFamily:'Orbitron,sans-serif'}}>
              [GITHUB] →
            </a>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-[#1a1a2e]">
            {[
              { v: '5',   u: 'COLLECTIONS',   d: 'tracked on-chain' },
              { v: '4',   u: 'DATA SOURCES',  d: 'marketplaces' },
              { v: '10M', u: 'UPDATE CYCLE',  d: 'every 10 minutes' },
              { v: '3+',  u: 'QUORUM',        d: 'reporters required' },
            ].map((s, i) => (
              <div key={i} className="bg-[#08080e] px-6 py-5 border-b-2 border-transparent hover:border-[#ff6b1a] transition-all group">
                <div className="text-3xl font-black text-[#ff6b1a] mb-1 group-hover:glow-orange transition-all" style={{fontFamily:'Orbitron,sans-serif'}}>{s.v}</div>
                <div className="text-xs text-[#ddddf0] tracking-widest mb-0.5" style={{fontFamily:'Share Tech Mono,monospace'}}>{s.u}</div>
                <div className="text-xs text-[#4a4a6a]">{s.d}</div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  )
}

// ── Live Feed ─────────────────────────────────────────────────
function LiveFeed() {
  const [prices, setPrices] = useState(PRICES.map(p => ({ ...p, sats: toSats(p.btc) })))
  const [selected, setSelected] = useState<string|null>(null)
  const [tick, setTick] = useState(0)

  useEffect(() => {
    const t = setInterval(() => {
      setPrices(prev => prev.map(p => ({
        ...p,
        btc:  parseFloat((p.btc  * (1 + (Math.random()-0.5)*0.003)).toFixed(8)),
        sats: Math.round(p.sats * (1 + (Math.random()-0.5)*0.003)),
        change: parseFloat((p.change + (Math.random()-0.5)*0.2).toFixed(2)),
      })))
      setTick(t => t+1)
    }, 5000)
    return () => clearInterval(t)
  }, [])

  return (
    <section id="feed" className="py-24 px-6 max-w-7xl mx-auto">

      {/* Header */}
      <div className="flex items-end justify-between mb-10">
        <div>
          <div className="text-xs text-[#ff6b1a] tracking-[0.3em] uppercase mb-3" style={{fontFamily:'Share Tech Mono,monospace'}}>
            // PRICE_FEED.LIVE
          </div>
          <h2 className="text-4xl md:text-5xl font-black tracking-tight" style={{fontFamily:'Orbitron,sans-serif'}}>
            FLOOR PRICES
          </h2>
        </div>
        <div className="text-right">
          <div className="flex items-center justify-end gap-2 mb-1">
            <div className="w-1.5 h-1.5 rounded-full bg-[#00ff88] animate-pulse" />
            <span className="text-xs text-[#00ff88]" style={{fontFamily:'Share Tech Mono,monospace'}}>SIMULATED</span>
          </div>
          <div className="text-xs text-[#4a4a6a]" style={{fontFamily:'Share Tech Mono,monospace'}}>
            TICK #{String(tick).padStart(6,'0')}
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {prices.map((p) => {
          const isOpen = selected === p.id
          const cc = confColor(p.conf)
          const isUp = p.change >= 0
          return (
            <div key={p.id} onClick={() => setSelected(isOpen ? null : p.id)}
              className="bg-[#08080e] border border-[#1a1a2e] p-6 cursor-pointer card-hover relative overflow-hidden"
              style={isOpen ? {borderColor:'rgba(255,107,26,0.5)', background:'#0d0d18', boxShadow:'0 0 30px rgba(255,107,26,0.08)'} : {}}>

              {/* Corner accent */}
              <div className="absolute top-0 right-0 w-8 h-8 overflow-hidden">
                <div className="absolute top-0 right-0 w-0 h-0 border-t-[24px] border-r-[24px]"
                  style={{borderTopColor:'rgba(255,107,26,0.3)', borderRightColor:'rgba(255,107,26,0.3)'}} />
              </div>

              {/* Top row */}
              <div className="flex items-start justify-between mb-5">
                <div>
                  <div className="text-xs text-[#4a4a6a] tracking-[0.2em] mb-1" style={{fontFamily:'Share Tech Mono,monospace'}}>{p.ticker} / BTC</div>
                  <div className="font-bold text-[#ddddf0] text-base" style={{fontFamily:'Orbitron,sans-serif', fontSize:'13px'}}>{p.name}</div>
                </div>
                <div className="text-xs px-2 py-1 border tracking-widest"
                  style={{color:cc, borderColor:cc+'55', background:cc+'11', fontFamily:'Share Tech Mono,monospace'}}>
                  {confLabel(p.conf)}
                </div>
              </div>

              {/* Price */}
              <div className="mb-5">
                <div className="text-2xl font-black mb-1" style={{fontFamily:'Orbitron,sans-serif', color:'#ff6b1a'}}>
                  {p.btc.toFixed(6)}
                </div>
                <div className="flex items-center gap-3 text-xs" style={{fontFamily:'Share Tech Mono,monospace'}}>
                  <span className="text-[#4a4a6a]">${toUSD(p.btc)}</span>
                  <span className="text-[#1a1a2e]">//</span>
                  <span className={isUp ? 'text-[#00ff88]' : 'text-[#ef4444]'}>
                    {isUp ? '▲' : '▼'} {Math.abs(p.change).toFixed(2)}%
                  </span>
                </div>
              </div>

              {/* Bar */}
              <div className="flex items-center justify-between text-xs mb-4" style={{fontFamily:'Share Tech Mono,monospace'}}>
                <span className="text-[#4a4a6a]">CONF {p.conf}%</span>
                <div className="flex-1 mx-3 h-px bg-[#1a1a2e]">
                  <div className="h-px transition-all duration-700" style={{width:`${p.conf}%`, background:cc, boxShadow:`0 0 6px ${cc}`}} />
                </div>
                <span className="text-[#4a4a6a]">{p.rep} NODES</span>
              </div>

              {/* Expanded */}
              {isOpen && (
                <div className="border-t border-[#1a1a2e] pt-4 mt-2 space-y-2">
                  {[
                    ['PRICE (SATS)', p.sats.toLocaleString()],
                    ['SOURCES',      'ME · OKX · UNISAT · GAMMA'],
                    ['MAX LTV 50%',  `${(p.sats*0.5/1e8).toFixed(6)} BTC`],
                    ['STATUS',       '✓ FRESH — <30 MIN'],
                  ].map(([k,v], i) => (
                    <div key={i} className="flex justify-between text-xs" style={{fontFamily:'Share Tech Mono,monospace'}}>
                      <span className="text-[#4a4a6a]">{k}</span>
                      <span className={k === 'STATUS' ? 'text-[#00ff88]' : k.includes('LTV') ? 'text-[#ff6b1a]' : 'text-[#ddddf0]'}>{v}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )
        })}

        {/* Coming soon card */}
        <div className="border border-dashed border-[#1a1a2e] p-6 flex flex-col items-center justify-center min-h-[220px] opacity-40 hover:opacity-60 transition-opacity">
          <div className="text-3xl text-[#1a1a2e] mb-3" style={{fontFamily:'Orbitron,sans-serif'}}>+</div>
          <div className="text-xs text-[#4a4a6a] tracking-widest text-center" style={{fontFamily:'Share Tech Mono,monospace'}}>
            MORE COLLECTIONS<br/>QUEUED
          </div>
        </div>
      </div>

      <div className="text-center mt-6 text-xs text-[#4a4a6a]" style={{fontFamily:'Share Tech Mono,monospace'}}>
        // TAP ANY CARD FOR EXTENDED DATA · PRICES SIMULATED UNTIL TESTNET DEPLOY
      </div>
    </section>
  )
}

// ── Architecture ──────────────────────────────────────────────
function Architecture() {
  const [active, setActive] = useState(0)
  const layers = [
    { num:'01', tag:'DATA_COLLECTION',  title:'Fetch',     lang:'NODE.JS',  color:'#00d4ff',
      body:'Every 10 minutes, oracle nodes fetch floor prices from Magic Eden, OKX, Unisat, and Gamma in parallel. Each node signs its data bundle with an Ed25519 key before submitting on-chain.' },
    { num:'02', tag:'COMPUTE_LAYER',    title:'Aggregate', lang:'RUST',     color:'#ff6b1a',
      body:'The Arch on-chain program collects signed reports. It removes statistical outliers (>2σ), computes a confidence-weighted median, and requires quorum of 3+ independent reporters before publishing.' },
    { num:'03', tag:'SETTLEMENT',       title:'Publish',   lang:'ARCHVM',   color:'#00ff88',
      body:'Final price, confidence score, reporter count, and timestamp are written to a UTXO state account on Bitcoin via Arch. Staleness protection enforced — reverts if data is >30 minutes old.' },
    { num:'04', tag:'CONSUMPTION',      title:'Consume',   lang:'SDK',      color:'#a855f7',
      body:'Lending protocols, DEXes, and liquidation bots call your oracle via the TypeScript SDK or direct Arch CPI. One line: oracle.getPriceSats("node-monkes") — throws if stale, safe by default.' },
  ]

  return (
    <section id="architecture" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="mb-12">
        <div className="text-xs text-[#ff6b1a] tracking-[0.3em] uppercase mb-3" style={{fontFamily:'Share Tech Mono,monospace'}}>// SYSTEM.ARCHITECTURE</div>
        <h2 className="text-4xl md:text-5xl font-black tracking-tight" style={{fontFamily:'Orbitron,sans-serif'}}>HOW IT WORKS</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left — step list */}
        <div className="space-y-2">
          {layers.map((l, i) => (
            <div key={i} onClick={() => setActive(i)}
              className={`p-5 border cursor-pointer transition-all duration-200 ${active===i ? 'border-[rgba(255,107,26,0.5)] bg-[#0d0d18]' : 'border-[#1a1a2e] bg-[#08080e] hover:border-[#2a2a4a]'}`}>
              <div className="flex items-center gap-4">
                <span className="text-3xl font-black opacity-20" style={{fontFamily:'Orbitron,sans-serif', color:l.color}}>{l.num}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-0.5">
                    <span className="font-black text-base" style={{fontFamily:'Orbitron,sans-serif', color: active===i ? l.color : '#ddddf0'}}>{l.title}</span>
                    <span className="text-xs border px-2 py-0.5" style={{color:l.color, borderColor:l.color+'44', fontFamily:'Share Tech Mono,monospace'}}>{l.lang}</span>
                  </div>
                  <div className="text-xs text-[#4a4a6a]" style={{fontFamily:'Share Tech Mono,monospace'}}>{l.tag}</div>
                </div>
                <span className="text-[#4a4a6a] text-xs">{active===i ? '◀' : '▶'}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Right — detail panel */}
        <div className="bg-[#08080e] border border-[#1a1a2e] p-8 relative overflow-hidden">
          {/* Top bar */}
          <div className="flex items-center gap-2 mb-6 pb-4 border-b border-[#1a1a2e]">
            <div className="w-2 h-2 rounded-full" style={{background: layers[active].color, boxShadow:`0 0 8px ${layers[active].color}`}} />
            <span className="text-xs tracking-widest" style={{color: layers[active].color, fontFamily:'Share Tech Mono,monospace'}}>
              LAYER_{layers[active].num} :: {layers[active].tag}
            </span>
          </div>

          <div className="text-4xl font-black mb-6" style={{fontFamily:'Orbitron,sans-serif', color: layers[active].color}}>
            {layers[active].title.toUpperCase()}
          </div>

          <p className="text-[#8888aa] text-base leading-relaxed mb-8" style={{fontFamily:'Rajdhani,sans-serif'}}>
            {layers[active].body}
          </p>

          {/* Data sources for layer 1 */}
          {active === 0 && (
            <div className="grid grid-cols-2 gap-2">
              {['Magic Eden','OKX NFT','Unisat','Gamma.io'].map((s,i) => (
                <div key={i} className="flex items-center gap-2 text-xs p-2 border border-[#1a1a2e]" style={{fontFamily:'Share Tech Mono,monospace'}}>
                  <div className="w-1.5 h-1.5 rounded-full bg-[#00ff88]" />
                  <span className="text-[#4a4a6a]">{s}</span>
                </div>
              ))}
            </div>
          )}

          {/* Decorative circuit lines */}
          <div className="absolute bottom-0 right-0 opacity-10 pointer-events-none">
            <svg width="120" height="120" viewBox="0 0 120 120">
              <path d="M120 0 L60 0 L60 60 L0 60 L0 120" stroke={layers[active].color} strokeWidth="1" fill="none"/>
              <circle cx="60" cy="60" r="4" fill={layers[active].color}/>
              <circle cx="0" cy="120" r="3" fill={layers[active].color}/>
              <circle cx="120" cy="0" r="3" fill={layers[active].color}/>
            </svg>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── SDK Section ───────────────────────────────────────────────
function SDKSection() {
  const [tab, setTab] = useState(0)
  const [copied, setCopied] = useState(false)

  const copy = (text: string) => {
    navigator.clipboard?.writeText(text)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const tabs = [
    { label: 'GET_PRICE', code:
`import { OracleClient } from "@ordinals-oracle/sdk"

const oracle = new OracleClient({
  network:   "testnet",
  programId: "YOUR_PROGRAM_ID",
})

// One line. Full data.
const price = await oracle.getPrice("node-monkes")

price.priceBTC        // "0.045000"
price.priceSats       // 4500000
price.confidence      // 92
price.lastUpdatedAgo  // "3 minutes ago"
price.isFresh         // true` },
    { label: 'GET_LTV', code:
`// Confidence-adjusted max loan amount
const { maxLoanSats, effectiveLTV } = await oracle.getLTV(
  "node-monkes",
  0.5,   // 50% target LTV
  70     // min confidence threshold
)

// If confidence < 70, LTV auto-reduces
// Never over-lend on low-confidence prices
maxLoanSats   // 2250000 sats
effectiveLTV  // 0.45 (reduced from 0.5)` },
    { label: 'SUBSCRIBE', code:
`// Live polling feed — every 2 minutes
const sub = oracle.subscribe({
  collections: ["node-monkes", "bitcoin-puppets"],
  intervalMs: 120_000,

  onUpdate: (feed) => {
    const p = feed.prices["node-monkes"]
    console.log(p.priceBTC, p.isFresh)
  },

  onError: (err) => {
    // alert your on-call team
  }
})

sub.unsubscribe() // stop when done` },
    { label: 'CIRCUIT_BREAKER', code:
`// Safety check before liquidation
// Returns false if stale OR confidence < 50%
const safe = await oracle.isHealthy("node-monkes")

if (!safe) {
  // NEVER liquidate on unhealthy oracle
  return
}

// Throws if stale — safe by default
const sats = await oracle.getPriceSats("node-monkes")

// Now safe to trigger liquidation logic` },
  ]

  return (
    <section id="sdk" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="mb-12">
        <div className="text-xs text-[#ff6b1a] tracking-[0.3em] uppercase mb-3" style={{fontFamily:'Share Tech Mono,monospace'}}>// SDK.INTEGRATION</div>
        <h2 className="text-4xl md:text-5xl font-black tracking-tight mb-4" style={{fontFamily:'Orbitron,sans-serif'}}>
          INTEGRATE IN<br/><span style={{color:'#ff6b1a'}}>MINUTES</span>
        </h2>
        <p className="text-[#8888aa] text-lg max-w-xl" style={{fontFamily:'Rajdhani,sans-serif'}}>
          TypeScript SDK. Full type safety. Built-in caching. Confidence-adjusted LTV. Live subscriptions.
        </p>
      </div>

      {/* Install bar */}
      <div className="flex items-center justify-between bg-[#08080e] border border-[#1a1a2e] px-5 py-3.5 mb-6 hover:border-[#ff6b1a] transition-colors group">
        <code className="text-sm text-[#ff6b1a]" style={{fontFamily:'Share Tech Mono,monospace'}}>
          npm install @ordinals-oracle/sdk
        </code>
        <button onClick={() => copy('npm install @ordinals-oracle/sdk')}
          className="text-xs text-[#4a4a6a] group-hover:text-[#ff6b1a] transition-colors tracking-widest"
          style={{fontFamily:'Share Tech Mono,monospace'}}>
          {copied ? 'COPIED ✓' : 'COPY'}
        </button>
      </div>

      {/* Code window */}
      <div className="border border-[#1a1a2e] overflow-hidden">
        {/* Tab bar */}
        <div className="flex bg-[#08080e] border-b border-[#1a1a2e] overflow-x-auto">
          <div className="flex items-center gap-1.5 px-4 border-r border-[#1a1a2e]">
            <div className="w-2.5 h-2.5 rounded-full bg-[#ef4444]" />
            <div className="w-2.5 h-2.5 rounded-full bg-[#f59e0b]" />
            <div className="w-2.5 h-2.5 rounded-full bg-[#00ff88]" />
          </div>
          {tabs.map((t, i) => (
            <button key={i} onClick={() => setTab(i)}
              className={`px-5 py-3 text-xs tracking-widest whitespace-nowrap border-r border-[#1a1a2e] transition-colors ${tab===i ? 'text-[#ff6b1a] bg-[#0d0d18] border-b border-b-[#ff6b1a]' : 'text-[#4a4a6a] hover:text-[#8888aa]'}`}
              style={{fontFamily:'Share Tech Mono,monospace'}}>
              {t.label}
            </button>
          ))}
        </div>

        {/* Code body */}
        <div className="bg-[#050508] p-8 overflow-x-auto">
          <pre className="text-sm leading-relaxed text-[#8888cc] whitespace-pre" style={{fontFamily:'Share Tech Mono,monospace'}}>
            {tabs[tab].code}
          </pre>
        </div>
      </div>

      {/* Method grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-px bg-[#1a1a2e] mt-6">
        {[
          { m:'getPrice(id)',        c:'#ff6b1a', d:'Full OraclePrice — BTC, USD, confidence, change %' },
          { m:'getPrices([ids])',    c:'#00d4ff', d:'Multi-collection parallel fetch. Partial results OK.' },
          { m:'getPriceSats(id)',    c:'#00ff88', d:'Raw number. Throws OracleSDKError if stale.' },
          { m:'getLTV(id, ratio)',   c:'#a855f7', d:'Max loan sats. Confidence-adjusted effective LTV.' },
          { m:'isHealthy(id)',       c:'#00ff88', d:'Circuit breaker. Fresh + confidence ≥ 50%.' },
          { m:'subscribe(opts)',     c:'#ff6b1a', d:'Polling feed with onUpdate / onError callbacks.' },
          { m:'setBtcUsdPrice(n)',   c:'#00d4ff', d:'Update BTC/USD for display. Clears cache.' },
          { m:'formatPrice(price)',  c:'#a855f7', d:'"0.045 BTC ($2,925) ▲ 4.7%" — display-ready.' },
        ].map((item, i) => (
          <div key={i} className="bg-[#08080e] p-5 hover:bg-[#0d0d18] transition-colors">
            <div className="text-sm font-bold mb-2" style={{fontFamily:'Share Tech Mono,monospace', color: item.c}}>{item.m}</div>
            <div className="text-xs text-[#4a4a6a] leading-relaxed">{item.d}</div>
          </div>
        ))}
      </div>
    </section>
  )
}

// ── Docs ──────────────────────────────────────────────────────
function Docs() {
  return (
    <section id="docs" className="py-24 px-6 max-w-7xl mx-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-px bg-[#1a1a2e]">

        {/* Left big panel */}
        <div className="lg:col-span-2 bg-[#08080e] p-10">
          <div className="text-xs text-[#ff6b1a] tracking-[0.3em] uppercase mb-4" style={{fontFamily:'Share Tech Mono,monospace'}}>// OPEN_SOURCE</div>
          <h2 className="text-4xl font-black tracking-tight mb-4" style={{fontFamily:'Orbitron,sans-serif'}}>
            BUILT IN PUBLIC.<br/><span style={{color:'#ff6b1a'}}>SHIP WITH US.</span>
          </h2>
          <p className="text-[#8888aa] text-base leading-relaxed mb-10 max-w-lg" style={{fontFamily:'Rajdhani,sans-serif'}}>
            Everything is open source. Fork it, extend it, integrate it. 
            The oracle is infrastructure — every Arch protocol that builds on it makes the whole ecosystem stronger.
          </p>

          <div className="space-y-2">
            {[
              { label:'FETCHER BOT',    path:'/fetcher',        lang:'NODE.JS', desc:'Off-chain price aggregator (Magic Eden · OKX · Unisat · Gamma)', color:'#00d4ff' },
              { label:'ORACLE PROGRAM', path:'/oracle-program', lang:'RUST',    desc:'On-chain Arch program — sig verify, outlier removal, quorum',     color:'#ff6b1a' },
              { label:'TYPESCRIPT SDK', path:'/sdk',            lang:'TS',      desc:'Consumer SDK — full types, caching, LTV, subscriptions',           color:'#a855f7' },
              { label:'WEBSITE',        path:'/website',        lang:'NEXT.JS', desc:'This site — live feed, docs, Vercel-deployed',                     color:'#00ff88' },
            ].map((f, i) => (
              <a key={i}
                href={`https://github.com/Thomasyoung113/Arch-oracle/tree/main${f.path}`}
                target="_blank" rel="noopener noreferrer"
                className="flex items-center justify-between p-4 border border-[#1a1a2e] hover:border-[rgba(255,107,26,0.4)] group transition-all scan-hover">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 flex items-center justify-center border border-[#1a1a2e] group-hover:border-current transition-colors text-xs"
                    style={{color: f.color, fontFamily:'Share Tech Mono,monospace', borderColor:`${f.color}33`}}>
                    {f.lang.slice(0,2)}
                  </div>
                  <div>
                    <div className="text-sm font-bold group-hover:text-[#ff6b1a] transition-colors" style={{fontFamily:'Orbitron,sans-serif', fontSize:'11px'}}>{f.label}</div>
                    <div className="text-xs text-[#4a4a6a]" style={{fontFamily:'Share Tech Mono,monospace'}}>{f.desc}</div>
                  </div>
                </div>
                <span className="text-[#4a4a6a] group-hover:text-[#ff6b1a] transition-colors text-sm">→</span>
              </a>
            ))}
          </div>
        </div>

        {/* Right quickstart */}
        <div className="bg-[#08080e] p-8 flex flex-col">
          <div className="text-xs text-[#ff6b1a] tracking-[0.3em] uppercase mb-6" style={{fontFamily:'Share Tech Mono,monospace'}}>// QUICKSTART</div>

          <div className="flex-1 space-y-1 text-xs overflow-auto" style={{fontFamily:'Share Tech Mono,monospace'}}>
            {[
              {t:'cm', v:'# Clone repo'},
              {t:'co', v:'git clone github.com/'},
              {t:'co', v:'  Thomasyoung113/Arch-oracle'},
              {t:'sp', v:''},
              {t:'cm', v:'# Test (no network needed)'},
              {t:'co', v:'cd fetcher && npm test'},
              {t:'co', v:'cd oracle-program && cargo test'},
              {t:'sp', v:''},
              {t:'cm', v:'# Generate keypair'},
              {t:'co', v:'node src/keygen.js'},
              {t:'sp', v:''},
              {t:'cm', v:'# Deploy to Arch testnet'},
              {t:'co', v:'arch-cli program deploy ...'},
              {t:'sp', v:''},
              {t:'cm', v:'# Start the fetcher'},
              {t:'co', v:'npm start'},
              {t:'sp', v:''},
              {t:'ok', v:'✓ Oracle live on testnet'},
            ].map((l, i) => (
              <div key={i} className={l.t==='cm' ? 'text-[#4a4a6a]' : l.t==='ok' ? 'text-[#00ff88]' : l.t==='sp' ? 'h-3' : 'text-[#8888cc]'}>
                {l.v}
              </div>
            ))}
          </div>

          <div className="mt-8 space-y-3">
            <a href="https://github.com/Thomasyoung113/Arch-oracle" target="_blank" rel="noopener noreferrer"
              className="block bg-[#ff6b1a] text-black font-black text-xs text-center py-3.5 tracking-[0.2em] uppercase hover:bg-orange-400 transition-colors"
              style={{fontFamily:'Orbitron,sans-serif'}}>
              VIEW ON GITHUB →
            </a>
            <a href="https://book.arch.network" target="_blank" rel="noopener noreferrer"
              className="block border border-[#1a1a2e] text-[#4a4a6a] text-xs text-center py-3.5 tracking-widest uppercase hover:border-[#ff6b1a] hover:text-[#ff6b1a] transition-all"
              style={{fontFamily:'Share Tech Mono,monospace'}}>
              ARCH DOCS →
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

// ── Footer ────────────────────────────────────────────────────
function Footer() {
  return (
    <footer className="border-t border-[#1a1a2e] py-12 px-6 relative">
      {/* Top line glow */}
      <div className="absolute top-0 left-1/4 right-1/4 h-px bg-gradient-to-r from-transparent via-[#ff6b1a] to-transparent opacity-40" />

      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 mb-8">

          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="relative w-7 h-7">
              <div className="absolute inset-0 border border-[#ff6b1a] rotate-45 opacity-50" />
              <div className="absolute inset-2 bg-[#ff6b1a] rounded-sm" />
            </div>
            <span className="text-sm font-black tracking-[0.2em]" style={{fontFamily:'Orbitron,sans-serif', color:'#ff6b1a'}}>
              ARCH ORACLE
            </span>
          </div>

          {/* Links */}
          <div className="flex flex-wrap gap-6 justify-center">
            {[
              { label:'GITHUB',       href:'https://github.com/Thomasyoung113/Arch-oracle' },
              { label:'ARCH NETWORK', href:'https://arch.network' },
              { label:'ARCH DOCS',    href:'https://book.arch.network' },
              { label:'TESTNET',      href:'https://faucet.arch.network' },
            ].map((l, i) => (
              <a key={i} href={l.href} target="_blank" rel="noopener noreferrer"
                className="text-xs text-[#4a4a6a] hover:text-[#ff6b1a] tracking-widest uppercase transition-colors"
                style={{fontFamily:'Share Tech Mono,monospace'}}>
                {l.label}
              </a>
            ))}
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-[#1a1a2e] pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="text-xs text-[#4a4a6a]" style={{fontFamily:'Share Tech Mono,monospace'}}>
            ARCH_ORACLE v0.1.0 // TESTNET // MIT LICENSE
          </div>

          {/* Built by Thomas Young — with Telegram link */}
          <a
            href="https://t.me/thomas_young"
            target="_blank"
            rel="noopener noreferrer"
            className="group flex items-center gap-2 text-xs text-[#4a4a6a] hover:text-[#00d4ff] transition-all duration-200"
            style={{fontFamily:'Share Tech Mono,monospace'}}
          >
            <span className="opacity-40 group-hover:opacity-100 transition-opacity">
              {/* Telegram icon SVG */}
              <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm5.894 8.221l-1.97 9.28c-.145.658-.537.818-1.084.508l-3-2.21-1.447 1.394c-.16.16-.295.295-.605.295l.213-3.053 5.56-5.023c.242-.213-.054-.333-.373-.12L7.19 13.67l-2.96-.924c-.643-.204-.657-.643.136-.953l11.57-4.461c.537-.194 1.006.131.958.889z"/>
              </svg>
            </span>
            <span>BUILT BY</span>
            <span
              className="font-bold tracking-wider"
              style={{
                color: 'transparent',
                backgroundImage: 'linear-gradient(90deg, #00d4ff, #ff6b1a)',
                WebkitBackgroundClip: 'text',
                backgroundClip: 'text',
              }}>
              THOMAS YOUNG
            </span>
            <span className="opacity-0 group-hover:opacity-100 transition-opacity text-[#00d4ff]">↗</span>
          </a>

          <div className="text-xs text-[#1a1a2e]" style={{fontFamily:'Share Tech Mono,monospace'}}>
            BUILT ON BITCOIN
          </div>
        </div>
      </div>
    </footer>
  )
}

// ── Page ──────────────────────────────────────────────────────
export default function Home() {
  return (
    <main className="relative z-10">
      <Cursor />
      <Nav />
      <Ticker />
      <Hero />
      <LiveFeed />
      <Architecture />
      <SDKSection />
      <Docs />
      <Footer />
    </main>
  )
}
