import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'Arch Oracle — Bitcoin-Native Ordinals Price Feed',
  description: 'The first decentralized floor price oracle for Ordinals on Arch Network. Trustless. Multi-source. Bitcoin-native.',
  keywords: ['ordinals', 'bitcoin', 'oracle', 'arch network', 'defi', 'price feed', 'nft'],
  openGraph: {
    title: 'Arch Oracle — Bitcoin-Native Ordinals Price Feed',
    description: 'Trustless. Multi-source. Bitcoin-native. Built on Arch Network.',
    type: 'website',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
