# @ordinals-oracle/sdk

TypeScript SDK for consuming the **Ordinals Price Oracle** on Arch Network.
One import. One line. Live Bitcoin-native NFT floor prices.

## Install

```bash
npm install @ordinals-oracle/sdk
```

## Quickstart

```typescript
import { OracleClient } from "@ordinals-oracle/sdk";

const oracle = new OracleClient({
  network:   "testnet",
  programId: "YOUR_DEPLOYED_PROGRAM_ID",
});

const price = await oracle.getPrice("node-monkes");
console.log(price.priceBTC);       // "0.045000"
console.log(price.confidence);      // 87
console.log(price.isFresh);         // true
```

## Key Methods

| Method | What it does |
|---|---|
| `getPrice(id)` | Full OraclePrice object for one collection |
| `getPrices([ids])` | Multiple collections in parallel |
| `getPriceSats(id)` | Just the number in sats. Throws if stale. |
| `getLTV(id, ratio)` | Max loan amount, confidence-adjusted |
| `isHealthy(id)` | Circuit breaker — fresh + confident? |
| `subscribe(opts)` | Live polling feed with onUpdate callback |
| `setBtcUsdPrice(n)` | Update BTC/USD for display conversions |
| `formatPrice(p)` | "0.045 BTC ($2,925) ▲ 4.7%" |
| `confidenceLabel(p)` | "HIGH" / "MEDIUM" / "LOW" |

## Error Codes

`PRICE_STALE` · `PRICE_EMPTY` · `COLLECTION_NOT_FOUND` · `RPC_ERROR` · `NETWORK_ERROR`

## Run tests

```bash
node src/test.js
```
