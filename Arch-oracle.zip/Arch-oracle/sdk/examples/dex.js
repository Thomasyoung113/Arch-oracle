// ─────────────────────────────────────────────────────────────
// examples/dex.js — DEX / Marketplace Integration
//
// Shows how a DEX or marketplace would use the oracle to:
//   1. Validate that a listed price isn't wildly off from fair value
//   2. Check if a swap price is within acceptable slippage
//   3. Set dynamic maker/taker fees based on price volatility
//
// Run: node examples/dex.js
// ─────────────────────────────────────────────────────────────

import { OracleClient, COLLECTIONS, OracleError } from "../src/index.js";

const oracle = new OracleClient({
  network:    "testnet",
  allowStale: true,  // remove in production
  minConfidence: 0,  // remove in production
});

// ─── 1. Validate a listing price ─────────────────────────────
/**
 * Before accepting a listing, check the price is within
 * a reasonable range of the oracle floor price.
 * Protects buyers from wildly overpriced listings.
 */
async function validateListing(collectionId, listedPriceSats) {
  console.log(`\n━━━ Listing Validation ━━━`);

  const price = await oracle.getFloorPrice(collectionId);
  const floorSats = price.floorPriceSats;

  // Allow listings up to 10x the floor (rare items may trade at a premium)
  // Reject listings below 50% of floor (likely error or wash trade)
  const maxAcceptable = floorSats * 10;
  const minAcceptable = floorSats * 0.5;

  const premium = ((listedPriceSats - floorSats) / floorSats) * 100;
  const isValid  = listedPriceSats >= minAcceptable && listedPriceSats <= maxAcceptable;

  console.log(`Collection:    ${price.collectionName}`);
  console.log(`Floor Price:   ${(floorSats / 1e8).toFixed(6)} BTC`);
  console.log(`Listed Price:  ${(listedPriceSats / 1e8).toFixed(6)} BTC`);
  console.log(`Premium:       ${premium >= 0 ? "+" : ""}${premium.toFixed(1)}% vs floor`);
  console.log(`Valid Listing: ${isValid ? "✅ Yes" : "❌ No — outside acceptable range"}`);

  return { isValid, premium, floorSats };
}

// ─── 2. Check swap slippage ───────────────────────────────────
/**
 * When a buyer submits a swap, verify the execution price
 * hasn't deviated too far from the oracle price (front-run protection).
 */
async function checkSwapSlippage(collectionId, executionPriceSats, maxSlippagePct = 5) {
  console.log(`\n━━━ Swap Slippage Check ━━━`);

  const price = await oracle.getFloorPrice(collectionId);
  const floorSats = price.floorPriceSats;

  const slippagePct = Math.abs((executionPriceSats - floorSats) / floorSats) * 100;
  const withinLimit = slippagePct <= maxSlippagePct;

  console.log(`Oracle Floor:      ${(floorSats / 1e8).toFixed(6)} BTC`);
  console.log(`Execution Price:   ${(executionPriceSats / 1e8).toFixed(6)} BTC`);
  console.log(`Slippage:          ${slippagePct.toFixed(2)}% (max: ${maxSlippagePct}%)`);
  console.log(`Swap Valid:        ${withinLimit ? "✅ Execute" : "❌ Reject — too much slippage"}`);

  return { withinLimit, slippagePct };
}

// ─── 3. Dynamic fee based on confidence ──────────────────────
/**
 * Charge higher maker/taker fees during periods of price uncertainty
 * (low oracle confidence = higher fees to account for risk).
 */
async function getDynamicFee(collectionId) {
  console.log(`\n━━━ Dynamic Fee Calculation ━━━`);

  const price = await oracle.getFloorPrice(collectionId);
  const { confidence } = price;

  // Fee schedule based on oracle confidence
  let feePct;
  let feeReason;
  if      (confidence >= 90) { feePct = 0.5;  feeReason = "High confidence — standard fee"; }
  else if (confidence >= 70) { feePct = 1.0;  feeReason = "Medium confidence — elevated fee"; }
  else if (confidence >= 50) { feePct = 1.5;  feeReason = "Low confidence — high fee"; }
  else                       { feePct = 2.5;  feeReason = "Very low confidence — max fee"; }

  console.log(`Collection:   ${price.collectionName}`);
  console.log(`Confidence:   ${confidence}%`);
  console.log(`Fee:          ${feePct}%`);
  console.log(`Reason:       ${feeReason}`);

  return { feePct, confidence };
}

// ─── Main ─────────────────────────────────────────────────────
async function main() {
  console.log("📈 Ordinals Oracle — DEX Integration Demo\n");

  const health = await oracle.getHealth();
  console.log(`RPC: ${health.healthy ? "✅ Online" : "⚠️  Offline"} (${health.network})`);

  // Simulate a new listing at 20% premium over floor
  const estimatedFloor = 4_500_000; // 0.045 BTC — would come from oracle in production
  await validateListing(COLLECTIONS.NODE_MONKES, Math.floor(estimatedFloor * 1.20));

  // Simulate a swap where execution price slipped 3% from oracle
  await checkSwapSlippage(COLLECTIONS.BITCOIN_PUPPETS, Math.floor(estimatedFloor * 0.97), 5);

  // Get dynamic trading fee for a collection
  await getDynamicFee(COLLECTIONS.NODE_MONKES);
}

main().catch((err) => {
  console.error("Fatal:", err.message);
  process.exit(1);
});
