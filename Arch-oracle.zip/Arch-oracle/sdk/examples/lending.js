// ─────────────────────────────────────────────────────────────
// examples/lending.js — Lending Protocol Integration
//
// Shows how a Bitcoin lending protocol would use the oracle to:
//   1. Determine max loan amount for Ordinal collateral
//   2. Check if a position should be liquidated
//   3. Monitor collateral health across all borrowers
//
// Run: node examples/lending.js
// ─────────────────────────────────────────────────────────────

import { OracleClient, COLLECTIONS, OracleError } from "../src/index.js";

// ─── Simulate a lending protocol's open positions ─────────────
const OPEN_POSITIONS = [
  {
    borrowerId:     "borrower_001",
    collectionId:   COLLECTIONS.NODE_MONKES,
    loanAmountSats: 3_000_000,   // 0.03 BTC loan
    openedAt:       "2024-01-15",
  },
  {
    borrowerId:     "borrower_002",
    collectionId:   COLLECTIONS.BITCOIN_PUPPETS,
    loanAmountSats: 2_000_000,   // 0.02 BTC loan
    openedAt:       "2024-01-20",
  },
  {
    borrowerId:     "borrower_003",
    collectionId:   COLLECTIONS.RUNESTONES,
    loanAmountSats: 500_000,     // 0.005 BTC loan
    openedAt:       "2024-02-01",
  },
];

// ─── 1. Calculate max loan for new borrower ───────────────────
async function calculateMaxLoan(oracle, collectionId, ltvRatio = 0.5) {
  console.log(`\n━━━ Max Loan Calculation ━━━`);
  console.log(`Collection: ${collectionId}`);
  console.log(`LTV Ratio:  ${(ltvRatio * 100).toFixed(0)}%`);

  try {
    const ltv = await oracle.getLTV(collectionId, ltvRatio);

    console.log(`Floor Price: ${ltv.floorPriceBTC.toFixed(6)} BTC (${ltv.floorPriceSats.toLocaleString()} sats)`);
    console.log(`Max Loan:    ${ltv.maxLoanBTC.toFixed(6)} BTC (${ltv.maxLoanSats.toLocaleString()} sats)`);
    console.log(`Confidence:  ${ltv.confidence}%`);
    console.log(`Stale:       ${ltv.isStale ? "⚠️ YES" : "✅ No"}`);

    return ltv;
  } catch (err) {
    if (err instanceof OracleError) {
      console.error(`❌ Oracle error: [${err.code}] ${err.message}`);
    } else {
      console.error(`❌ Unexpected error: ${err.message}`);
    }
    return null;
  }
}

// ─── 2. Check individual position health ─────────────────────
async function checkPositionHealth(oracle, position) {
  const { borrowerId, collectionId, loanAmountSats } = position;

  try {
    const result = await oracle.isLiquidatable(collectionId, loanAmountSats, 1.1);

    const statusIcon = result.liquidatable ? "🔴 LIQUIDATE" : "🟢 Healthy";

    console.log(
      `${statusIcon.padEnd(18)} ${borrowerId.padEnd(15)}` +
      `  Collateral: ${(result.currentValueBTC).toFixed(4)} BTC` +
      `  Loan: ${(loanAmountSats / 1e8).toFixed(4)} BTC` +
      `  Health: ${result.healthPct.toFixed(1)}%`
    );

    return result;
  } catch (err) {
    console.log(`❓ Unknown  ${borrowerId.padEnd(15)}  Error: ${err.message}`);
    return null;
  }
}

// ─── 3. Full portfolio health scan ───────────────────────────
async function runLiquidationScan(oracle, positions) {
  console.log(`\n━━━ Liquidation Health Scan ━━━`);
  console.log(`Scanning ${positions.length} open positions...\n`);
  console.log(
    `${"Status".padEnd(18)} ${"Borrower".padEnd(15)}  ${"Collateral".padEnd(22)}` +
    `${"Loan".padEnd(18)}  Health`
  );
  console.log("─".repeat(85));

  const results = await Promise.allSettled(
    positions.map((p) => checkPositionHealth(oracle, p))
  );

  const toBeLiquidated = positions.filter((_, i) => {
    const r = results[i];
    return r.status === "fulfilled" && r.value?.liquidatable;
  });

  console.log("\n─".repeat(85));
  console.log(`\nSummary: ${toBeLiquidated.length} of ${positions.length} positions marked for liquidation`);

  if (toBeLiquidated.length > 0) {
    console.log("Positions to liquidate:");
    toBeLiquidated.forEach((p) => console.log(`  → ${p.borrowerId} (${p.collectionId})`));
  }
}

// ─── 4. Price feed dashboard ─────────────────────────────────
async function showPriceDashboard(oracle) {
  console.log(`\n━━━ Ordinals Price Dashboard ━━━\n`);

  const prices = await oracle.getAllPrices();

  console.log(
    `${"Collection".padEnd(22)}  ${"Floor (BTC)".padEnd(14)}` +
    `${"Floor (sats)".padEnd(16)}  ${"Confidence".padEnd(12)}  Age`
  );
  console.log("─".repeat(78));

  for (const [id, price] of prices) {
    if (price instanceof OracleError) {
      console.log(`${id.padEnd(22)}  ❌ ${price.message}`);
      continue;
    }

    const ageStr = price.ageSecs !== null
      ? `${Math.floor(price.ageSecs / 60)}m ago`
      : "never";
    const staleFlag = price.isStale ? " ⚠️" : "";
    const dirArrow  = price.priceDirection === "up" ? "↑"
                    : price.priceDirection === "down" ? "↓" : "→";

    console.log(
      `${price.collectionName.padEnd(22)}  ` +
      `${price.floorPriceBTC.toFixed(6).padEnd(14)}` +
      `${price.floorPriceSats.toLocaleString().padEnd(16)}  ` +
      `${String(price.confidence + "%").padEnd(12)}  ${ageStr}${staleFlag} ${dirArrow}`
    );
  }
}

// ─── Main ─────────────────────────────────────────────────────
async function main() {
  console.log("🏦 Ordinals Oracle — Lending Protocol Demo\n");

  // Initialize oracle (reads from testnet by default)
  // Pass allowStale: true for demo since we may not have live data yet
  const oracle = new OracleClient({
    network:    "testnet",
    allowStale: true,   // remove this in production!
    minConfidence: 0,   // remove this in production!
  });

  // Check RPC health first
  const health = await oracle.getHealth();
  console.log(`RPC Status: ${health.healthy ? "✅ Online" : "❌ Offline"} (${health.network})`);
  if (!health.healthy) {
    console.log("⚠️  Oracle RPC unavailable — prices may not reflect live data.");
  }

  // Show available collections
  console.log(`\nTracked collections: ${oracle.listCollections().map((c) => c.name).join(", ")}`);

  // 1. New borrower wants to use NodeMonkes as collateral
  await calculateMaxLoan(oracle, COLLECTIONS.NODE_MONKES, 0.5);

  // 2. Full price dashboard
  await showPriceDashboard(oracle);

  // 3. Run liquidation scan across open positions
  await runLiquidationScan(oracle, OPEN_POSITIONS);
}

main().catch((err) => {
  console.error("Fatal:", err.message);
  process.exit(1);
});
