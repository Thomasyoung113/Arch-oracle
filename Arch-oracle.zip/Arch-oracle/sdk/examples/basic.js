// ─────────────────────────────────────────────────────────────
// examples/basic.js — Basic SDK usage
//
// Shows the most common patterns: single price, multi-price, LTV
// Run: node examples/basic.js
// ─────────────────────────────────────────────────────────────

import { OracleClient, OracleSDKError } from "../src/index.js";

// ── 1. Initialize the client ──────────────────────────────────
const oracle = new OracleClient({
  network:    "testnet",
  programId:  "YOUR_PROGRAM_ID_HERE",  // ← paste your deployed program ID
  btcUsdPrice: 65_000,                 // ← optional: your BTC/USD feed
  debug: true,
});

async function main() {

  // ── 2. Get a single price (one liner) ───────────────────────
  console.log("\n── Single Price ──────────────────────────────");
  try {
    const price = await oracle.getPrice("node-monkes");

    console.log(`Collection:   ${price.collectionId}`);
    console.log(`Price:        ${price.priceBTC} BTC`);
    console.log(`Price (sats): ${price.priceSats.toLocaleString()}`);
    if (price.priceUSD) console.log(`Price (USD):  $${price.priceUSD.toLocaleString()}`);
    console.log(`Confidence:   ${price.confidence}%  (${oracle.confidenceLabel(price)})`);
    console.log(`Reporters:    ${price.reporterCount} oracle nodes`);
    console.log(`Updated:      ${price.lastUpdatedAgo}`);
    console.log(`Fresh:        ${price.isFresh ? "✅ Yes" : "❌ No — STALE"}`);
    if (price.priceChangePct !== 0) {
      const dir = price.priceChangePct > 0 ? "▲" : "▼";
      console.log(`Change:       ${dir} ${Math.abs(price.priceChangePct)}%`);
    }

    // One-line formatted display
    console.log(`Display:      ${oracle.formatPrice(price)}`);
  } catch (err) {
    if (err instanceof OracleSDKError) {
      console.error(`Oracle error [${err.code}]: ${err.message}`);
    } else {
      throw err;
    }
  }

  // ── 3. Get multiple prices at once ──────────────────────────
  console.log("\n── Multi-Collection Feed ─────────────────────");
  const feed = await oracle.getPrices([
    "node-monkes",
    "bitcoin-puppets",
    "ordinal-maxi-biz",
    "runestones",
    "bitcoin-frogs",
  ]);

  console.log(`Fetched at: ${new Date(feed.fetchedAt * 1000).toISOString()}`);
  console.log(`Network:    ${feed.network}`);
  console.log("\nPrices:");
  for (const [id, price] of Object.entries(feed.prices)) {
    const freshIcon = price.isFresh ? "✅" : "⚠️";
    console.log(`  ${freshIcon} ${id.padEnd(22)} ${oracle.formatPrice(price)}`);
  }

  // ── 4. LTV calculation for lending ──────────────────────────
  console.log("\n── LTV Calculation (for lending protocol) ───");
  try {
    const { maxLoanSats, effectiveLTV, confidence } = await oracle.getLTV(
      "node-monkes",
      0.5,   // 50% target LTV
      70     // require at least 70% confidence
    );

    console.log(`Collateral:    NodeMonkes Ordinal`);
    console.log(`Target LTV:    50%`);
    console.log(`Confidence:    ${confidence}%`);
    console.log(`Effective LTV: ${(effectiveLTV * 100).toFixed(1)}%`);
    console.log(`Max loan:      ${(maxLoanSats / 1e8).toFixed(6)} BTC`);
    console.log(`Max loan:      ${maxLoanSats.toLocaleString()} sats`);
  } catch (err) {
    console.error("LTV error:", err.message);
  }

  // ── 5. Health check (circuit breaker) ───────────────────────
  console.log("\n── Health Check ──────────────────────────────");
  const healthy = await oracle.isHealthy("node-monkes");
  console.log(`NodeMonkes feed healthy: ${healthy ? "✅ Yes" : "❌ No"}`);
  if (!healthy) {
    console.log("→ Do NOT use this price for liquidations until feed recovers.");
  }

}

main().catch(console.error);
