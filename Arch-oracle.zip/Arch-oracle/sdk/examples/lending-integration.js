// ─────────────────────────────────────────────────────────────
// examples/lending-integration.js
//
// Shows exactly how a lending protocol on Arch would integrate
// the oracle for: collateral valuation, LTV enforcement,
// liquidation triggering, and health factor monitoring.
// ─────────────────────────────────────────────────────────────

import { OracleClient, OracleSDKError } from "../src/index.js";

// ── Setup ─────────────────────────────────────────────────────
const oracle = new OracleClient({
  network:    "testnet",
  programId:  "YOUR_PROGRAM_ID_HERE",
  btcUsdPrice: 65_000,
});

// ── Simulated loan book ────────────────────────────────────────
const LOAN_BOOK = [
  { loanId: "LOAN-001", borrower: "alice", collection: "node-monkes",      loanAmountSats: 1_800_000, ltv: 0.5  },
  { loanId: "LOAN-002", borrower: "bob",   collection: "bitcoin-puppets",   loanAmountSats: 800_000,   ltv: 0.4  },
  { loanId: "LOAN-003", borrower: "carol", collection: "ordinal-maxi-biz",  loanAmountSats: 500_000,   ltv: 0.35 },
];

// ── Constants ─────────────────────────────────────────────────
const LIQUIDATION_THRESHOLD = 0.80; // liquidate when loan > 80% of collateral value
const HEALTH_FACTOR_SAFE    = 1.25; // health factor < 1.0 = undercollateralized

// ── Core lending functions ────────────────────────────────────

/**
 * Calculate the health factor for a loan.
 * health factor = (collateral value * liquidation threshold) / loan amount
 * If health factor < 1.0 → position is undercollateralized → liquidate
 */
function calcHealthFactor(collateralSats: number, loanSats: number): number {
  return (collateralSats * LIQUIDATION_THRESHOLD) / loanSats;
}

/**
 * Check all loans against current oracle prices.
 * Flag any that should be liquidated.
 */
async function runLiquidationCheck() {
  console.log("\n╔════════════════════════════════════════════╗");
  console.log("║       Liquidation Monitor — Running        ║");
  console.log("╚════════════════════════════════════════════╝\n");

  // Fetch all needed collection prices in one batch call
  const collections = [...new Set(LOAN_BOOK.map((l) => l.collection))];
  const feed = await oracle.getPrices(collections);

  const toliquidate: typeof LOAN_BOOK = [];

  for (const loan of LOAN_BOOK) {
    const price = feed.prices[loan.collection];

    if (!price) {
      console.warn(`⚠️  [${loan.loanId}] No price data for ${loan.collection} — skipping`);
      continue;
    }

    if (!price.isFresh) {
      console.warn(`⚠️  [${loan.loanId}] Price stale (${price.lastUpdatedAgo}) — NOT liquidating`);
      console.warn(`       Never liquidate on stale oracle data.`);
      continue;
    }

    const healthFactor = calcHealthFactor(price.priceSats, loan.loanAmountSats);
    const loanPct      = (loan.loanAmountSats / price.priceSats * 100).toFixed(1);
    const icon         = healthFactor >= HEALTH_FACTOR_SAFE ? "✅" : healthFactor >= 1.0 ? "⚠️ " : "🔴";

    console.log(`${icon} ${loan.loanId} (${loan.borrower})`);
    console.log(`   Collection:     ${loan.collection}`);
    console.log(`   Floor price:    ${price.priceBTC} BTC  [confidence: ${price.confidence}%]`);
    console.log(`   Loan amount:    ${(loan.loanAmountSats / 1e8).toFixed(6)} BTC`);
    console.log(`   Loan / Floor:   ${loanPct}%`);
    console.log(`   Health factor:  ${healthFactor.toFixed(3)}  ${healthFactor < 1.0 ? "← UNDERWATER" : ""}`);
    console.log();

    if (healthFactor < 1.0) {
      toliquidate.push(loan);
    }
  }

  if (toliquidate.length === 0) {
    console.log("✅ All positions are healthy. No liquidations needed.\n");
  } else {
    console.log(`🔴 ${toliquidate.length} position(s) to liquidate:`);
    for (const loan of toliquidate) {
      console.log(`   → ${loan.loanId} (${loan.borrower})`);
      // In production: call your Arch lending program's liquidate() instruction
      // await archLendingProgram.liquidate(loan.loanId, oracle prices)
    }
    console.log();
  }
}

/**
 * Originate a new loan — validate oracle price before accepting collateral.
 */
async function originateLoan(
  collectionId: string,
  requestedLoanSats: number,
  targetLTV: number
) {
  console.log(`\n── Loan Origination: ${collectionId} ──`);

  // 1. Health check — abort if oracle is unhealthy
  const healthy = await oracle.isHealthy(collectionId);
  if (!healthy) {
    throw new Error(`Oracle unhealthy for ${collectionId}. Cannot originate loan.`);
  }

  // 2. Get LTV-adjusted max loan
  const { maxLoanSats, effectiveLTV, confidence } = await oracle.getLTV(
    collectionId,
    targetLTV,
    75 // require high confidence for loan origination
  );

  console.log(`Oracle confidence:  ${confidence}%`);
  console.log(`Target LTV:         ${(targetLTV * 100).toFixed(0)}%`);
  console.log(`Effective LTV:      ${(effectiveLTV * 100).toFixed(1)}% (adjusted for confidence)`);
  console.log(`Max loan allowed:   ${(maxLoanSats / 1e8).toFixed(6)} BTC`);
  console.log(`Requested loan:     ${(requestedLoanSats / 1e8).toFixed(6)} BTC`);

  // 3. Validate loan amount
  if (requestedLoanSats > maxLoanSats) {
    throw new Error(
      `Loan rejected: requested ${requestedLoanSats} sats exceeds max ${maxLoanSats} sats ` +
      `(LTV ${(effectiveLTV * 100).toFixed(1)}%)`
    );
  }

  console.log(`✅ Loan approved! ${(requestedLoanSats / 1e8).toFixed(6)} BTC`);
  return { approved: true, requestedLoanSats, maxLoanSats, effectiveLTV };
}

/**
 * Subscribe to price updates and run liquidation checks automatically.
 */
function startLiquidationMonitor() {
  console.log("🔄 Starting liquidation monitor (checking every 2 minutes)...\n");

  const sub = oracle.subscribe({
    collections: [...new Set(LOAN_BOOK.map((l) => l.collection))],
    intervalMs: 120_000, // every 2 minutes

    onUpdate: async (feed) => {
      console.log(`\n[${new Date().toISOString()}] Price update received`);
      await runLiquidationCheck();
    },

    onError: (err) => {
      console.error("Oracle subscription error:", err.message);
      // In production: alert your team via PagerDuty / Discord
    },
  });

  // Stop after 10 minutes in this demo
  setTimeout(() => {
    sub.unsubscribe();
    console.log("Monitor stopped.");
  }, 10 * 60 * 1000);

  return sub;
}

// ── Run ───────────────────────────────────────────────────────
async function main() {
  // Single liquidation check
  await runLiquidationCheck();

  // Test loan origination
  try {
    await originateLoan("node-monkes", 1_500_000, 0.5);
  } catch (err) {
    console.error("Loan rejected:", err.message);
  }

  // Uncomment to start live monitor:
  // startLiquidationMonitor()
}

main().catch(console.error);
