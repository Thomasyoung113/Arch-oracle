// ─────────────────────────────────────────────────────────────
// examples/subscribe.js
//
// Live price monitoring with the subscribe API.
// Useful for: dashboards, bots, price alert systems.
// Run: node examples/subscribe.js
// ─────────────────────────────────────────────────────────────

import { OracleClient } from "../src/index.js";

const oracle = new OracleClient({
  network:    "testnet",
  programId:  "YOUR_PROGRAM_ID_HERE",
  btcUsdPrice: 65_000,
});

const COLLECTIONS = [
  "node-monkes",
  "bitcoin-puppets",
  "ordinal-maxi-biz",
  "runestones",
];

// Track previous prices to detect changes
const prevPrices: Record<string, number> = {};

function printFeed(feed: import("../src/index.js").PriceFeedResult) {
  console.clear();
  console.log(`╔${"═".repeat(60)}╗`);
  console.log(`║  Ordinals Oracle — Live Feed                           ║`);
  console.log(`║  Network: ${feed.network.padEnd(8)} Updated: ${new Date(feed.fetchedAt * 1000).toLocaleTimeString().padEnd(20)}║`);
  console.log(`╚${"═".repeat(60)}╝`);
  console.log();

  for (const [id, price] of Object.entries(feed.prices)) {
    const prev = prevPrices[id];
    const changed = prev !== undefined && prev !== price.priceSats;
    const changeIcon = !changed ? "  " : price.priceSats > prev ? "▲ " : "▼ ";
    const freshIcon = price.isFresh ? "●" : "○";

    console.log(`  ${freshIcon} ${changeIcon}${price.collectionId}`);
    console.log(`       ${oracle.formatPrice(price)}`);
    console.log(`       Confidence: ${price.confidence}% [${oracle.confidenceLabel(price)}]  •  ${price.lastUpdatedAgo}`);
    console.log();

    prevPrices[id] = price.priceSats;
  }

  console.log(`  ● = fresh  ○ = stale  ▲ = up  ▼ = down`);
  console.log(`  Refreshing every 2 minutes. CTRL+C to stop.`);
}

console.log("Starting Ordinals Oracle live feed...");

const sub = oracle.subscribe({
  collections: COLLECTIONS,
  intervalMs: 120_000,
  onUpdate: printFeed,
  onError: (err) => console.error("\nFeed error:", err.message),
});

// Graceful shutdown
process.on("SIGINT", () => {
  console.log("\nStopping feed...");
  sub.unsubscribe();
  process.exit(0);
});
