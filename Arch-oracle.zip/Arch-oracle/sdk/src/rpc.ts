// ─────────────────────────────────────────────────────────────
// rpc.ts — Low-level Arch Network RPC client
//
// Handles JSON-RPC communication with Arch nodes.
// All higher-level SDK methods build on top of this.
// ─────────────────────────────────────────────────────────────

import axios, { AxiosInstance } from "axios";
import {
  Network,
  NETWORK_RPC_URLS,
  OracleSDKError,
  RawOracleState,
} from "./types.js";

interface JsonRpcRequest {
  jsonrpc: "2.0";
  id: number;
  method: string;
  params: unknown[];
}

interface JsonRpcResponse<T> {
  jsonrpc: "2.0";
  id: number;
  result?: T;
  error?: { code: number; message: string };
}

export class ArchRPCClient {
  private http: AxiosInstance;
  private requestId = 1;
  private debug: boolean;

  constructor(
    network: Network,
    rpcUrl?: string,
    timeoutMs = 10_000,
    debug = false
  ) {
    const url = rpcUrl ?? NETWORK_RPC_URLS[network];
    this.debug = debug;

    this.http = axios.create({
      baseURL: url,
      timeout: timeoutMs,
      headers: {
        "Content-Type": "application/json",
        "User-Agent": "OrdinalsOracleSDK/0.1.0",
      },
    });

    if (debug) console.log(`[OracleSDK] RPC connected to: ${url}`);
  }

  // ─── Generic RPC call ───────────────────────────────────────
  private async call<T>(method: string, params: unknown[]): Promise<T> {
    const payload: JsonRpcRequest = {
      jsonrpc: "2.0",
      id: this.requestId++,
      method,
      params,
    };

    if (this.debug) console.log(`[OracleSDK] RPC →`, method, params);

    try {
      const { data } = await this.http.post<JsonRpcResponse<T>>("", payload);

      if (data.error) {
        throw new OracleSDKError(
          "RPC_ERROR",
          `RPC error ${data.error.code}: ${data.error.message}`
        );
      }

      if (data.result === undefined) {
        throw new OracleSDKError("INVALID_RESPONSE", "RPC returned no result");
      }

      if (this.debug) console.log(`[OracleSDK] RPC ←`, data.result);

      return data.result;
    } catch (err) {
      if (err instanceof OracleSDKError) throw err;
      throw new OracleSDKError(
        "NETWORK_ERROR",
        `Network error: ${(err as Error).message}`,
        err
      );
    }
  }

  // ─── Get current block count ────────────────────────────────
  async getBlockCount(): Promise<number> {
    return this.call<number>("get_block_count", []);
  }

  // ─── Read oracle state account ──────────────────────────────
  /**
   * Fetch the raw on-chain OracleState for a given collection.
   * The account address is derived as PDA: ["oracle", collection_id]
   */
  async getOracleState(
    programId: string,
    collectionId: string
  ): Promise<RawOracleState> {
    // Derive the oracle state account address
    // This mirrors the PDA derivation in the Rust program
    const accountAddress = deriveOracleStateAddress(programId, collectionId);

    if (this.debug) {
      console.log(`[OracleSDK] Fetching oracle state for: ${collectionId}`);
      console.log(`[OracleSDK] Account address: ${accountAddress}`);
    }

    // Fetch the account data from Arch
    const accountData = await this.call<{ data: string; owner: string }>(
      "get_account_info",
      [accountAddress]
    );

    if (!accountData?.data) {
      throw new OracleSDKError(
        "COLLECTION_NOT_FOUND",
        `No oracle account found for collection: ${collectionId}. ` +
          `Ensure the collection has been initialized on-chain.`
      );
    }

    // Decode the Borsh-encoded account data
    // In production, use a proper Borsh decoder matching state.rs
    // For now, we parse the JSON-encoded data Arch returns for program accounts
    try {
      const decoded = decodeOracleState(accountData.data);
      return decoded;
    } catch (err) {
      throw new OracleSDKError(
        "INVALID_RESPONSE",
        `Failed to decode oracle state for ${collectionId}`,
        err
      );
    }
  }

  // ─── Call GetFloorPrice instruction ─────────────────────────
  /**
   * Invoke the oracle program's GetFloorPrice instruction.
   * This is a read-only call — no transaction, no fees.
   * Returns the price from the program logs.
   */
  async callGetFloorPrice(
    programId: string,
    collectionId: string
  ): Promise<RawOracleState> {
    // Arch supports simulated instruction calls for read-only queries
    const accountAddress = deriveOracleStateAddress(programId, collectionId);

    const result = await this.call<{
      logs: string[];
      state: Record<string, unknown>;
    }>("simulate_instruction", [
      {
        program_id: programId,
        instruction: "GetFloorPrice",
        args: { collection_id: collectionId },
        accounts: [{ pubkey: accountAddress, is_signer: false, is_writable: false }],
      },
    ]);

    // Parse price from program logs
    // The Rust program emits: ORACLE_PRICE collection=X price_sats=Y ...
    const priceLine = result.logs?.find((l) => l.startsWith("ORACLE_PRICE"));
    if (priceLine) {
      return parseOraclePriceLog(priceLine, collectionId);
    }

    // Fallback: read directly from account state
    return this.getOracleState(programId, collectionId);
  }
}

// ─── PDA Derivation ───────────────────────────────────────────
/**
 * Derive the oracle state account address for a collection.
 * Must match the Rust program's find_program_address logic:
 *   seeds = [b"oracle", collection_id.as_bytes()]
 */
function deriveOracleStateAddress(
  programId: string,
  collectionId: string
): string {
  // TODO: Implement proper PDA derivation using Arch SDK
  // For now, return a deterministic placeholder that matches the Rust program
  // Replace with: ArchPDA.findAddress(programId, ["oracle", collectionId])
  const encoded = Buffer.from(collectionId).toString("hex");
  return `${programId}_oracle_${encoded}`;
}

// ─── Borsh Decoder ────────────────────────────────────────────
/**
 * Decode Borsh-encoded OracleState account data.
 * Arch returns account data as base64. We decode it here.
 *
 * Field layout (matches state.rs OracleState):
 *   collection_id: String (4-byte length prefix + UTF-8 bytes)
 *   floor_price_sats: u64 (8 bytes, little-endian)
 *   last_updated: u64 (8 bytes)
 *   reporter_count: u8 (1 byte)
 *   confidence: u8 (1 byte)
 *   prev_price_sats: u64 (8 bytes)
 *   is_initialized: bool (1 byte)
 *   bump: u8 (1 byte)
 *   version: u8 (1 byte)
 */
function decodeOracleState(base64Data: string): RawOracleState {
  const buf = Buffer.from(base64Data, "base64");
  let offset = 0;

  // Read Borsh String: 4-byte LE length prefix + UTF-8 bytes
  const idLen = buf.readUInt32LE(offset);
  offset += 4;
  const collection_id = buf.slice(offset, offset + idLen).toString("utf8");
  offset += idLen;

  // Read u64 fields (8 bytes each, little-endian)
  // Note: JavaScript BigInt needed for full u64 range, but prices fit in Number
  const floor_price_sats = Number(buf.readBigUInt64LE(offset));
  offset += 8;
  const last_updated = Number(buf.readBigUInt64LE(offset));
  offset += 8;

  // Read u8 fields (1 byte each)
  const reporter_count = buf.readUInt8(offset++);
  const confidence = buf.readUInt8(offset++);

  const prev_price_sats = Number(buf.readBigUInt64LE(offset));
  offset += 8;

  const is_initialized = buf.readUInt8(offset++) === 1;
  offset++; // bump
  const version = buf.readUInt8(offset++);

  return {
    collection_id,
    floor_price_sats,
    last_updated,
    reporter_count,
    confidence,
    prev_price_sats,
    is_initialized,
    version,
  };
}

// ─── Log Parser ───────────────────────────────────────────────
/**
 * Parse an ORACLE_PRICE log line emitted by the Rust program.
 * Format: "ORACLE_PRICE collection=X price_sats=Y confidence=Z last_updated=T reporter_count=N"
 */
function parseOraclePriceLog(
  log: string,
  collectionId: string
): RawOracleState {
  const get = (key: string): string => {
    const match = log.match(new RegExp(`${key}=([^\\s]+)`));
    return match?.[1] ?? "0";
  };

  return {
    collection_id: collectionId,
    floor_price_sats: parseInt(get("price_sats"), 10),
    last_updated: parseInt(get("last_updated"), 10),
    reporter_count: parseInt(get("reporter_count"), 10),
    confidence: parseInt(get("confidence"), 10),
    prev_price_sats: 0,
    is_initialized: true,
    version: 1,
  };
}
