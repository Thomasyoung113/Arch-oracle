// ─────────────────────────────────────────────────────────────
// rpc.js — Low-level Arch Network RPC client
//
// Wraps the Arch JSON-RPC interface.
// Higher-level SDK methods are built on top of this.
// ─────────────────────────────────────────────────────────────

import axios from "axios";
import { NETWORKS, ORACLE_CONFIG } from "./constants.js";

export class ArchRpcClient {
  /**
   * @param {string} network - "testnet" | "mainnet" | "regtest"
   * @param {Object} [options]
   * @param {string} [options.rpcUrl]       - Override RPC URL
   * @param {number} [options.timeoutMs]    - Request timeout in ms
   */
  constructor(network = "testnet", options = {}) {
    const net = NETWORKS[network];
    if (!net) throw new Error(`Unknown network: "${network}". Use testnet, mainnet, or regtest.`);

    this.network    = network;
    this.networkMeta = net;
    this.rpcUrl     = options.rpcUrl ?? net.rpcUrl;
    this._reqId     = 0;

    this._http = axios.create({
      baseURL: this.rpcUrl,
      timeout: options.timeoutMs ?? ORACLE_CONFIG.DEFAULT_TIMEOUT_MS,
      headers: { "Content-Type": "application/json" },
    });
  }

  // ─── Core RPC call ──────────────────────────────────────────
  async _call(method, params = []) {
    const id = ++this._reqId;
    const body = { jsonrpc: "2.0", id, method, params };

    try {
      const { data } = await this._http.post("/", body);

      if (data.error) {
        throw new OracleRpcError(data.error.message, data.error.code, method);
      }

      return data.result;
    } catch (err) {
      if (err instanceof OracleRpcError) throw err;
      throw new OracleRpcError(
        `RPC request failed: ${err.message}`,
        -1,
        method
      );
    }
  }

  // ─── Read account data ──────────────────────────────────────
  /**
   * Fetch raw account data for a given public key.
   * Returns null if account doesn't exist.
   */
  async getAccountInfo(pubkey) {
    const result = await this._call("get_account_info", [pubkey]);
    return result ?? null;
  }

  // ─── Invoke a program (read-only simulation) ────────────────
  /**
   * Simulate a program instruction without submitting a transaction.
   * Used for read-only calls like GetFloorPrice.
   * Returns the program logs as a string array.
   */
  async simulateInstruction({ programId, accounts, instructionData }) {
    const result = await this._call("simulate_transaction", [
      {
        version: 1,
        message: {
          instructions: [
            {
              program_id: programId,
              accounts:   accounts.map((a) => ({
                pubkey:      a.pubkey,
                is_signer:   a.isSigner   ?? false,
                is_writable: a.isWritable ?? false,
              })),
              data: Buffer.from(JSON.stringify(instructionData)).toString("base64"),
            },
          ],
        },
      },
    ]);

    return result?.logs ?? [];
  }

  // ─── Send a signed transaction ──────────────────────────────
  async sendTransaction(transaction) {
    return this._call("send_transaction", [transaction]);
  }

  // ─── Network info ───────────────────────────────────────────
  async getBlockCount() {
    return this._call("get_block_count");
  }

  async getHealth() {
    try {
      const blockCount = await this.getBlockCount();
      return { healthy: true, blockCount, network: this.network };
    } catch {
      return { healthy: false, blockCount: null, network: this.network };
    }
  }

  /** Explorer URL for a transaction */
  txUrl(txId) {
    const base = this.networkMeta.explorer;
    return base ? `${base}/tx/${txId}` : null;
  }

  /** Explorer URL for an account */
  accountUrl(pubkey) {
    const base = this.networkMeta.explorer;
    return base ? `${base}/account/${pubkey}` : null;
  }
}

// ─── Custom Error ─────────────────────────────────────────────
export class OracleRpcError extends Error {
  constructor(message, code, method) {
    super(message);
    this.name   = "OracleRpcError";
    this.code   = code;
    this.method = method;
  }
}
