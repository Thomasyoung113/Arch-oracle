// ─────────────────────────────────────────────────────────────
// client.js — OracleClient: main SDK class
//
// This is what protocols import and use.
// Everything else in the SDK is an implementation detail.
//
// Usage:
//   import { OracleClient } from "@ordinals-oracle/sdk";
//   const oracle = new OracleClient({ network: "testnet" });
//   const price  = await oracle.getFloorPrice("node-monkes");
// ─────────────────────────────────────────────────────────────

import { ArchRpcClient, OracleRpcError } from "./rpc.js";
import { decodeOracleState, parsePriceFromLogs } from "./parser.js";
import { deriveOracleStateAddress, deriveRegistryAddress } from "./pda.js";
import {
  ORACLE_PROGRAM_IDS,
  COLLECTIONS,
  COLLECTION_META,
  ORACLE_CONFIG,
} from "./constants.js";

export class OracleClient {
  /**
   * @param {Object} options
   * @param {string}  [options.network="testnet"]   - "testnet" | "mainnet" | "regtest"
   * @param {string}  [options.programId]           - Override oracle program ID
   * @param {string}  [options.rpcUrl]              - Override RPC URL
   * @param {number}  [options.timeoutMs]           - RPC timeout in ms
   * @param {boolean} [options.allowStale=false]    - Return stale prices instead of throwing
   * @param {number}  [options.minConfidence=50]    - Minimum confidence score to accept
   */
  constructor(options = {}) {
    this.network       = options.network ?? "testnet";
    this.programId     = options.programId ?? ORACLE_PROGRAM_IDS[this.network];
    this.allowStale    = options.allowStale ?? false;
    this.minConfidence = options.minConfidence ?? ORACLE_CONFIG.MIN_CONFIDENCE;

    this._rpc = new ArchRpcClient(this.network, {
      rpcUrl:    options.rpcUrl,
      timeoutMs: options.timeoutMs,
    });

    // Simple in-memory cache: collectionId → { price, fetchedAt }
    this._cache = new Map();
    this._cacheTtlMs = options.cacheTtlMs ?? 60_000; // 60s client-side cache
  }

  // ─── getFloorPrice ──────────────────────────────────────────
  /**
   * Get the current floor price for an Ordinals collection.
   * This is the primary method most protocols will use.
   *
   * @param {string} collectionId - e.g. "node-monkes" or COLLECTIONS.NODE_MONKES
   * @returns {Promise<OraclePrice>} Current price with metadata
   * @throws {OracleError} If price is stale, confidence too low, or feed not found
   *
   * @example
   * const price = await oracle.getFloorPrice("node-monkes");
   * console.log(price.floorPriceBTC);   // 0.045
   * console.log(price.floorPriceSats);  // 4500000
   * console.log(price.confidence);      // 92
   */
  async getFloorPrice(collectionId) {
    this._validateCollectionId(collectionId);

    // Check client-side cache first
    const cached = this._getCached(collectionId);
    if (cached) return cached;

    const price = await this._fetchPrice(collectionId);

    // Validate quality
    if (!this.allowStale && price.isStale) {
      throw new OracleError(
        `Price feed for "${collectionId}" is stale (last update: ${price.ageSecs}s ago)`,
        "STALE_PRICE",
        { collectionId, ageSecs: price.ageSecs }
      );
    }

    if (price.confidence < this.minConfidence) {
      throw new OracleError(
        `Price confidence too low for "${collectionId}": ${price.confidence}% (min: ${this.minConfidence}%)`,
        "LOW_CONFIDENCE",
        { collectionId, confidence: price.confidence }
      );
    }

    this._setCached(collectionId, price);
    return price;
  }

  // ─── getFloorPriceSats ──────────────────────────────────────
  /**
   * Convenience method — returns just the floor price in satoshis.
   * Ideal for use in on-chain-aware off-chain logic (lending bots, etc.)
   *
   * @param {string} collectionId
   * @returns {Promise<number>} Floor price in satoshis
   *
   * @example
   * const sats = await oracle.getFloorPriceSats("node-monkes");
   * const maxLoan = sats * 0.5; // 50% LTV
   */
  async getFloorPriceSats(collectionId) {
    const price = await this.getFloorPrice(collectionId);
    return price.floorPriceSats;
  }

  // ─── getFloorPriceBTC ───────────────────────────────────────
  /**
   * Convenience method — returns floor price in BTC (as decimal number).
   *
   * @param {string} collectionId
   * @returns {Promise<number>} Floor price in BTC
   */
  async getFloorPriceBTC(collectionId) {
    const price = await this.getFloorPrice(collectionId);
    return price.floorPriceBTC;
  }

  // ─── getMultiplePrices ──────────────────────────────────────
  /**
   * Fetch prices for multiple collections in parallel.
   * Failed collections are included with an error field instead of throwing.
   *
   * @param {string[]} collectionIds
   * @returns {Promise<Map<string, OraclePrice|OracleError>>}
   *
   * @example
   * const prices = await oracle.getMultiplePrices([
   *   "node-monkes",
   *   "bitcoin-puppets",
   *   "runestones",
   * ]);
   * for (const [id, price] of prices) {
   *   if (price instanceof OracleError) console.error(id, price.message);
   *   else console.log(id, price.floorPriceBTC);
   * }
   */
  async getMultiplePrices(collectionIds) {
    const results = await Promise.allSettled(
      collectionIds.map((id) => this.getFloorPrice(id))
    );

    const map = new Map();
    collectionIds.forEach((id, i) => {
      const result = results[i];
      map.set(
        id,
        result.status === "fulfilled" ? result.value : result.reason
      );
    });
    return map;
  }

  // ─── getAllPrices ────────────────────────────────────────────
  /**
   * Fetch prices for all tracked collections.
   * Useful for dashboards and portfolio valuation.
   *
   * @returns {Promise<Map<string, OraclePrice|OracleError>>}
   */
  async getAllPrices() {
    return this.getMultiplePrices(Object.values(COLLECTIONS));
  }

  // ─── isStale ────────────────────────────────────────────────
  /**
   * Check if a price feed is stale without fetching the full price.
   * Useful for monitoring scripts.
   *
   * @param {string} collectionId
   * @returns {Promise<boolean>}
   */
  async isStale(collectionId) {
    try {
      const price = await this._fetchPrice(collectionId);
      return price.isStale;
    } catch {
      return true; // if we can't fetch, assume stale
    }
  }

  // ─── getLTV ─────────────────────────────────────────────────
  /**
   * Calculate the maximum loan amount for an Ordinal used as collateral.
   * Applies a loan-to-value ratio to the floor price.
   *
   * @param {string} collectionId
   * @param {number} [ltvRatio=0.5] - e.g. 0.5 = 50% LTV
   * @returns {Promise<{ maxLoanSats: number, floorPriceSats: number, ltvRatio: number }>}
   *
   * @example
   * // For a lending protocol: what's the max loan for a NodeMonkes holder?
   * const { maxLoanSats } = await oracle.getLTV("node-monkes", 0.5);
   */
  async getLTV(collectionId, ltvRatio = 0.5) {
    if (ltvRatio <= 0 || ltvRatio >= 1) {
      throw new OracleError("ltvRatio must be between 0 and 1 (exclusive)", "INVALID_LTV");
    }

    const price = await this.getFloorPrice(collectionId);
    const maxLoanSats = Math.floor(price.floorPriceSats * ltvRatio);

    return {
      collectionId,
      collectionName:  price.collectionName,
      floorPriceSats:  price.floorPriceSats,
      floorPriceBTC:   price.floorPriceBTC,
      ltvRatio,
      maxLoanSats,
      maxLoanBTC:      maxLoanSats / 1e8,
      confidence:      price.confidence,
      isStale:         price.isStale,
    };
  }

  // ─── isLiquidatable ─────────────────────────────────────────
  /**
   * Check if a collateralized position is liquidatable.
   * Returns true when current collateral value < loan amount / health factor.
   *
   * @param {string} collectionId
   * @param {number} loanAmountSats - Outstanding loan in sats
   * @param {number} [healthFactor=1.1] - Liquidation threshold (110%)
   * @returns {Promise<{ liquidatable: boolean, currentValueSats: number, healthRatio: number }>}
   *
   * @example
   * // Liquidation bot: should we liquidate this position?
   * const { liquidatable, healthRatio } = await oracle.isLiquidatable(
   *   "node-monkes",
   *   3_000_000, // 0.03 BTC loan
   *   1.1        // liquidate if collateral < 110% of loan
   * );
   */
  async isLiquidatable(collectionId, loanAmountSats, healthFactor = 1.1) {
    const price = await this.getFloorPrice(collectionId);
    const currentValueSats = price.floorPriceSats;
    const liquidationThresholdSats = Math.ceil(loanAmountSats * healthFactor);
    const healthRatio = currentValueSats / loanAmountSats;
    const liquidatable = currentValueSats < liquidationThresholdSats;

    return {
      collectionId,
      liquidatable,
      currentValueSats,
      currentValueBTC:           currentValueSats / 1e8,
      loanAmountSats,
      liquidationThresholdSats,
      healthRatio:               parseFloat(healthRatio.toFixed(4)),
      healthPct:                 parseFloat((healthRatio * 100).toFixed(2)),
      priceConfidence:           price.confidence,
      priceIsStale:              price.isStale,
    };
  }

  // ─── getHealth ──────────────────────────────────────────────
  /**
   * Check if the oracle and RPC are healthy.
   *
   * @returns {Promise<{ healthy: boolean, blockCount: number|null, network: string }>}
   */
  async getHealth() {
    return this._rpc.getHealth();
  }

  // ─── listCollections ────────────────────────────────────────
  /**
   * List all collections tracked by this oracle instance.
   *
   * @returns {Array<{ id: string, name: string, supply: number }>}
   */
  listCollections() {
    return Object.entries(COLLECTIONS).map(([, id]) => ({
      id,
      ...COLLECTION_META[id],
    }));
  }

  // ─── Internal: fetch price from chain ───────────────────────
  async _fetchPrice(collectionId) {
    if (!this.programId || this.programId === "DEPLOY_TO_GET_PROGRAM_ID") {
      throw new OracleError(
        "Oracle program ID not configured. Set ORACLE_PROGRAM_ID_TESTNET env var or pass programId to constructor.",
        "NOT_CONFIGURED"
      );
    }

    const oracleStateAccount = deriveOracleStateAddress(this.programId, collectionId);

    try {
      // First try: read account data directly (most efficient)
      const accountInfo = await this._rpc.getAccountInfo(oracleStateAccount);

      if (accountInfo?.data) {
        const raw = Buffer.from(accountInfo.data, "base64");
        return decodeOracleState(raw);
      }

      // Fallback: simulate GetFloorPrice instruction and parse logs
      const logs = await this._rpc.simulateInstruction({
        programId: this.programId,
        accounts:  [{ pubkey: oracleStateAccount, isSigner: false, isWritable: false }],
        instructionData: { instruction: "GetFloorPrice", args: { collection_id: collectionId } },
      });

      const price = parsePriceFromLogs(logs);
      if (!price) {
        throw new OracleError(
          `No price data found for "${collectionId}". Is this collection initialized?`,
          "NOT_FOUND",
          { collectionId }
        );
      }

      return price;
    } catch (err) {
      if (err instanceof OracleError) throw err;
      throw new OracleError(
        `Failed to fetch price for "${collectionId}": ${err.message}`,
        "FETCH_FAILED",
        { collectionId, cause: err.message }
      );
    }
  }

  // ─── Cache helpers ───────────────────────────────────────────
  _getCached(collectionId) {
    const entry = this._cache.get(collectionId);
    if (!entry) return null;
    if (Date.now() - entry.fetchedAt > this._cacheTtlMs) {
      this._cache.delete(collectionId);
      return null;
    }
    return entry.price;
  }

  _setCached(collectionId, price) {
    this._cache.set(collectionId, { price, fetchedAt: Date.now() });
  }

  clearCache() {
    this._cache.clear();
  }

  // ─── Validation ──────────────────────────────────────────────
  _validateCollectionId(collectionId) {
    if (!collectionId || typeof collectionId !== "string") {
      throw new OracleError("collectionId must be a non-empty string", "INVALID_INPUT");
    }
  }
}

// ─── OracleError ─────────────────────────────────────────────
export class OracleError extends Error {
  constructor(message, code = "UNKNOWN", context = {}) {
    super(message);
    this.name    = "OracleError";
    this.code    = code;
    this.context = context;
  }
}
