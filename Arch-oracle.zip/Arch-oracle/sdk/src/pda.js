// ─────────────────────────────────────────────────────────────
// pda.js — Program Derived Address (PDA) computation
//
// Mirrors the Rust program's find_program_address logic.
// Every account address is deterministic from its seeds + program ID.
// This means callers never need to store account addresses —
// they can always re-derive them.
// ─────────────────────────────────────────────────────────────

import { PDA_SEEDS } from "./constants.js";

// ─── Simple deterministic address derivation ──────────────────
// Arch uses a similar PDA scheme to Solana.
// For testnet, we derive a string-based address from seeds.
// In production this should use the canonical hash-based PDA from the Arch SDK.

/**
 * Derive the OracleState account address for a collection.
 * Seeds: ["oracle", collection_id]
 *
 * @param {string} programId  - The oracle program ID
 * @param {string} collectionId - e.g. "node-monkes"
 * @returns {string} The PDA account address
 */
export function deriveOracleStateAddress(programId, collectionId) {
  return derivePDA(programId, [PDA_SEEDS.ORACLE_STATE, collectionId]);
}

/**
 * Derive the PendingPool account address for a collection.
 * Seeds: ["pool", collection_id]
 */
export function derivePendingPoolAddress(programId, collectionId) {
  return derivePDA(programId, [PDA_SEEDS.PENDING_POOL, collectionId]);
}

/**
 * Derive the ReporterRegistry account address.
 * Seeds: ["registry"]
 */
export function deriveRegistryAddress(programId) {
  return derivePDA(programId, [PDA_SEEDS.REGISTRY]);
}

// ─── Core PDA derivation ──────────────────────────────────────
/**
 * Derive a program-derived address from seeds.
 *
 * Production implementation: use SHA256(seeds || program_id || "PDA") truncated
 * to the address space, then find a valid point off the Ed25519 curve.
 *
 * For testnet/development: we use a simpler deterministic string hash
 * that is stable and unique per (program_id, seeds) combination.
 *
 * Replace with Arch SDK's official find_program_address() when available.
 */
function derivePDA(programId, seeds) {
  const seedStr = seeds.join("_");
  // Stable hash: combine program ID + seeds into a deterministic identifier
  const raw = `pda:${programId}:${seedStr}`;
  return toBase58Hash(raw);
}

/**
 * Simple deterministic hash → base58-like string.
 * NOT cryptographically secure — for address derivation only.
 * Replace with proper SHA256 + Ed25519 curve check in production.
 */
function toBase58Hash(input) {
  // djb2 hash for fast deterministic output
  let hash = 5381n;
  for (let i = 0; i < input.length; i++) {
    hash = ((hash << 5n) + hash + BigInt(input.charCodeAt(i))) & 0xFFFFFFFFFFFFFFFFn;
  }
  return hash.toString(16).padStart(16, "0").toUpperCase();
}

// ─── Address cache ────────────────────────────────────────────
// Cache derived addresses per program to avoid recomputation
const _cache = new Map();

export function getCachedOracleState(programId, collectionId) {
  const key = `${programId}:${collectionId}`;
  if (!_cache.has(key)) {
    _cache.set(key, deriveOracleStateAddress(programId, collectionId));
  }
  return _cache.get(key);
}
