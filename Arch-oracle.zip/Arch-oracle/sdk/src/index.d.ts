// ─────────────────────────────────────────────────────────────
// index.d.ts — TypeScript type definitions for @ordinals-oracle/sdk
// ─────────────────────────────────────────────────────────────

// ─── Price Response ───────────────────────────────────────────
export interface OraclePrice {
  // Identity
  collectionId:   string;
  collectionName: string;

  // Price in multiple units
  floorPriceSats: number;
  floorPriceBTC:  number;

  // Previous price (from prior oracle round)
  prevPriceSats:  number;
  prevPriceBTC:   number;

  // Change vs previous round
  priceDeltaSats: number | null;
  priceDeltaPct:  number | null;
  priceDirection: "up" | "down" | "flat" | null;

  // Quality indicators
  confidence:    number;    // 0-100
  reporterCount: number;
  isStale:       boolean;
  ageSecs:       number | null;

  // Timestamps
  lastUpdated:     number;        // unix seconds
  lastUpdatedDate: string | null; // ISO 8601

  // State
  isInitialized: boolean;
}

// ─── LTV Result ───────────────────────────────────────────────
export interface LTVResult {
  collectionId:    string;
  collectionName:  string;
  floorPriceSats:  number;
  floorPriceBTC:   number;
  ltvRatio:        number;
  maxLoanSats:     number;
  maxLoanBTC:      number;
  confidence:      number;
  isStale:         boolean;
}

// ─── Liquidation Check ────────────────────────────────────────
export interface LiquidationCheck {
  collectionId:             string;
  liquidatable:             boolean;
  currentValueSats:         number;
  currentValueBTC:          number;
  loanAmountSats:           number;
  liquidationThresholdSats: number;
  healthRatio:              number;
  healthPct:                number;
  priceConfidence:          number;
  priceIsStale:             boolean;
}

// ─── Health Check ─────────────────────────────────────────────
export interface HealthResult {
  healthy:    boolean;
  blockCount: number | null;
  network:    string;
}

// ─── Collection Meta ─────────────────────────────────────────
export interface CollectionMeta {
  id:          string;
  name:        string;
  supply:      number;
  description: string;
}

// ─── Client Options ──────────────────────────────────────────
export interface OracleClientOptions {
  network?:       "testnet" | "mainnet" | "regtest";
  programId?:     string;
  rpcUrl?:        string;
  timeoutMs?:     number;
  allowStale?:    boolean;
  minConfidence?: number;
  cacheTtlMs?:    number;
}

// ─── OracleClient ────────────────────────────────────────────
export class OracleClient {
  constructor(options?: OracleClientOptions);

  /**
   * Get the current floor price for an Ordinals collection.
   * @throws {OracleError} if stale, low confidence, or not found
   */
  getFloorPrice(collectionId: string): Promise<OraclePrice>;

  /** Floor price in satoshis only */
  getFloorPriceSats(collectionId: string): Promise<number>;

  /** Floor price in BTC only */
  getFloorPriceBTC(collectionId: string): Promise<number>;

  /** Fetch prices for multiple collections in parallel */
  getMultiplePrices(collectionIds: string[]): Promise<Map<string, OraclePrice | OracleError>>;

  /** Fetch prices for all tracked collections */
  getAllPrices(): Promise<Map<string, OraclePrice | OracleError>>;

  /** Check if a price feed is stale */
  isStale(collectionId: string): Promise<boolean>;

  /** Calculate max loan amount for Ordinal collateral */
  getLTV(collectionId: string, ltvRatio?: number): Promise<LTVResult>;

  /** Check if a collateralized position should be liquidated */
  isLiquidatable(
    collectionId: string,
    loanAmountSats: number,
    healthFactor?: number
  ): Promise<LiquidationCheck>;

  /** Check RPC and oracle health */
  getHealth(): Promise<HealthResult>;

  /** List all tracked collections */
  listCollections(): CollectionMeta[];

  /** Clear the client-side price cache */
  clearCache(): void;
}

// ─── OracleError ─────────────────────────────────────────────
export class OracleError extends Error {
  name:    "OracleError";
  code:    string;
  context: Record<string, unknown>;

  constructor(message: string, code?: string, context?: Record<string, unknown>);
}

// ─── Constants ───────────────────────────────────────────────
export const COLLECTIONS: {
  NODE_MONKES:     "node-monkes";
  BITCOIN_PUPPETS: "bitcoin-puppets";
  OMB:             "ordinal-maxi-biz";
  RUNESTONES:      "runestones";
  BITCOIN_FROGS:   "bitcoin-frogs";
};

export const NETWORKS: Record<"testnet" | "mainnet" | "regtest", {
  rpcUrl:   string;
  explorer: string | null;
  name:     string;
}>;

export const ORACLE_CONFIG: {
  MAX_PRICE_AGE_SECS: number;
  MIN_CONFIDENCE:     number;
  DEFAULT_TIMEOUT_MS: number;
};

export const TESTNET:  "testnet";
export const MAINNET:  "mainnet";
export const REGTEST:  "regtest";

// ─── Factory ─────────────────────────────────────────────────
export function createOracle(
  network?: "testnet" | "mainnet" | "regtest",
  options?: OracleClientOptions
): OracleClient;
