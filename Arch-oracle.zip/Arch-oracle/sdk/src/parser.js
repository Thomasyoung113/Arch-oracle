// ─────────────────────────────────────────────────────────────
// parser.js — Decodes on-chain account data into JS objects
//
// Arch stores account data as Borsh-encoded bytes.
// This parser mirrors the Rust struct layout in OracleState.
// Field order MUST match state.rs exactly.
// ─────────────────────────────────────────────────────────────

import { ORACLE_CONFIG, COLLECTION_META } from "./constants.js";

// ─── Borsh primitive readers ──────────────────────────────────
class BorshReader {
  constructor(buffer) {
    this.buf    = buffer;
    this.offset = 0;
  }

  readU8() {
    const val = this.buf.readUInt8(this.offset);
    this.offset += 1;
    return val;
  }

  readU16() {
    const val = this.buf.readUInt16LE(this.offset);
    this.offset += 2;
    return val;
  }

  readU32() {
    const val = this.buf.readUInt32LE(this.offset);
    this.offset += 4;
    return val;
  }

  readU64() {
    // JS BigInt for safety, then convert to Number (safe up to ~9 quadrillion sats)
    const lo  = this.buf.readUInt32LE(this.offset);
    const hi  = this.buf.readUInt32LE(this.offset + 4);
    this.offset += 8;
    return hi * 0x100000000 + lo;
  }

  readBool() {
    return this.readU8() !== 0;
  }

  readString() {
    // Borsh strings: u32 length prefix + UTF-8 bytes
    const len = this.readU32();
    const str = this.buf.toString("utf8", this.offset, this.offset + len);
    this.offset += len;
    return str;
  }

  readBytes(n) {
    const bytes = this.buf.slice(this.offset, this.offset + n);
    this.offset += n;
    return bytes;
  }
}

// ─── OracleState decoder ─────────────────────────────────────
/**
 * Decode raw Borsh bytes into an OracleState object.
 * Field order matches state.rs OracleState struct exactly.
 *
 * @param {Buffer|Uint8Array} data - Raw account data bytes
 * @returns {OraclePrice} Decoded price object
 */
export function decodeOracleState(data) {
  const buf = Buffer.isBuffer(data) ? data : Buffer.from(data);
  const r   = new BorshReader(buf);

  const raw = {
    collectionId:    r.readString(),
    floorPriceSats:  r.readU64(),
    lastUpdated:     r.readU64(),
    reporterCount:   r.readU8(),
    confidence:      r.readU8(),
    prevPriceSats:   r.readU64(),
    isInitialized:   r.readBool(),
    bump:            r.readU8(),
    version:         r.readU8(),
  };

  return enrichOracleState(raw);
}

/**
 * Parse oracle price from program logs.
 * The GetFloorPrice instruction emits a structured log line:
 *   "ORACLE_PRICE collection=... price_sats=... confidence=... ..."
 */
export function parsePriceFromLogs(logs) {
  const oracleLine = logs.find((l) => l.startsWith("ORACLE_PRICE"));
  if (!oracleLine) return null;

  const parsed = {};
  for (const part of oracleLine.replace("ORACLE_PRICE ", "").split(" ")) {
    const [key, val] = part.split("=");
    if (key && val !== undefined) parsed[key] = val;
  }

  if (!parsed.price_sats) return null;

  const raw = {
    collectionId:   parsed.collection,
    floorPriceSats: parseInt(parsed.price_sats, 10),
    lastUpdated:    parseInt(parsed.last_updated, 10),
    reporterCount:  parseInt(parsed.reporter_count, 10),
    confidence:     parseInt(parsed.confidence, 10),
    prevPriceSats:  0,
    isInitialized:  true,
  };

  return enrichOracleState(raw);
}

// ─── Enrich raw state with derived fields ─────────────────────
function enrichOracleState(raw) {
  const nowSecs = Math.floor(Date.now() / 1000);
  const ageSecs = raw.lastUpdated > 0 ? nowSecs - raw.lastUpdated : null;
  const isStale = ageSecs === null || ageSecs > ORACLE_CONFIG.MAX_PRICE_AGE_SECS;
  const meta    = COLLECTION_META[raw.collectionId] ?? {};

  // Price change from previous round
  const priceDeltaSats = raw.prevPriceSats > 0
    ? raw.floorPriceSats - raw.prevPriceSats
    : null;
  const priceDeltaPct = raw.prevPriceSats > 0
    ? ((raw.floorPriceSats - raw.prevPriceSats) / raw.prevPriceSats) * 100
    : null;

  return {
    // Identity
    collectionId:   raw.collectionId,
    collectionName: meta.name ?? raw.collectionId,

    // Price in multiple units
    floorPriceSats: raw.floorPriceSats,
    floorPriceBTC:  raw.floorPriceSats / 1e8,

    // Previous price
    prevPriceSats: raw.prevPriceSats,
    prevPriceBTC:  raw.prevPriceSats / 1e8,

    // Change
    priceDeltaSats,
    priceDeltaPct:  priceDeltaPct !== null ? parseFloat(priceDeltaPct.toFixed(2)) : null,
    priceDirection: priceDeltaSats === null ? null
                  : priceDeltaSats > 0 ? "up"
                  : priceDeltaSats < 0 ? "down"
                  : "flat",

    // Quality
    confidence:    raw.confidence,   // 0-100
    reporterCount: raw.reporterCount,
    isStale,
    ageSecs,

    // Timestamps
    lastUpdated:     raw.lastUpdated,
    lastUpdatedDate: raw.lastUpdated > 0 ? new Date(raw.lastUpdated * 1000).toISOString() : null,

    // Meta
    isInitialized: raw.isInitialized,
  };
}
