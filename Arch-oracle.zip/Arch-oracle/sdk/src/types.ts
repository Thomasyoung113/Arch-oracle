// ─────────────────────────────────────────────────────────────
// types.ts — All public types for the Ordinals Oracle SDK
// ─────────────────────────────────────────────────────────────

// ─── Network ──────────────────────────────────────────────────
export type Network = "testnet" | "mainnet" | "regtest";

export const NETWORK_RPC_URLS: Record<Network, string> = {
  testnet: "https://rpc.testnet.arch.network",
  mainnet: "https://rpc.arch.network",
  regtest: "http://localhost:9002",
};

// ─── Oracle Price ─────────────────────────────────────────────
/** A single floor price reading from the oracle */
export interface OraclePrice {
  /** Collection identifier (e.g. "node-monkes") */
  collectionId: string;

  /** Floor price in satoshis (1 BTC = 100,000,000 sats) */
  priceSats: number;

  /** Floor price as a BTC decimal string (e.g. "0.045000") */
  priceBTC: string;

  /** Floor price in USD (requires BTC/USD price feed, optional) */
  priceUSD: number | null;

  /** Confidence score 0–100. Higher = more agreement between oracle nodes */
  confidence: number;

  /** How many oracle nodes contributed to this price */
  reporterCount: number;

  /** Unix timestamp (seconds) when the price was last published on-chain */
  lastUpdated: number;

  /** Human-readable time since last update (e.g. "3 minutes ago") */
  lastUpdatedAgo: string;

  /** Previous price in sats (for change calculation) */
  prevPriceSats: number;

  /** Price change since last update (sats) */
  priceChangeSats: number;

  /** Price change percentage since last update */
  priceChangePct: number;

  /** Whether the price is considered fresh (< 30 minutes old) */
  isFresh: boolean;
}

/** Result of a multi-collection price fetch */
export interface PriceFeedResult {
  prices: Record<string, OraclePrice>;
  fetchedAt: number;
  network: Network;
}

// ─── Oracle State (raw on-chain) ──────────────────────────────
/** Raw state as returned by the Arch RPC — matches OracleState in state.rs */
export interface RawOracleState {
  collection_id: string;
  floor_price_sats: number;
  last_updated: number;
  reporter_count: number;
  confidence: number;
  prev_price_sats: number;
  is_initialized: boolean;
  version: number;
}

// ─── Subscription ─────────────────────────────────────────────
export interface SubscriptionOptions {
  /** Collections to subscribe to */
  collections: string[];

  /** Polling interval in milliseconds (minimum 60_000 = 1 minute) */
  intervalMs?: number;

  /** Called when any price updates */
  onUpdate: (prices: PriceFeedResult) => void;

  /** Called on fetch errors (optional — errors are non-fatal by default) */
  onError?: (err: Error) => void;
}

export interface Subscription {
  /** Stop the subscription */
  unsubscribe: () => void;

  /** Force an immediate refresh */
  refresh: () => Promise<void>;
}

// ─── Oracle Client Options ────────────────────────────────────
export interface OracleClientOptions {
  /** Arch Network to connect to */
  network?: Network;

  /** Override the RPC URL (optional) */
  rpcUrl?: string;

  /** Your deployed oracle program ID */
  programId: string;

  /** BTC/USD price for USD conversion (optional, provide your own feed) */
  btcUsdPrice?: number;

  /** Request timeout in ms (default: 10000) */
  timeoutMs?: number;

  /** Enable debug logging */
  debug?: boolean;
}

// ─── Errors ───────────────────────────────────────────────────
export type OracleErrorCode =
  | "PRICE_STALE"
  | "PRICE_EMPTY"
  | "COLLECTION_NOT_FOUND"
  | "RPC_ERROR"
  | "INVALID_RESPONSE"
  | "NETWORK_ERROR";

export class OracleSDKError extends Error {
  constructor(
    public readonly code: OracleErrorCode,
    message: string,
    public readonly cause?: unknown
  ) {
    super(message);
    this.name = "OracleSDKError";
  }
}

// ─── Supported Collections ────────────────────────────────────
/** Known collection IDs supported by the oracle */
export const KNOWN_COLLECTIONS = [
  "node-monkes",
  "bitcoin-puppets",
  "ordinal-maxi-biz",
  "runestones",
  "bitcoin-frogs",
] as const;

export type KnownCollection = (typeof KNOWN_COLLECTIONS)[number];
