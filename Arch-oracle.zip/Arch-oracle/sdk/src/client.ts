// ─────────────────────────────────────────────────────────────
// client.ts — OracleClient: the main SDK interface
//
// This is what protocol developers import and use.
// Everything is designed for a one-liner experience.
//
// Usage:
//   const oracle = new OracleClient({ programId: "...", network: "testnet" })
//   const price  = await oracle.getPrice("node-monkes")
// ─────────────────────────────────────────────────────────────

import { ArchRPCClient } from "./rpc.js";
import { formatPrice, formatPriceDisplay, confidenceLabel } from "./formatter.js";
import {
  Network,
  OracleClientOptions,
  OraclePrice,
  OracleSDKError,
  PriceFeedResult,
  Subscription,
  SubscriptionOptions,
} from "./types.js";

export class OracleClient {
  private rpc: ArchRPCClient;
  private programId: string;
  private network: Network;
  private btcUsdPrice: number | null;
  private debug: boolean;

  // Simple in-memory cache: collectionId → { price, fetchedAt }
  private cache = new Map<string, { price: OraclePrice; fetchedAt: number }>();
  private readonly CACHE_TTL_MS = 30_000; // 30 seconds

  constructor(options: OracleClientOptions) {
    this.programId   = options.programId;
    this.network     = options.network ?? "testnet";
    this.btcUsdPrice = options.btcUsdPrice ?? null;
    this.debug       = options.debug ?? false;

    this.rpc = new ArchRPCClient(
      this.network,
      options.rpcUrl,
      options.timeoutMs ?? 10_000,
      this.debug
    );
  }

  // ─── getPrice ──────────────────────────────────────────────
  /**
   * Get the current floor price for a single collection.
   *
   * @example
   * const price = await oracle.getPrice("node-monkes")
   * console.log(price.priceBTC)          // "0.045000"
   * console.log(price.confidence)         // 87
   * console.log(price.lastUpdatedAgo)     // "3 minutes ago"
   */
  async getPrice(collectionId: string): Promise<OraclePrice> {
    // Check cache first
    const cached = this.cache.get(collectionId);
    if (cached && Date.now() - cached.fetchedAt < this.CACHE_TTL_MS) {
      if (this.debug) console.log(`[OracleSDK] Cache hit: ${collectionId}`);
      return cached.price;
    }

    const raw = await this.rpc.callGetFloorPrice(this.programId, collectionId);
    const price = formatPrice(raw, this.btcUsdPrice);

    // Cache result
    this.cache.set(collectionId, { price, fetchedAt: Date.now() });

    return price;
  }

  // ─── getPrices ─────────────────────────────────────────────
  /**
   * Get prices for multiple collections in parallel.
   * Failed fetches are included as null — partial results always returned.
   *
   * @example
   * const feed = await oracle.getPrices(["node-monkes", "bitcoin-puppets"])
   * const nodeMonkesPrice = feed.prices["node-monkes"]
   */
  async getPrices(collectionIds: string[]): Promise<PriceFeedResult> {
    const results = await Promise.allSettled(
      collectionIds.map((id) => this.getPrice(id))
    );

    const prices: Record<string, OraclePrice> = {};
    for (let i = 0; i < collectionIds.length; i++) {
      const result = results[i];
      if (result.status === "fulfilled") {
        prices[collectionIds[i]] = result.value;
      } else {
        if (this.debug) {
          console.warn(
            `[OracleSDK] Failed to fetch ${collectionIds[i]}:`,
            result.reason
          );
        }
      }
    }

    return {
      prices,
      fetchedAt: Math.floor(Date.now() / 1000),
      network: this.network,
    };
  }

  // ─── getPriceSats ──────────────────────────────────────────
  /**
   * Minimal helper — returns just the price in satoshis.
   * Ideal for lending protocols that just need the number.
   *
   * Throws OracleSDKError if price is stale or collection not found.
   *
   * @example
   * const priceSats = await oracle.getPriceSats("node-monkes")
   * const ltvSats = priceSats * 0.5  // 50% LTV collateral
   */
  async getPriceSats(collectionId: string): Promise<number> {
    const price = await this.getPrice(collectionId);

    if (!price.isFresh) {
      throw new OracleSDKError(
        "PRICE_STALE",
        `Price for ${collectionId} is stale (last updated ${price.lastUpdatedAgo}). ` +
          "Do not use stale prices for liquidations."
      );
    }

    return price.priceSats;
  }

  // ─── isHealthy ─────────────────────────────────────────────
  /**
   * Check if a collection's price feed is live and fresh.
   * Use this as a circuit breaker before executing liquidations.
   *
   * @example
   * if (await oracle.isHealthy("node-monkes")) {
   *   // safe to use price
   * }
   */
  async isHealthy(collectionId: string): Promise<boolean> {
    try {
      const price = await this.getPrice(collectionId);
      return price.isFresh && price.confidence >= 50;
    } catch {
      return false;
    }
  }

  // ─── getLTV ────────────────────────────────────────────────
  /**
   * Calculate the maximum borrowable amount (in sats) for an Ordinal used
   * as collateral, given an LTV ratio and optional confidence threshold.
   *
   * Adjusts LTV down automatically when oracle confidence is low.
   *
   * @param collectionId  Collection the Ordinal belongs to
   * @param ltvRatio      Target LTV (0.0 – 1.0). E.g. 0.5 = 50% LTV
   * @param minConfidence Minimum confidence required (default: 70)
   *
   * @example
   * // How much can I lend against a NodeMonkes Ordinal at 50% LTV?
   * const maxLoanSats = await oracle.getLTV("node-monkes", 0.5)
   */
  async getLTV(
    collectionId: string,
    ltvRatio: number,
    minConfidence = 70
  ): Promise<{ maxLoanSats: number; effectiveLTV: number; confidence: number }> {
    if (ltvRatio <= 0 || ltvRatio > 1) {
      throw new RangeError("ltvRatio must be between 0 and 1");
    }

    const price = await this.getPrice(collectionId);

    if (!price.isFresh) {
      throw new OracleSDKError(
        "PRICE_STALE",
        `Cannot compute LTV — price for ${collectionId} is stale`
      );
    }

    // Reduce LTV when confidence is below minimum
    // e.g. if target LTV is 50% but confidence is 60 (below 70 threshold),
    //      apply a 10% penalty → effective LTV = 45%
    let effectiveLTV = ltvRatio;
    if (price.confidence < minConfidence) {
      const penalty = ((minConfidence - price.confidence) / minConfidence) * 0.2;
      effectiveLTV = Math.max(ltvRatio * (1 - penalty), ltvRatio * 0.7);
      if (this.debug) {
        console.warn(
          `[OracleSDK] Low confidence (${price.confidence}) — LTV reduced to ${(effectiveLTV * 100).toFixed(1)}%`
        );
      }
    }

    const maxLoanSats = Math.floor(price.priceSats * effectiveLTV);

    return {
      maxLoanSats,
      effectiveLTV: parseFloat(effectiveLTV.toFixed(4)),
      confidence: price.confidence,
    };
  }

  // ─── subscribe ─────────────────────────────────────────────
  /**
   * Subscribe to live price updates via polling.
   * Calls onUpdate whenever any price changes.
   * Returns a Subscription object with unsubscribe() and refresh().
   *
   * @example
   * const sub = oracle.subscribe({
   *   collections: ["node-monkes", "bitcoin-puppets"],
   *   intervalMs: 120_000,  // check every 2 minutes
   *   onUpdate: (feed) => {
   *     console.log("NodeMonkes floor:", feed.prices["node-monkes"]?.priceBTC)
   *   }
   * })
   *
   * // Later...
   * sub.unsubscribe()
   */
  subscribe(options: SubscriptionOptions): Subscription {
    const {
      collections,
      intervalMs = 120_000,
      onUpdate,
      onError,
    } = options;

    const MIN_INTERVAL = 60_000;
    const safeInterval = Math.max(intervalMs, MIN_INTERVAL);

    let stopped = false;
    let timer: ReturnType<typeof setTimeout> | null = null;

    const doFetch = async () => {
      if (stopped) return;
      try {
        const feed = await this.getPrices(collections);
        onUpdate(feed);
      } catch (err) {
        if (onError) onError(err as Error);
        else if (this.debug) console.warn("[OracleSDK] Subscription fetch error:", err);
      }
    };

    const schedule = () => {
      timer = setTimeout(async () => {
        await doFetch();
        if (!stopped) schedule();
      }, safeInterval);
    };

    // Fetch immediately, then on interval
    doFetch();
    schedule();

    return {
      unsubscribe: () => {
        stopped = true;
        if (timer !== null) clearTimeout(timer);
        if (this.debug) console.log("[OracleSDK] Subscription stopped");
      },
      refresh: doFetch,
    };
  }

  // ─── setBtcUsdPrice ────────────────────────────────────────
  /**
   * Update the BTC/USD price used for USD conversions.
   * Call this whenever you refresh your BTC price feed.
   *
   * @example
   * oracle.setBtcUsdPrice(65000)
   */
  setBtcUsdPrice(price: number): void {
    this.btcUsdPrice = price;
    // Invalidate cache so next fetches recalculate USD values
    this.cache.clear();
  }

  // ─── clearCache ────────────────────────────────────────────
  /** Force-clear the in-memory cache. */
  clearCache(): void {
    this.cache.clear();
  }

  // ─── format helpers ────────────────────────────────────────
  /** Format a price for display (includes BTC, USD, change %). */
  formatPrice(price: OraclePrice, showUSD = true): string {
    return formatPriceDisplay(price, showUSD);
  }

  /** Get a confidence label for a price: "HIGH" | "MEDIUM" | "LOW" */
  confidenceLabel(price: OraclePrice): "HIGH" | "MEDIUM" | "LOW" {
    return confidenceLabel(price.confidence);
  }
}
