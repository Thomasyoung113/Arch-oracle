// ─────────────────────────────────────────────────────────────
// index.js — Public SDK surface
//
// Everything a consumer needs is exported from here.
// Internal modules (rpc.js, parser.js, pda.js) are not re-exported.
// ─────────────────────────────────────────────────────────────

export { OracleClient, OracleError } from "./client.js";
export { COLLECTIONS, COLLECTION_META, NETWORKS, ORACLE_CONFIG } from "./constants.js";
export { OracleRpcError } from "./rpc.js";

// ─── Convenience factory ──────────────────────────────────────
/**
 * Create an OracleClient with sensible defaults.
 * The quickest way to get started.
 *
 * @param {string} [network="testnet"]
 * @param {Object} [options]
 * @returns {OracleClient}
 *
 * @example
 * import { createOracle } from "@ordinals-oracle/sdk";
 * const oracle = createOracle("testnet");
 * const price  = await oracle.getFloorPrice("node-monkes");
 */
export function createOracle(network = "testnet", options = {}) {
  const { OracleClient } = require("./client.js");
  return new OracleClient({ network, ...options });
}

// Re-export for convenience (no need to import from constants separately)
export const TESTNET  = "testnet";
export const MAINNET  = "mainnet";
export const REGTEST  = "regtest";
