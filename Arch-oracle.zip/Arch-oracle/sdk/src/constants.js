// ─────────────────────────────────────────────────────────────
// constants.js — Network addresses, program IDs, known accounts
// ─────────────────────────────────────────────────────────────

// ─── Network RPC endpoints ────────────────────────────────────
export const NETWORKS = {
  testnet: {
    rpcUrl:   "https://rpc.testnet.arch.network",
    explorer: "https://explorer.testnet.arch.network",
    name:     "Arch Testnet",
  },
  mainnet: {
    rpcUrl:   "https://rpc.arch.network",
    explorer: "https://explorer.arch.network",
    name:     "Arch Mainnet",
  },
  regtest: {
    rpcUrl:   "http://localhost:9002",
    explorer: null,
    name:     "Local Regtest",
  },
};

// ─── Oracle Program IDs ───────────────────────────────────────
// Update these once you deploy the oracle program to each network
export const ORACLE_PROGRAM_IDS = {
  testnet: process.env.ORACLE_PROGRAM_ID_TESTNET ?? "DEPLOY_TO_GET_PROGRAM_ID",
  mainnet: process.env.ORACLE_PROGRAM_ID_MAINNET ?? null,
  regtest: process.env.ORACLE_PROGRAM_ID_REGTEST ?? null,
};

// ─── Supported Collections ────────────────────────────────────
// Registry of all collections tracked by the oracle.
// Consumers can use these IDs to query prices.
export const COLLECTIONS = {
  NODE_MONKES:     "node-monkes",
  BITCOIN_PUPPETS: "bitcoin-puppets",
  OMB:             "ordinal-maxi-biz",
  RUNESTONES:      "runestones",
  BITCOIN_FROGS:   "bitcoin-frogs",
};

// Human-readable metadata per collection
export const COLLECTION_META = {
  [COLLECTIONS.NODE_MONKES]: {
    name:        "NodeMonkes",
    supply:      10_000,
    description: "First 10k collection inscribed on Bitcoin by a single person",
  },
  [COLLECTIONS.BITCOIN_PUPPETS]: {
    name:        "Bitcoin Puppets",
    supply:      10_000,
    description: "Iconic Bitcoin NFT collection",
  },
  [COLLECTIONS.OMB]: {
    name:        "Ordinal Maxi Biz",
    supply:      5_000,
    description: "Bitcoin maximalist Ordinals collection",
  },
  [COLLECTIONS.RUNESTONES]: {
    name:        "Runestones",
    supply:      112_383,
    description: "Airdropped to top Ordinals holders — airdropped by Runestone creator",
  },
  [COLLECTIONS.BITCOIN_FROGS]: {
    name:        "Bitcoin Frogs",
    supply:      10_000,
    description: "Frog-themed Bitcoin Ordinals",
  },
};

// ─── Oracle Config ────────────────────────────────────────────
export const ORACLE_CONFIG = {
  /** Max age of a price before it's considered stale (matches on-chain: 30 min) */
  MAX_PRICE_AGE_SECS: 1800,

  /** Minimum confidence score to trust a price feed */
  MIN_CONFIDENCE: 50,

  /** Default request timeout for RPC calls (ms) */
  DEFAULT_TIMEOUT_MS: 10_000,
};

// ─── PDA Seeds (must match Rust program) ─────────────────────
export const PDA_SEEDS = {
  ORACLE_STATE: "oracle",   // ["oracle", collection_id]
  PENDING_POOL: "pool",     // ["pool",   collection_id]
  REGISTRY:     "registry", // ["registry"]
};
