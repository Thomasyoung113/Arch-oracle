// ─────────────────────────────────────────────────────────────
// index.ts — Public API surface for @ordinals-oracle/sdk
//
// Import from here. Everything else is internal.
// ─────────────────────────────────────────────────────────────

// Main client
export { OracleClient } from "./client.js";

// Types — everything a consumer might need to type their code
export type {
  OraclePrice,
  OracleClientOptions,
  PriceFeedResult,
  Subscription,
  SubscriptionOptions,
  Network,
  KnownCollection,
  RawOracleState,
} from "./types.js";

// Error class (for instanceof checks in catch blocks)
export { OracleSDKError } from "./types.js";

// Constants
export { KNOWN_COLLECTIONS, NETWORK_RPC_URLS } from "./types.js";

// Utility formatters (for UI layers that want to display prices)
export { formatPrice, formatPriceDisplay, formatTimeAgo, confidenceLabel } from "./formatter.js";

// Version
export const SDK_VERSION = "0.1.0";
