// ─────────────────────────────────────────────────────────────
// src/test.js — SDK unit tests (no network needed)
// Run: node src/test.js
// ─────────────────────────────────────────────────────────────

import { formatPrice, formatTimeAgo, confidenceLabel } from "./formatter.js";
import { OracleSDKError } from "./types.js";

let passed = 0;
let failed = 0;

function test(name, fn) {
  try { fn(); console.log(`  ✅ ${name}`); passed++; }
  catch (err) { console.log(`  ❌ ${name}: ${err.message}`); failed++; }
}
function assert(cond, msg) { if (!cond) throw new Error(msg ?? "Assertion failed"); }
function assertEqual(a, b, msg) { if (a !== b) throw new Error(msg ?? `Expected ${JSON.stringify(a)} === ${JSON.stringify(b)}`); }

const now = Math.floor(Date.now() / 1000);
const freshRaw = { collection_id: "node-monkes", floor_price_sats: 4_500_000, last_updated: now - 300, reporter_count: 4, confidence: 87, prev_price_sats: 4_300_000, is_initialized: true, version: 1 };
const staleRaw = { ...freshRaw, last_updated: now - 3600 };
const zeroRaw  = { ...freshRaw, last_updated: 0, floor_price_sats: 0, prev_price_sats: 0 };

console.log("\n⏱  formatTimeAgo Tests:");
test("seconds ago",    () => assertEqual(formatTimeAgo(45),   "45s ago"));
test("1 minute ago",   () => assertEqual(formatTimeAgo(90),   "1 minute ago"));
test("3 minutes ago",  () => assertEqual(formatTimeAgo(180),  "3 minutes ago"));
test("1 hour ago",     () => assertEqual(formatTimeAgo(3700), "1 hour ago"));
test("1 day ago",      () => assertEqual(formatTimeAgo(90000),"1 day ago"));
test("just now (neg)", () => assertEqual(formatTimeAgo(-5),   "just now"));

console.log("\n🎯 confidenceLabel Tests:");
test("90 → HIGH",   () => assertEqual(confidenceLabel(90), "HIGH"));
test("80 → HIGH",   () => assertEqual(confidenceLabel(80), "HIGH"));
test("79 → MEDIUM", () => assertEqual(confidenceLabel(79), "MEDIUM"));
test("50 → MEDIUM", () => assertEqual(confidenceLabel(50), "MEDIUM"));
test("49 → LOW",    () => assertEqual(confidenceLabel(49), "LOW"));
test("0  → LOW",    () => assertEqual(confidenceLabel(0),  "LOW"));

console.log("\n💰 formatPrice Tests:");
test("fresh → isFresh true",  () => assert(formatPrice(freshRaw).isFresh,   "should be fresh"));
test("stale → isFresh false", () => assert(!formatPrice(staleRaw).isFresh,  "should be stale"));
test("priceBTC 6 decimals",   () => assertEqual(formatPrice(freshRaw).priceBTC, "0.045000"));
test("priceUSD null without btcUsd", () => assertEqual(formatPrice(freshRaw, null).priceUSD, null));
test("priceUSD computed with btcUsd", () => { const p = formatPrice(freshRaw, 60_000); assertEqual(p.priceUSD, (4_500_000 / 1e8) * 60_000); });
test("priceChangeSats correct", () => assertEqual(formatPrice(freshRaw).priceChangeSats, 200_000));
test("zero prevPrice → 0% change", () => assertEqual(formatPrice({ ...freshRaw, prev_price_sats: 0 }).priceChangePct, 0));
test("never-updated → stale", () => assert(!formatPrice(zeroRaw).isFresh, "zero last_updated should be stale"));

console.log("\n🚨 OracleSDKError Tests:");
test("correct code",         () => assertEqual(new OracleSDKError("PRICE_STALE", "msg").code, "PRICE_STALE"));
test("correct name",         () => assertEqual(new OracleSDKError("RPC_ERROR", "msg").name, "OracleSDKError"));
test("instanceof Error",     () => assert(new OracleSDKError("RPC_ERROR", "msg") instanceof Error));
test("stores cause",         () => { const c = new Error("x"); assert(new OracleSDKError("NETWORK_ERROR", "y", c).cause === c); });

console.log(`\n${"─".repeat(50)}`);
console.log(`Results: ${passed} passed, ${failed} failed`);
if (failed === 0) console.log("✅ All tests passed!\n");
else { console.log("❌ Some tests failed.\n"); process.exit(1); }
