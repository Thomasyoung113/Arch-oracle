// ─────────────────────────────────────────────────────────────
// formatter.ts — Converts raw on-chain state into rich OraclePrice objects
// ─────────────────────────────────────────────────────────────

import { OraclePrice, RawOracleState } from "./types.js";

const STALE_THRESHOLD_SECS = 1800; // 30 minutes — matches Rust program

/**
 * Transform a raw RawOracleState (from chain) into a rich OraclePrice.
 * Adds BTC/USD formatting, change calculations, and freshness status.
 */
export function formatPrice(
  raw: RawOracleState,
  btcUsdPrice: number | null = null
): OraclePrice {
  const now = Math.floor(Date.now() / 1000);
  const ageSecs = now - raw.last_updated;
  const isFresh = ageSecs <= STALE_THRESHOLD_SECS && raw.last_updated > 0;

  const priceChangeSats = raw.floor_price_sats - raw.prev_price_sats;
  const priceChangePct =
    raw.prev_price_sats > 0
      ? (priceChangeSats / raw.prev_price_sats) * 100
      : 0;

  const priceUSD =
    btcUsdPrice !== null
      ? (raw.floor_price_sats / 1e8) * btcUsdPrice
      : null;

  return {
    collectionId:    raw.collection_id,
    priceSats:       raw.floor_price_sats,
    priceBTC:        (raw.floor_price_sats / 1e8).toFixed(6),
    priceUSD,
    confidence:      raw.confidence,
    reporterCount:   raw.reporter_count,
    lastUpdated:     raw.last_updated,
    lastUpdatedAgo:  formatTimeAgo(ageSecs),
    prevPriceSats:   raw.prev_price_sats,
    priceChangeSats,
    priceChangePct:  parseFloat(priceChangePct.toFixed(2)),
    isFresh,
  };
}

/**
 * Human-readable relative time string.
 */
export function formatTimeAgo(ageSecs: number): string {
  if (ageSecs < 0)   return "just now";
  if (ageSecs < 60)  return `${ageSecs}s ago`;
  if (ageSecs < 3600) {
    const mins = Math.floor(ageSecs / 60);
    return `${mins} minute${mins !== 1 ? "s" : ""} ago`;
  }
  if (ageSecs < 86400) {
    const hrs = Math.floor(ageSecs / 3600);
    return `${hrs} hour${hrs !== 1 ? "s" : ""} ago`;
  }
  const days = Math.floor(ageSecs / 86400);
  return `${days} day${days !== 1 ? "s" : ""} ago`;
}

/**
 * Format sats as a human-readable BTC string with optional USD.
 */
export function formatPriceDisplay(
  price: OraclePrice,
  showUSD = true
): string {
  const btc = `${price.priceBTC} BTC`;
  const usd = showUSD && price.priceUSD !== null
    ? ` ($${price.priceUSD.toLocaleString("en-US", { maximumFractionDigits: 0 })})`
    : "";
  const change = price.priceChangePct !== 0
    ? ` ${price.priceChangePct >= 0 ? "▲" : "▼"} ${Math.abs(price.priceChangePct).toFixed(1)}%`
    : "";
  return `${btc}${usd}${change}`;
}

/**
 * Confidence level as a label.
 */
export function confidenceLabel(score: number): "HIGH" | "MEDIUM" | "LOW" {
  if (score >= 80) return "HIGH";
  if (score >= 50) return "MEDIUM";
  return "LOW";
}
